"""Historique de la courbe des taux de référence BAM et variations (jour, mois, début d'année).

Chaque courbe téléchargée sur bkam.ma est conservée telle quelle (CSV d'origine) dans
data/historique_courbes/AAAA-MM-JJ.csv. Les jours sans publication (fériés…) sont notés dans
_jours_sans_courbe.txt pour ne pas être redemandés.

Variations : la courbe du jour D est comparée à
  - J-1      : la dernière courbe publiée avant D ;
  - mois     : la dernière courbe du mois précédent (MTD) ;
  - YTD      : la dernière courbe de l'année précédente.
Les taux sont lus aux maturités standard BAM (13 s … 30 ans) par interpolation, dans leur base
de publication (monétaire jusqu'à 1 an, actuariel au-delà). Variations en points de base.
"""
from __future__ import annotations

import threading
from datetime import date, datetime, timedelta
from pathlib import Path

import re

from .bam import _a_des_taux, _telecharger
from .courbe import CourbeTaux, _parse_date

DOSSIER_DEFAUT = Path(__file__).resolve().parent.parent / "data" / "historique_courbes"
MATURITES = [  # libellé, jours
    ("13 sem.", 91), ("26 sem.", 182), ("52 sem.", 364), ("2 ans", 730), ("5 ans", 1825),
    ("10 ans", 3650), ("15 ans", 5475), ("20 ans", 7300), ("30 ans", 10950),
]
_verrou = threading.Lock()


class Historique:
    def __init__(self, dossier: Path | str = DOSSIER_DEFAUT, telecharger=_telecharger):
        self.dossier = Path(dossier)
        self.dossier.mkdir(parents=True, exist_ok=True)
        self._telecharger = telecharger
        self._cache: dict[date, CourbeTaux] = {}

    # ------------------------------------------------------------------ stockage
    # ------------------------------------------------------------------ historique importé (maturités standard)
    @property
    def _fichier_import(self) -> Path:
        return self.dossier / "_historique_importe.csv"

    def _importes(self) -> dict[date, list[float]]:
        """Lignes importées d'Excel : {date: [9 taux décimaux aux maturités standard]}."""
        try:
            mtime = self._fichier_import.stat().st_mtime
        except FileNotFoundError:
            return {}
        if getattr(self, "_imp_mtime", None) != mtime:
            out = {}
            for l in self._fichier_import.read_text(encoding="utf-8").splitlines()[1:]:
                parts = l.split(";")
                try:
                    out[date.fromisoformat(parts[0])] = [float(x) if x else None for x in parts[1:1 + len(MATURITES)]]
                except ValueError:
                    pass
            self._imp, self._imp_mtime = out, mtime
        return self._imp

    def importer_excel(self, source) -> dict:
        """Importe un historique Excel : 1re colonne = dates, puis une colonne par maturité
        (« 13 Semaines », « 2 Ans », « 10 ans »…), taux en décimal (0,0298) ou en % (2,98)."""
        from .base_titres import _date, _num, lire_xlsx

        lignes = lire_xlsx(source)
        if not lignes:
            raise ValueError("Fichier vide.")
        cols = {}
        for i, h in enumerate(lignes[0]):
            j = _maturite_libelle(h)
            if j is not None:
                cols[j] = i
        manquantes = [lib for lib, j in MATURITES if j not in cols]
        if len(manquantes) == len(MATURITES):
            raise ValueError("Aucune colonne de maturité reconnue (ex. « 13 Semaines », « 2 Ans », « 10 ans »).")
        donnees = dict(self._importes())
        n = 0
        for r in lignes[1:]:
            d = _date(r[0]) if r else None
            if not d:
                continue
            vals = []
            for _, j in MATURITES:
                v = _num(r[cols[j]]) if j in cols and cols[j] < len(r) else None
                vals.append(None if v is None else (v / 100 if v > 0.5 else v))
            if any(v is not None for v in vals):
                donnees[d] = vals
                n += 1
        entete = "date;" + ";".join(lib for lib, _ in MATURITES)
        corps = [f"{d.isoformat()};" + ";".join("" if v is None else repr(v) for v in vals) for d, vals in sorted(donnees.items())]
        self._fichier_import.write_text(entete + "\n" + "\n".join(corps) + "\n", encoding="utf-8")
        return {"lignes": n, "total": len(donnees), "maturites_absentes": manquantes}

    def table(self, depuis=None, jusqu=None) -> list[dict]:
        """Historique complet aux maturités standard : lignes importées (prioritaires) + courbes BAM
        stockées (interpolées). [{date, taux: [9], source}] trié par date."""
        d0 = _parse_date(depuis) if depuis else date.min
        d1 = _parse_date(jusqu) if jusqu else date.max
        imp = self._importes()
        out = {d: {"date": d, "taux": v, "source": "import"} for d, v in imp.items() if d0 <= d <= d1}
        for d in self.dates():
            if d0 <= d <= d1 and d not in out:
                try:
                    out[d] = {"date": d, "taux": self.points_standard(self.courbe(d)), "source": "bkam.ma"}
                except Exception:
                    pass
        return [out[d] for d in sorted(out)]

    def _fichier(self, jour: date) -> Path:
        return self.dossier / f"{jour.isoformat()}.csv"

    @property
    def _fichier_absents(self) -> Path:
        return self.dossier / "_jours_sans_courbe.txt"

    def _absents(self) -> set[date]:
        try:
            return {date.fromisoformat(l.strip()) for l in self._fichier_absents.read_text().splitlines() if l.strip()}
        except FileNotFoundError:
            return set()

    def _noter_absent(self, jour: date) -> None:
        with _verrou, open(self._fichier_absents, "a", encoding="utf-8") as f:
            f.write(jour.isoformat() + "\n")

    def enregistrer(self, texte: str, jour: date) -> None:
        self._fichier(jour).write_text(texte, encoding="utf-8")
        self._cache.pop(jour, None)

    def dates(self) -> list[date]:
        out = []
        for p in self.dossier.glob("????-??-??.csv"):
            try:
                out.append(date.fromisoformat(p.stem))
            except ValueError:
                pass
        return sorted(out)

    def texte(self, jour: date) -> str | None:
        p = self._fichier(jour)
        return p.read_text(encoding="utf-8") if p.exists() else None

    def courbe(self, jour: date) -> CourbeTaux | None:
        if jour not in self._cache:
            t = self.texte(jour)
            if t is None:
                return None
            self._cache[jour] = CourbeTaux.depuis_csv_bam(t, date_courbe=jour)
        return self._cache[jour]

    # ------------------------------------------------------------------ récupération
    def courbe_au_plus_tard(self, jour_voulu, max_recul: int = 10, telecharger: bool = True) -> tuple[CourbeTaux, date]:
        """Dernière courbe publiée à `jour_voulu` ou avant (historique d'abord, sinon bkam.ma)."""
        d = _parse_date(jour_voulu)
        absents, aujourd_hui = self._absents(), date.today()
        for k in range(max_recul + 1):
            j = d - timedelta(days=k)
            if j.weekday() >= 5 or j in absents or j > aujourd_hui:
                continue
            c = self.courbe(j)
            if c is not None:
                return c, j
            if not telecharger:
                continue
            texte = self._telecharger(j)
            if _a_des_taux(texte):
                self.enregistrer(texte, j)
                return self.courbe(j), j
            if j < aujourd_hui:  # aujourd'hui : la courbe peut encore être publiée (15h)
                self._noter_absent(j)
        raise RuntimeError(f"Aucune courbe BAM entre le {d - timedelta(days=max_recul):%d/%m/%Y} et le {d:%d/%m/%Y}.")

    def completer(self, depuis, jusqu=None, progression=None) -> dict:
        """Télécharge toutes les courbes manquantes entre deux dates (jours ouvrés)."""
        d0, d1 = _parse_date(depuis), _parse_date(jusqu or date.today())
        presents, absents = set(self.dates()), self._absents()
        jours = [d0 + timedelta(days=i) for i in range((d1 - d0).days + 1)]
        a_faire = [j for j in jours if j.weekday() < 5 and j not in presents and j not in absents]
        ajoutes = erreurs = 0
        for i, j in enumerate(a_faire, 1):
            try:
                texte = self._telecharger(j)
                if _a_des_taux(texte):
                    self.enregistrer(texte, j)
                    ajoutes += 1
                elif j < date.today():
                    self._noter_absent(j)
            except Exception:
                erreurs += 1
            if progression:
                progression(i, len(a_faire), j)
        return {"a_faire": len(a_faire), "ajoutes": ajoutes, "erreurs": erreurs, "total": len(self.dates())}

    # ------------------------------------------------------------------ analyses
    @staticmethod
    def points_standard(c: CourbeTaux) -> list[float]:
        return [c.taux(j) for _, j in MATURITES]

    def points_au_plus_tard(self, jour_voulu, telecharger: bool = True) -> tuple[list[float], date]:
        """Taux standard de la dernière courbe publiée <= jour_voulu.

        La date est trouvée sur bkam.ma / l'historique stocké ; si cette date figure dans l'historique
        importé (Excel), ce sont les valeurs importées qui sont retenues. Sans réseau, on prend la
        dernière date connue localement (import ou courbe stockée).
        """
        d = _parse_date(jour_voulu)
        imp = self._importes()
        complet = lambda x: x is not None and all(v is not None for v in x)
        if telecharger:
            try:
                c, j = self.courbe_au_plus_tard(d)
                return (imp[j] if complet(imp.get(j)) else self.points_standard(c)), j
            except Exception:
                pass  # pas de réseau : on se rabat sur l'historique local
        connus = [x for x in set(imp) | set(self.dates()) if d - timedelta(days=10) <= x <= d]
        if not connus:
            raise RuntimeError(f"Aucune courbe connue entre le {d - timedelta(days=10):%d/%m/%Y} et le {d:%d/%m/%Y}.")
        j = max(connus)
        return (imp[j] if complet(imp.get(j)) else self.points_standard(self.courbe(j))), j

    def variations(self, jour, telecharger: bool = True) -> dict:
        """Taux aux maturités standard et variations jour / mois / YTD (en points de base)."""
        t0, d0 = self.points_au_plus_tard(jour, telecharger)
        fin_mois_prec = d0.replace(day=1) - timedelta(days=1)
        fin_annee_prec = date(d0.year - 1, 12, 31)
        refs, erreurs = {}, {}
        for cle, voulu in (("jour", d0 - timedelta(days=1)), ("mois", fin_mois_prec), ("ytd", fin_annee_prec)):
            try:
                refs[cle] = self.points_au_plus_tard(voulu, telecharger)
            except Exception as e:
                refs[cle], erreurs[cle] = (None, None), str(e)
        lignes = []
        for i, (lib, j) in enumerate(MATURITES):
            ligne = {"maturite": lib, "jours": j, "base": "monetaire" if j <= 365 else "actuariel", "taux": t0[i]}
            for cle, (pts, _) in refs.items():
                ligne[cle] = None if pts is None or pts[i] is None or t0[i] is None else (t0[i] - pts[i]) * 1e4
            lignes.append(ligne)
        return {
            "date": d0.isoformat(),
            "references": {k: (v[1].isoformat() if v[1] else None) for k, v in refs.items()},
            "erreurs": erreurs,
            "courbes": {"date": t0, **{k: v[0] for k, v in refs.items()}},
            "lignes": lignes,
        }

    def serie(self, jours_maturite: int, depuis=None, jusqu=None) -> list[tuple[str, float]]:
        """Évolution du taux à une maturité standard (en jours) sur tout l'historique."""
        idx = next((k for k, (_, j) in enumerate(MATURITES) if j == int(jours_maturite)), None)
        if idx is None:
            raise ValueError("Maturité non standard.")
        return [(l["date"].isoformat(), l["taux"][idx]) for l in self.table(depuis, jusqu) if l["taux"][idx] is not None]

    def export_csv(self, depuis=None, jusqu=None) -> str:
        """Tableau date x maturités standard (taux en %), séparateur ; et virgule décimale."""
        lignes = ["Date;" + ";".join(lib for lib, _ in MATURITES)]
        for l in self.table(depuis, jusqu):
            lignes.append(f"{l['date']:%d/%m/%Y};" + ";".join("" if t is None else f"{t * 100:.3f}".replace(".", ",") for t in l["taux"]))
        return "\n".join(lignes) + "\n"

    def export_xlsx(self, depuis=None, jusqu=None, mode: str = "taux") -> bytes:
        """Excel : dates en lignes, maturités en colonnes. mode 'taux' (0,000 %) ou 'variation' (pb vs veille)."""
        from .xlsx import ecrire_xlsx

        table = self.table(depuis, jusqu)
        entetes = ["Date"] + [lib.replace("sem.", "Semaines") for lib, _ in MATURITES]
        if mode == "variation":
            lignes, prec = [], None
            for l in table:
                if prec is not None:
                    lignes.append([l["date"]] + [None if a is None or b is None else round((a - b) * 1e4, 2) for a, b in zip(l["taux"], prec)])
                prec = l["taux"]
            return ecrire_xlsx(entetes, lignes, ["date"] + ["pb"] * len(MATURITES), "Variations (pb)", [12] + [11] * len(MATURITES))
        lignes = [[l["date"]] + l["taux"] for l in table]
        return ecrire_xlsx(entetes, lignes, ["date"] + ["pct"] * len(MATURITES), "Historique courbe BAM", [12] + [11] * len(MATURITES))


def _maturite_libelle(h) -> int | None:
    """« 13 Semaines » -> 91, « 2 Ans » -> 730, « 10 ans » -> 3650 (maturités standard seulement)."""
    m = re.match(r"\s*(\d+)\s*([a-zA-Zé]+)", str(h or ""))
    if not m:
        return None
    n, u = int(m.group(1)), m.group(2).lower()
    jours = 7 * n if u.startswith("s") else 365 * n if u.startswith("a") else round(n * 365 / 12) if u.startswith("m") else None
    if jours is None:
        return None
    standard = {91: 91, 182: 182, 364: 364}
    if u.startswith("s"):
        return standard.get(jours)
    return jours if any(j == jours for _, j in MATURITES) else None

if __name__ == "__main__":  # python -m pricer_obligataire.historique 2026-10-05
    import sys

    h = Historique()
    v = h.variations(sys.argv[1] if len(sys.argv) > 1 else date.today())
    print(f"Courbe du {v['date']}  |  réf. J-1 {v['references']['jour']}  mois {v['references']['mois']}  YTD {v['references']['ytd']}")
    for l in v["lignes"]:
        f = lambda x: "   n.d." if x is None else f"{x:+7.1f}"
        print(f"{l['maturite']:>8}  {l['taux'] * 100:6.3f} %   jour {f(l['jour'])}  mois {f(l['mois'])}  YTD {f(l['ytd'])} pb")
