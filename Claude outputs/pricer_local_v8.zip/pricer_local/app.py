"""Pricer obligataire — serveur local.

Lance l'interface web du pricer sur http://localhost:8765 et l'ouvre dans le navigateur.
La base de titres est relue depuis data/Base Titres.xlsx à chaque chargement de la page :
il suffit de remplacer ce fichier puis d'actualiser la page (F5).

Usage :  python app.py                     (port 8765, ouvre le navigateur)
         python app.py --port 9000 --base "D:\\Titres\\base.xlsx" --sans-navigateur
Aucune dépendance externe : Python 3.10+ suffit.
"""
from __future__ import annotations

import argparse
import json
import threading
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from pricer_obligataire.historique import MATURITES, Historique
from pricer_obligataire.base_titres import base_pour_page, charger_base

ICI = Path(__file__).resolve().parent
PAGE = ICI / "web" / "index.html"
_cache: dict = {"mtime": None, "chemin": None, "base": [], "erreur": ""}
HIST = Historique(ICI / "data" / "historique_courbes")
PROGRES: dict = {"en_cours": False}


def _completer(depuis: str):
    """Complète l'historique en tâche de fond (suivi via /api/historique/info)."""
    PROGRES.clear()
    PROGRES.update(en_cours=True, fait=0, total=0, jour=None, message="")
    try:
        r = HIST.completer(depuis, progression=lambda i, n, j: PROGRES.update(fait=i, total=n, jour=j.isoformat()))
        PROGRES.update(message=f"{r['ajoutes']} courbes ajoutées, {r['total']} en historique"
                       + (f" ({r['erreurs']} erreurs réseau)" if r["erreurs"] else ""))
    except Exception as e:
        PROGRES.update(message=f"Erreur : {e}")
    finally:
        PROGRES["en_cours"] = False


def lire_base(chemin: Path):
    """Charge la base (avec cache tant que le fichier n'a pas changé)."""
    try:
        mtime = chemin.stat().st_mtime
    except FileNotFoundError:
        return [], f"fichier introuvable ({chemin})", ""
    if _cache["mtime"] != mtime or _cache["chemin"] != chemin:
        try:
            _cache.update(base=charger_base(chemin), erreur="")
        except Exception as e:  # fichier ouvert dans Excel, colonnes manquantes…
            _cache.update(base=[], erreur=str(e))
        _cache.update(mtime=mtime, chemin=chemin)
    maj = datetime.fromtimestamp(mtime).strftime("%d/%m/%Y %H:%M")
    return _cache["base"], _cache["erreur"], maj


def fabriquer_handler(chemin_base: Path):
    class Handler(BaseHTTPRequestHandler):
        def _envoyer(self, code: int, corps: bytes, type_: str):
            self.send_response(code)
            self.send_header("Content-Type", type_)
            self.send_header("Content-Length", str(len(corps)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(corps)

        def do_GET(self):
            chemin = self.path.split("?")[0]
            if chemin in ("/", "/index.html"):
                base, erreur, maj = lire_base(chemin_base)
                info = {"fichier": chemin_base.name, "maj": maj, "erreur": erreur}
                html = PAGE.read_text(encoding="utf-8")
                html = html.replace("/*__BASE_TITRES__*/[]", json.dumps(base_pour_page(base), ensure_ascii=False))
                html = html.replace('/*__BASE_INFO__*/{"fichier":"","maj":"","erreur":""}', json.dumps(info, ensure_ascii=False))
                self._envoyer(200, html.encode("utf-8"), "text/html; charset=utf-8")
            elif chemin == "/api/titres":
                base, erreur, maj = lire_base(chemin_base)
                corps = json.dumps({"titres": base, "erreur": erreur, "maj": maj}, ensure_ascii=False).encode("utf-8")
                self._envoyer(200, corps, "application/json; charset=utf-8")
            elif chemin.startswith("/api/"):
                self._api(chemin)
            else:
                self._envoyer(404, "Page introuvable".encode("utf-8"), "text/plain; charset=utf-8")

        def _json(self, obj):
            self._envoyer(200, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        def _api(self, chemin):
            from urllib.parse import parse_qs, urlparse

            q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
            aujourd_hui = datetime.now().strftime("%Y-%m-%d")
            try:
                if chemin == "/api/courbe_bam":  # courbe du jour (historique local, sinon bkam.ma)
                    _, jour = HIST.courbe_au_plus_tard(q.get("date") or aujourd_hui)
                    self._json({"ok": True, "date": jour.isoformat(), "texte": HIST.texte(jour)})
                elif chemin == "/api/variations":
                    self._json({"ok": True, **HIST.variations(q.get("date") or aujourd_hui)})
                elif chemin == "/api/serie":
                    self._json({"ok": True, "serie": HIST.serie(int(q.get("jours", 3650)), q.get("depuis"), q.get("jusqu"))})
                elif chemin == "/api/historique/info":
                    ds = HIST.dates()
                    self._json({"ok": True, "nb": len(ds), "premiere": ds[0].isoformat() if ds else None,
                                "derniere": ds[-1].isoformat() if ds else None, "progression": PROGRES})
                elif chemin == "/api/historique/completer":
                    if not PROGRES.get("en_cours"):
                        depuis = q.get("depuis") or f"{datetime.now().year - 1}-01-01"
                        threading.Thread(target=_completer, args=(depuis,), daemon=True).start()
                    self._json({"ok": True, "progression": PROGRES})
                elif chemin == "/api/historique/table":
                    lignes = HIST.table(q.get("depuis"), q.get("jusqu"))
                    self._json({"ok": True, "maturites": [m for m, _ in MATURITES],
                                "lignes": [[l["date"].isoformat(), l["taux"], l["source"]] for l in lignes]})
                elif chemin == "/api/historique/export.xlsx":
                    mode = q.get("mode", "taux")
                    corps = HIST.export_xlsx(q.get("depuis"), q.get("jusqu"), mode)
                    nom = f"historique_courbe_bam{'_variations' if mode == 'variation' else ''}_{datetime.now():%Y%m%d}.xlsx"
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    self.send_header("Content-Disposition", f'attachment; filename="{nom}"')
                    self.send_header("Content-Length", str(len(corps)))
                    self.end_headers()
                    self.wfile.write(corps)
                elif chemin == "/api/historique/export.csv":
                    corps = HIST.export_csv().encode("utf-8-sig")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/csv; charset=utf-8")
                    self.send_header("Content-Disposition", 'attachment; filename="historique_courbe_bam.csv"')
                    self.send_header("Content-Length", str(len(corps)))
                    self.end_headers()
                    self.wfile.write(corps)
                else:
                    self._envoyer(404, b"API inconnue", "text/plain; charset=utf-8")
            except Exception as e:  # pas d'Internet, proxy, site indisponible, aucune courbe…
                self._json({"ok": False, "erreur": str(e) or e.__class__.__name__})

        def do_POST(self):
            chemin = self.path.split("?")[0]
            if chemin != "/api/historique/import":
                self._envoyer(404, b"API inconnue", "text/plain; charset=utf-8")
                return
            try:
                import io

                taille = int(self.headers.get("Content-Length") or 0)
                if not taille or taille > 20_000_000:
                    raise ValueError("Fichier vide ou trop volumineux.")
                r = HIST.importer_excel(io.BytesIO(self.rfile.read(taille)))
                self._json({"ok": True, **r})
            except Exception as e:
                self._json({"ok": False, "erreur": f"Import impossible : {e}"})

        def log_message(self, fmt, *args):  # console silencieuse
            pass

    return Handler


def main():
    p = argparse.ArgumentParser(description="Pricer obligataire — serveur local")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--base", default=str(ICI / "data" / "Base Titres.xlsx"), help="chemin du fichier Excel des titres")
    p.add_argument("--sans-navigateur", action="store_true", help="ne pas ouvrir le navigateur")
    a = p.parse_args()

    chemin_base = Path(a.base).expanduser().resolve()
    base, erreur, _ = lire_base(chemin_base)
    print(f"Base de titres : {len(base)} titres ({chemin_base})" if not erreur else f"Attention : {erreur}")

    url = f"http://localhost:{a.port}"
    try:
        serveur = ThreadingHTTPServer(("127.0.0.1", a.port), fabriquer_handler(chemin_base))
    except OSError:
        # Port déjà pris : le pricer tourne déjà (autre fenêtre, VS Code…) -> on ouvre simplement la page.
        print(f"Le pricer est déjà lancé : ouverture de {url}")
        if not a.sans_navigateur:
            webbrowser.open(url)
        return
    print(f"Pricer disponible sur {url}  —  Ctrl+C pour arrêter")
    if not a.sans_navigateur:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du pricer.")
        serveur.server_close()


if __name__ == "__main__":
    main()
