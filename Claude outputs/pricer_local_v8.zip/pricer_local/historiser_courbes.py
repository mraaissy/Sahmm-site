"""Constitue / complète l'historique des courbes BAM (data/historique_courbes).

Exemples :
  python historiser_courbes.py                       (complète depuis le 01/01 de l'année précédente)
  python historiser_courbes.py --depuis 2024-01-01   (historique plus long)
  python historiser_courbes.py --variations          (affiche les variations du jour)
  python historiser_courbes.py --export historique_courbes.csv

À planifier chaque jour après 15h30 (Planificateur de tâches Windows) pour garder l'historique à jour.
"""
from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from pricer_obligataire.historique import MATURITES, Historique


def main():
    p = argparse.ArgumentParser(description="Historique de la courbe des taux BAM")
    p.add_argument("--depuis", default=f"{date.today().year - 1}-01-01", help="date de début AAAA-MM-JJ")
    p.add_argument("--jusqu", default=None, help="date de fin AAAA-MM-JJ (défaut : aujourd'hui)")
    p.add_argument("--variations", action="store_true", help="affiche seulement les variations du jour")
    p.add_argument("--export", help="exporte l'historique (maturités standard) dans ce fichier CSV")
    a = p.parse_args()
    h = Historique()

    if not a.variations and not a.export:
        def prog(i, n, j):
            print(f"\r  {i}/{n}  {j:%d/%m/%Y}", end="", flush=True)
        r = h.completer(a.depuis, a.jusqu, prog)
        print(f"\n{r['ajoutes']} courbes ajoutées ({r['erreurs']} erreurs) — {r['total']} courbes en historique.")

    if a.export:
        Path(a.export).write_text(h.export_csv(), encoding="utf-8-sig")
        print(f"Historique exporté dans {Path(a.export).resolve()}")

    v = h.variations(date.today())
    ref = v["references"]
    print(f"\nCourbe du {v['date']}  (J-1 : {ref['jour']}, fin de mois : {ref['mois']}, fin d'année : {ref['ytd']})")
    f = lambda x: "    n.d." if x is None else f"{x:+8.1f}"
    print(f"{'Maturité':>9} {'Taux':>8} {'Jour':>8} {'Mois':>8} {'YTD':>8}   (pb)")
    for l in v["lignes"]:
        print(f"{l['maturite']:>9} {l['taux'] * 100:7.3f}% {f(l['jour'])} {f(l['mois'])} {f(l['ytd'])}")


if __name__ == "__main__":
    main()
