import React, { useState, useRef, useEffect } from "react";
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Search, Bell, Settings, User, Menu, X, Star, Download, ArrowUpDown, Eye, EyeOff } from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar } from "recharts";
import { supabase } from "./supabaseClient";


const hausses = [
  { code: "IAM", nom: "Maroc Telecom", var: 4.2, cours: "92.20" },
  { code: "LHM", nom: "LafargeHolcim Maroc", var: 3.1, cours: "2 480.00" },
  { code: "CIH", nom: "CIH Bank", var: 2.8, cours: "398.50" },
  { code: "ADH", nom: "Douja Prom Addoha", var: 2.3, cours: "9.87" },
  { code: "TQM", nom: "Taqa Morocco", var: 1.9, cours: "1 042.00" },
];

const baisses = [
  { code: "CMA", nom: "Ciments du Maroc", var: -3.5, cours: "1 659.00" },
  { code: "SNA", nom: "Snep", var: -2.9, cours: "845.00" },
  { code: "RIS", nom: "Risma", var: -2.1, cours: "142.00" },
  { code: "DHO", nom: "Dari Couspate", var: -1.8, cours: "410.00" },
  { code: "MNG", nom: "Managem", var: -1.4, cours: "2 960.00" },
];

const ticker = [
  { code: "IAM", var: 4.2 }, { code: "ATW", var: 0.6 }, { code: "BCP", var: -0.3 },
  { code: "CMA", var: -3.5 }, { code: "LHM", var: 3.1 }, { code: "MNG", var: -1.4 },
  { code: "TQM", var: 1.9 }, { code: "CIH", var: 2.8 }, { code: "ADH", var: 2.3 },
  { code: "SNA", var: -2.9 }, { code: "RIS", var: -2.1 }, { code: "DHO", var: -1.8 },
];

// Top 5 des OPCVM par catégorie — données de secours (utilisées uniquement si le
// robot GitHub Actions n'a pas encore pu récupérer les données live). La source
// réelle et actualisée toutes les 15 min est l'ASFIM (fundshare.asfim.ma).
const opcvmSourceDate = "16 juillet 2026";
const opcvmFunds = {
  Actions: [
    { nom: "AD CAPITAL MULTISTRATEGIE", code: "MA0000300048", valeur: "1 001,68", jour: 0.26, m1: 0.71, m3: 0.00, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "DAILY EQUITY FUND", code: "MA0000038820", valeur: "1 318,35", jour: -0.03, m1: -5.01, m3: -5.54, m6: -14.43, a1: -14.44, a2: 18.18, a5: 26.76 },
    { nom: "TWIN PERFORMANCE", code: "MA0000039927", valeur: "97,82", jour: -0.06, m1: -2.97, m3: -3.17, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "CMR ASHOUM", code: "MA0000041113", valeur: "2 684,73", jour: -0.18, m1: -3.85, m3: -5.00, m6: -12.16, a1: -12.05, a2: 27.46, a5: 51.10 },
    { nom: "WG VALEURS", code: "MA0000039059", valeur: "1 522,70", jour: -0.19, m1: -2.25, m3: -1.48, m6: -1.32, a1: 4.49, a2: 45.00, a5: 0.00 },
  ],
  "Diversifié": [
    { nom: "FCP STERLING DYNAMIC", code: "MA0000039950", valeur: "982,32", jour: 0.03, m1: -0.71, m3: 0.00, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "AFG ALLOCATION FUND", code: "MA0000039968", valeur: "1 008,70", jour: 0.02, m1: 0.54, m3: 0.00, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "CFG OPPORTUNITÉS", code: "MA0000039315", valeur: "1 240,00", jour: 0.01, m1: -2.45, m3: 0.53, m6: 0.15, a1: 1.09, a2: 0.00, a5: 0.00 },
    { nom: "FCP QUANTUM OPTIMUM DIVERSIFIE", code: "MA0000039984", valeur: "1 017,47", jour: 0.00, m1: -0.43, m3: 0.76, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "UPLINE CROISSANCE", code: "MA0000039331", valeur: "1 092,40", jour: -0.01, m1: 0.05, m3: -0.01, m6: -1.73, a1: -1.28, a2: 5.33, a5: 0.00 },
  ],
  OMLT: [
    { nom: "FCP EMERGENCE OBLIHORIZON", code: "MA0000038770", valeur: "1 153,10", jour: 0.42, m1: 0.70, m3: 0.72, m6: -0.29, a1: -0.66, a2: 9.13, a5: 11.60 },
    { nom: "AD CAPITAL OBLIGATAIRE PLUS", code: "MA0000300055", valeur: "1 004,68", jour: 0.26, m1: 0.87, m3: 0.00, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "AD CAPITAL DYNAMIC BOND", code: "MA0000300030", valeur: "1 004,24", jour: 0.26, m1: 0.85, m3: 0.00, m6: 0.00, a1: 0.00, a2: 0.00, a5: 0.00 },
    { nom: "UPLINE OBLIG PLUS", code: "MA0000037376", valeur: "1 804,33", jour: 0.17, m1: 0.53, m3: 0.97, m6: 1.33, a1: 1.64, a2: 10.17, a5: 18.63 },
    { nom: "UNIVERS OBLIGATIONS", code: "MA0000042368", valeur: "1 906,44", jour: 0.16, m1: -0.14, m3: -1.09, m6: 0.07, a1: 2.76, a2: 8.99, a5: 18.63 },
  ],
  OCT: [
    { nom: "CDG OBLIG SÉCURITÉ", code: "MA0000041154", valeur: "1 705,16", jour: 0.02, m1: 0.34, m3: 0.88, m6: 1.55, a1: 2.61, a2: 6.11, a5: 14.28 },
    { nom: "CDG DYNAMIC COURT TERME", code: "MA0000040594", valeur: "1 196,45", jour: 0.02, m1: 0.34, m3: 0.89, m6: 1.46, a1: 2.48, a2: 6.41, a5: 14.56 },
    { nom: "FCP CAM TRESO PLUS", code: "MA0000036352", valeur: "174,25", jour: 0.02, m1: 0.32, m3: 0.86, m6: 1.56, a1: 2.67, a2: 6.46, a5: 15.11 },
    { nom: "TWIN TREASURY", code: "MA0000038655", valeur: "1 185,72", jour: 0.02, m1: 0.34, m3: 0.94, m6: 1.65, a1: 2.69, a2: 7.02, a5: 15.71 },
    { nom: "AFRICAPITAL CASH", code: "MA0000036873", valeur: "1 597,88", jour: 0.01, m1: 0.28, m3: 0.78, m6: 1.35, a1: 2.30, a2: 5.99, a5: 14.33 },
  ],
  "Monétaire": [
    { nom: "FCP MONETAIRE DYNAMIQUE", code: "MA0000038945", valeur: "1 115,85", jour: 0.01, m1: 0.23, m3: 0.62, m6: 1.16, a1: 2.19, a2: 4.72, a5: 0.00 },
    { nom: "RMA TRESO PLUS", code: "MA0000041097", valeur: "102,86", jour: 0.01, m1: 0.21, m3: 0.61, m6: 3.82, a1: 4.91, a2: 10.76, a5: 32.62 },
    { nom: "BMCI MONETAIRE PLUS", code: "MA0000041899", valeur: "145 931,46", jour: 0.01, m1: 0.24, m3: 0.70, m6: 1.36, a1: 2.57, a2: 5.41, a5: 11.49 },
    { nom: "INSTIMONETAIRE", code: "MA0000036477", valeur: "139,87", jour: 0.01, m1: 0.16, m3: 1.08, m6: 1.88, a1: 4.12, a2: 7.87, a5: 11.28 },
    { nom: "AXA MONETAIRE", code: "MA0000037046", valeur: "159 560,84", jour: 0.01, m1: 0.20, m3: 0.61, m6: 1.17, a1: 2.18, a2: 4.93, a5: 12.07 },
  ],
  Contractuel: [
    { nom: "CAPITAL IMTIYAZ GARANTI", code: "MA0000039497", valeur: "1 058,43", jour: 0.01, m1: 0.17, m3: 0.52, m6: 1.04, a1: 2.11, a2: 4.53, a5: 0.00 },
    { nom: "UPLINE CAPITAL GARANTI", code: "MA0000037350", valeur: "13 204,47", jour: 0.01, m1: 0.16, m3: 0.50, m6: 1.00, a1: 2.04, a2: 4.40, a5: 10.72 },
    { nom: "HORIZON CAPITAL GARANTI", code: "MA0000041691", valeur: "142 591,16", jour: 0.01, m1: 0.14, m3: 0.45, m6: 0.93, a1: 1.93, a2: 4.20, a5: 10.35 },
    { nom: "FCP CKG GARANTI", code: "MA0000042228", valeur: "1 066,20", jour: 0.00, m1: 0.16, m3: 0.51, m6: 1.02, a1: 2.03, a2: 4.24, a5: 0.00 },
    { nom: "ATTIJARI CASH GARANTI", code: "MA0000042145", valeur: "1 088,41", jour: 0.00, m1: 0.16, m3: 0.48, m6: 0.97, a1: 1.98, a2: 4.26, a5: 0.00 },
  ],
};
const opcvmCategoryList = Object.keys(opcvmFunds);

// Statut du marché — calculé à partir des horaires réels de cotation de la Bourse
// de Casablanca : séance continue du lundi au vendredi, 9h30–15h30, heure de Casablanca.
// (source : AMMC, "Modalités pratiques d'une séance boursière")
// Limite assumée : ne tient pas compte du calendrier des jours fériés marocains,
// qui n'est pas disponible via une source accessible automatiquement.
// Détail de la séance boursière — données réelles de clôture
// Jours fériés marocains (Bourse de Casablanca fermée) — dates civiles fixes +
// dates religieuses estimées (calendrier lunaire, confirmées par le Ministère
// des Habous à l'approche de chaque fête ; à ajuster de +/-1 jour si besoin).
const MOROCCO_HOLIDAYS_2026 = [
  "2026-01-01", // Nouvel An
  "2026-01-11", // Manifeste de l'Indépendance
  "2026-01-14", // Nouvel An Amazigh (Yennayer)
  "2026-03-20", // Aïd al-Fitr (1er jour, estimé)
  "2026-03-21", // Aïd al-Fitr (2e jour, estimé)
  "2026-05-01", // Fête du Travail
  "2026-05-27", // Aïd al-Adha (1er jour, estimé)
  "2026-05-28", // Aïd al-Adha (2e jour, estimé)
  "2026-06-17", // 1er Moharram — Nouvel An Hégirien (estimé)
  "2026-07-30", // Fête du Trône
  "2026-08-14", // Récupération Oued Ed-Dahab
  "2026-08-20", // Révolution du Roi et du Peuple
  "2026-08-21", // Fête de la Jeunesse
  "2026-08-26", // Aïd Al Mawlid Annabaoui (estimé)
  "2026-10-31", // Aïd Al Wahda (Fête de l'Unité)
  "2026-11-06", // Anniversaire de la Marche Verte
  "2026-11-18", // Fête de l'Indépendance
];

// Calcule le libellé de la dernière séance de cotation réelle (saute les
// week-ends et jours fériés marocains) au lieu d'afficher bêtement la date du jour.
function getLastTradingDayLabel() {
  const d = new Date();
  for (let i = 0; i < 14; i++) {
    const iso = d.toISOString().slice(0, 10);
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    if (!isWeekend && !MOROCCO_HOLIDAYS_2026.includes(iso)) {
      return d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    }
    d.setDate(d.getDate() - 1);
  }
  return new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

// (source : Médias24 et Boursenews, relayant les chiffres officiels de la Bourse de
// Casablanca — le site casablanca-bourse.com bloquant l'accès automatisé, ces médias
// financiers qui reprennent ses publications officielles sont la source la plus fiable
// accessible) — séance du mardi 7 juillet 2026
const seanceDate = getLastTradingDayLabel();
const seanceIndices = [
  { nom: "MASI", valeur: "18 710,31", var: 1.04, ytd: -0.72 },
  { nom: "MASI ESG", valeur: "1 392,35", var: 1.24, ytd: 11.25 },
  { nom: "MASI 20", valeur: "1 352,72", var: 1.06, ytd: -8.95 },
];
const seanceStats = {
  capitalisation: "1 100,30 MMDH",
  volume: "546,26 MDH",
  volumeCentral: "546,26 MDH",
  volumeBlocs: "0 MDH (aucun échange sur le marché de blocs)",
  hausses: null,
  baisses: null,
  inchangees: null,
};

// Dernière séance CLOTUREE — figé volontairement, ne bouge pas avec les
// données intrajournalières (seanceIndices/seanceStats/palmares ci-dessus,
// qui eux restent en direct). À mettre à jour une fois par jour, en fin de
// séance, avec les vrais chiffres de clôture transmis manuellement.
const derniereCloture = {
  date: "3 septembre 2026",
  masiValeur: "18 710,31",
  masiVar: 1.04,
  volume: "546,26 MDH",
  meilleureHausse: { nom: "AGMA", var: 5.99 },
  plusForteBaisse: { nom: "IB MAROC.COM", var: -7.55 },
  topActifs: [
    { nom: "Maroc Telecom", volume: 75.90 },
    { nom: "CFG Bank", volume: 45.20 },
    { nom: "Label Vie", volume: 43.36 },
  ],
  topActifsUnite: " MDH",
};

// Fil d'actualité — "The Morning Brief". Chaque entrée est transmise
// manuellement (texte complet) et affichée en un seul bloc, du plus récent
// au plus ancien. Le premier élément du tableau est le plus récent.
const morningBriefs = [
  {
    date: "2026-09-11",
    pdfUrl: "/assets/briefs/2026-09-11.pdf",
    dateLabel: "11/09/2026",
    titre: "Wall Street enchaîne une 4e séance de baisse, le pétrole au plus haut depuis mai",
    resumeCourt:
      "Wall Street a clôturé en baisse pour une 4e séance consécutive jeudi, sa plus longue série de repli depuis début mars, tandis que le pétrole a atteint ses plus hauts niveaux depuis le 19 mai sur fond de guerre Iran-USA prolongée. La BCE a relevé ses taux directeurs de 25 pb face à une inflation en zone euro remontée à 3,3%, et le rendement du 10 ans américain a grimpé à 4,95%. À Casablanca, le MASI a cédé 0,27% jeudi à 18.785,4 points, la Sylviculture et Papier ayant le plus pesé sur l'indice. Au menu du jour : le CPI américain d'août à 14h30, test décisif avant la réunion de la Fed des 15-16 septembre.",
    sections: [
      {
        titre: "CONTEXTE OVERNIGHT",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street enchaîne une 4e séance de baisse",
            texte:
              "Wall Street a clôturé en baisse pour la 4e séance consécutive jeudi (Dow -0,6%, S&P -0,6%, Nasdaq -0,7%), sa plus longue série de repli depuis début mars.",
          },
          {
            tag: "ÉNERGIE | PÉTROLE",
            titre: "Le pétrole au plus haut depuis le 19 mai",
            texte:
              "Le WTI et le Brent ont clôturé à leurs plus hauts niveaux depuis le 19 mai (102,48$ et 107,63$), sur fond de guerre Iran-USA prolongée.",
          },
          {
            tag: "EUROPE | BCE",
            titre: "La BCE relève ses taux directeurs de 25 pb",
            texte:
              "La BCE a relevé ses taux directeurs de 25 pb jeudi, portant le taux de dépôt à 2,50% (2e hausse de l'année), face à une inflation en zone euro remontée à 3,3%.",
          },
          {
            tag: "USA | TAUX",
            titre: "Le 10 ans américain atteint 4,95%",
            texte:
              "Le rendement des bons du Trésor américain à 10 ans a atteint 4,95%, en hausse de près d'un point depuis le début du conflit.",
          },
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI recule pour une 2e séance consécutive",
            texte:
              "La Bourse de Casablanca a clôturé en baisse pour une 2e séance consécutive jeudi (-0,27% à 18.785,4 points), la Sylviculture et Papier ayant le plus pesé sur l'indice.",
          },
        ],
      },
      {
        titre: "OUVERTURE DES MARCHÉS",
        items: [
          {
            tag: "MATIÈRES PREMIÈRES | OR",
            titre: "L'or se replie légèrement à 4.374 $/oz",
            texte:
              "L'once d'or évolue autour de 4.374 $/oz (-0,5%), en léger repli après le rapport PPI.",
          },
          {
            tag: "MATIÈRES PREMIÈRES | ARGENT",
            titre: "L'argent se replie après le rallye de la veille",
            texte:
              "L'once d'argent évolue autour de 65,3 $/oz, en repli après le fort rallye de la veille.",
          },
          {
            tag: "MATIÈRES PREMIÈRES | CUIVRE",
            titre: "Le cuivre proche de son record historique",
            texte:
              "Le cuivre (LME) s'échange autour de 14.617 $/tonne, proche de son record historique (+15% YTD), dans un contexte de pénurie physique de stocks.",
          },
          {
            tag: "EUROPE | FUTURES",
            titre: "Ouverture prudente attendue en Europe",
            texte:
              "Les futures européens évoluent en légère hausse (CAC 40 +0,29% à 8.146 pts, DAX +0,10% à 25.442 pts, Eurostoxx 50 +0,25% à 6.294 pts), une ouverture prudente étant attendue.",
          },
        ],
      },
      {
        titre: "À SUIVRE AUJOURD'HUI",
        items: [
          {
            tag: "USA | INFLATION",
            titre: "CPI américain d'août à 14h30",
            texte:
              "Le CPI américain d'août (consensus 3,4% sur un an) sera publié à 14h30, un test décisif avant la réunion de la Fed des 15-16 septembre.",
          },
          {
            tag: "GÉOPOLITIQUE | IRAN-USA",
            titre: "La guerre Iran-USA à surveiller en continu",
            texte:
              "La suite de la guerre Iran-USA et son impact sur le pétrole restent à surveiller en continu.",
          },
          {
            tag: "USA | FED",
            titre: "Réunion de la Fed les 15-16 septembre",
            texte:
              "La réunion de la Fed les 15-16 septembre et la poursuite de la désinflation en zone euro post-BCE seront à suivre cette semaine.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-09-04",
    pdfUrl: "/assets/briefs/2026-09-04.pdf",
    dateLabel: "04/09/2026",
    titre: "Le MASI rebondit de 1,04% et dépasse les 18.700 points",
    resumeCourt:
      "Le MASI rebondit de 1,04% jeudi à 18 710,31 points, effaçant une bonne partie du recul de la veille, porté par la Sylviculture et Papier (+4,08%), AGMA (+5,99%) et Med Paper (+4,08%). Auto Hall boucle son augmentation de capital de 250 MDH. Wall Street signe sa meilleure séance depuis le 4 août après des propos rassurants du gouverneur de la Fed Christopher Waller sur l'inflation, tandis que les marchés asiatiques évoluent en ordre dispersé.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI rebondit de 1,04% et dépasse les 18.700 points",
            texte:
              "La Bourse de Casablanca a clôturé la séance de jeudi sur une note nettement positive, portée par un regain des achats sur plusieurs compartiments de la cote. Le MASI a gagné 1,04% pour terminer à 18.710,31 points, effaçant une bonne partie du recul de la veille, et le MASI 20 a progressé de 1,06% à 1.352,72 points. La capitalisation boursière globale s'établit à 1.100,3 milliards de dirhams, pour un volume d'échanges de 546,3 MDH. Sur le plan sectoriel, la Sylviculture et Papier s'est distinguée avec une progression de 4,08%, la meilleure performance de la journée. Parmi les valeurs les plus recherchées, AGMA a bondi de 5,99% à 7.080 DH, Med Paper a avancé de 4,08% à 25,5 DH et CFG Bank a complété le podium avec un gain de 3,40% à 209,9 DH.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | AUTO HALL",
            titre: "Augmentation de capital de 250 MDH bouclée",
            texte:
              "La Bourse de Casablanca a annoncé jeudi les résultats de l'opération d'augmentation de capital en numéraire d'Auto Hall, portant sur un montant global de 249,99 MDH. À l'issue de cette opération, le capital social de la société passe de 502,95 MDH (50.294.528 titres) à 541,4 MDH, réparti sur 54.140.578 titres. Décidée par l'assemblée générale extraordinaire du 21 mai 2026, l'opération portait sur l'émission de 3.846.050 actions nouvelles d'une valeur nominale de 10 DH, au prix d'émission de 65 DH, par souscription en numéraire avec droit préférentiel réservé aux actionnaires. La période de souscription s'est déroulée du 27 juillet au 17 août 2026.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street signe sa meilleure séance depuis le 4 août, portée par la Fed",
            texte:
              "La Bourse de New York a connu jeudi sa meilleure séance depuis le 4 août, après que le gouverneur de la Fed Christopher Waller a estimé que l'inflation montrait des signes encourageants de ralentissement et qu'il pourrait soutenir un statu quo sur les taux lors de la réunion de septembre, si les prochaines données confirment cette tendance. Le Dow Jones a bondi de 624 points (+1,14%) à 53.666 points, le S&P 500 a gagné 1,1% et le Nasdaq Composite 1,2%, porté par les valeurs technologiques dans le sillage du recul des rendements obligataires. Cette annonce a fait chuter la probabilité d'une hausse des taux en septembre, désormais estimée à environ 50% par le marché contre près de 63% la veille. L'actualité a également été marquée par l'acquisition de Hugging Face par Nvidia pour 13 milliards de dollars, confirmant la poursuite de la course aux investissements dans l'intelligence artificielle. Les investisseurs se tournent désormais vers le rapport officiel sur l'emploi américain (NFP), attendu vendredi avant le week-end prolongé du Labor Day.",
          },
          {
            tag: "ASIE | NIKKEI",
            titre: "Les marchés asiatiques évoluent en ordre dispersé",
            texte:
              "En Asie, le Nikkei japonais a reculé de 111 points à 64.214 points, tandis que l'indice de Shanghai est resté quasiment stable autour de 3.942 points et que le Hang Seng de Hong Kong a cédé 97 points à 25.213 points. Le yen s'est par ailleurs apprécié d'environ 2% face au dollar, mettant fin à une glissade de près de 3% sur deux séances déclenchée par des propos plus fermes d'un membre du conseil de la Banque du Japon.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-09-03",
    pdfUrl: "/assets/briefs/2026-09-03.pdf",
    dateLabel: "03/09/2026",
    titre: "Le MASI recule, la pharmacie résiste",
    resumeCourt:
      "Le MASI cède 0,34% mercredi à 18 517,79 points, une quatrième séance de repli sur les cinq dernières, Wafa Assurance signant la plus forte baisse (-9,47%) tandis que l'Industrie pharmaceutique se distingue (+5,46%). Wall Street rebondit, portée par les grandes valeurs technologiques et Nvidia (+3%), mettant fin à trois séances de baisse, tandis que le rapport ADP confirme un ralentissement du marché du travail américain avant le NFP de vendredi.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI recule, la pharmacie résiste",
            texte:
              "La Bourse de Casablanca a achevé la séance de mercredi sur une note négative, le MASI cédant 0,34% à 18.517,79 points, une quatrième séance de repli sur les cinq dernières. Le MASI 20 a reculé de 0,37% à 1.338,47 points, pour une capitalisation boursière globale de 1.088,1 milliards de dirhams et un volume d'échanges de 140 MDH. La plus forte correction sectorielle a concerné la Sylviculture et le papier (-5,48%), tandis que Wafa Assurance a signé la plus forte baisse individuelle de la séance (-9,47% à 4.980 DH), devant Med Paper (-5,48% à 24,5 DH) et CIH (-3,09% à 337 DH). À l'inverse, l'Industrie pharmaceutique s'est distinguée avec une progression de 5,46%, la meilleure performance sectorielle de la journée.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street rebondit, stoppant trois séances de baisse",
            texte:
              "La Bourse de New York a signé mercredi sa meilleure séance de la semaine, mettant fin à une série de trois séances consécutives de baisse. Le Dow Jones a gagné 0,56% (+295,07 points) à 53.061,95 points, le S&P 500 a progressé de 0,46% à 7.666,60 points et le Nasdaq Composite a avancé de 0,45% à 26.217,83 points. Ce rebond a été porté par les grandes valeurs technologiques, Nvidia bondissant de plus de 3%, tandis que les rendements obligataires marquaient une pause après leur récente flambée : le taux à 10 ans, qui avait touché mercredi un plus haut depuis novembre 2023 à 4,818%, s'est replié à 4,78%. Le président de la Fed de New York, John Williams, a par ailleurs tempéré les anticipations d'une hausse des taux automatique en septembre, estimant que les prochains indicateurs économiques, notamment le rapport sur l'emploi attendu vendredi, seront déterminants. Sur le pétrole, le Brent est resté proche de 95 dollars le baril, les tensions entre les États-Unis et l'Iran continuant de peser sur les approvisionnements énergétiques mondiaux.",
          },
          {
            tag: "USA | EMPLOI",
            titre: "Le rapport ADP confirme un ralentissement du marché du travail",
            texte:
              "Le secteur privé américain n'a créé que 38.000 emplois en août, un chiffre inférieur aux attentes du marché et au chiffre révisé de juillet, selon le rapport ADP publié mercredi. Il s'agit de la plus faible progression depuis janvier, les créations d'emplois se concentrant principalement dans la santé et l'éducation. Cette donnée renforce l'incertitude entourant la prochaine décision de la Fed, les investisseurs se tournant désormais vers le rapport officiel sur l'emploi (NFP) attendu vendredi pour arbitrer entre les risques d'inflation liés au pétrole et ceux d'un ralentissement du marché du travail.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-09-01",
    pdfUrl: "/assets/briefs/2026-09-01.pdf",
    dateLabel: "01/09/2026",
    titre: "Le MASI chute de 1,47%, les valeurs industrielles sous pression",
    resumeCourt:
      "Le MASI chute de 1,47% lundi à 18 652,72 points, une troisième séance de baisse consécutive, plombé par les Ingénieries et biens d'équipement industriels (-8,44%), les Mines (-4,31%) et le Pétrole et gaz (-3,75%). BCP publie un PNB en repli de 3,2% au premier semestre, Akdital un chiffre d'affaires en hausse de 19%. Wall Street termine août en baisse après une flambée du pétrole liée aux tensions Iran-États-Unis, malgré un bilan mensuel très positif.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI chute de 1,47%, les valeurs industrielles sous pression",
            texte:
              "La Bourse de Casablanca a clôturé la séance de lundi dans le rouge, le MASI cédant 1,47% à 18.652,72 points, une troisième séance de baisse consécutive. Le MASI 20 a reculé de 1,23% à 1.341,93 points et le MASI ESG a plus nettement chuté de 2,1% à 1.380,35 points, tandis que le MASI Mid and Small Cap a mieux résisté (-0,05% à 1.814,22 points). La pression vendeuse a été particulièrement marquée sur les Ingénieries et biens d'équipement industriels (-8,44%), plombées par Stroc Industrie (-9,98% à 184,55 DH) et Microdata (-8,44% à 705 DH). Les Mines (-4,31%) et le Pétrole et gaz (-3,75%) ont également pesé sur l'indice, TotalEnergies Marketing Maroc reculant de 8,97% à 1.411 DH au lendemain de la publication de ses résultats semestriels. À l'inverse, les Matériels, logiciels et services informatiques ont progressé de 0,91%.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | BCP",
            titre: "PNB en recul de 3,2%, malgré une dynamique commerciale solide",
            texte:
              "Le Groupe Banque Centrale Populaire affiche un produit net bancaire consolidé en repli de 3,2% à 13,5 MMDH au premier semestre 2026, pénalisé par la contraction du résultat des activités de marché après une performance exceptionnelle un an plus tôt. Les métiers bancaires cœurs restent en revanche bien orientés : les dépôts de la clientèle progressent de 9% à 429,5 MMDH et les crédits bruts de 5,7% à 337,5 MMDH, tandis que la marge d'intérêt gagne 5,9% et la marge sur commissions 9,1%.",
          },
          {
            tag: "MAROC | AKDITAL",
            titre: "Chiffre d'affaires en hausse de 19%, poursuite de l'expansion",
            texte:
              "Akdital a réalisé un chiffre d'affaires consolidé de 2,482 MMDH au premier semestre 2026 (+19%), porté par l'ouverture de quatre nouveaux établissements au T2 (dont trois à Casablanca) portant le réseau à 45 établissements et 4.864 lits. Les admissions atteignent 590.842 sur le semestre, 71% étant réalisées hors de l'axe Casablanca-Rabat. L'endettement net progresse à 4,916 MMDH (+15%), incluant une émission obligataire de 300 MDH. Le groupe vise 59 établissements d'ici 2028, avec une expansion en Arabie saoudite soutenue par l'entrée d'Arab Invest au capital de sa holding internationale.",
          },
          {
            tag: "MAROC | CMT",
            titre: "Chiffre d'affaires en bond de 74%, trésorerie nette de 393 MDH",
            texte:
              "Compagnie Minière de Touissit a réalisé un chiffre d'affaires consolidé de 596 MDH au premier semestre 2026 (+74%), porté non par les volumes mais par la flambée des cours des métaux (zinc +22%, argent +141%). La structure financière s'est nettement renforcée, avec une trésorerie nette positive de 393 MDH contre un endettement net de 70 MDH fin 2025, grâce notamment au règlement d'accords transactionnels avec OMM et Shaba Metals pour 47 M$ au total.",
          },
          {
            tag: "MAROC | TGCC",
            titre: "Produit d'exploitation en repli, carnet de commandes en forte hausse",
            texte:
              "TGCC affiche un produit d'exploitation consolidé de 5,24 MMDH au premier semestre 2026 (-5,3%), pénalisé par les conditions climatiques et le démarrage encore progressif de plusieurs grands chantiers, avec un impact attendu sur la rentabilité semestrielle. Le T2 seul renoue toutefois avec la croissance (+1,2%). Le carnet de commandes bondit à 28,4 MMDH (contre 19,1 MMDH un an plus tôt), porté notamment par le nouveau terminal de l'aéroport Mohammed V et la LGV Casablanca-Marrakech. L'endettement net progresse à 2,08 MMDH, lié à la hausse du BFR sur les chantiers en lancement.",
          },
          {
            tag: "MAROC | SGTM",
            titre: "Revenus en baisse de 7,2%, carnet de commandes proche de 35 MMDH",
            texte:
              "SGTM affiche un chiffre d'affaires consolidé de 6,601 MMDH au premier semestre 2026 (-7,2%), le groupe expliquant ce recul par le phasage entre les grands projets livrés en 2025 (UM6P, stades de Rabat) et la montée en charge encore progressive de nouveaux chantiers comme le terminal de l'aéroport Mohammed V. Les investissements bondissent de 47,3% à 377 MDH et l'endettement net grimpe à 2,4 MMDH. Le carnet de commandes reste élevé à 34,8 MMDH, dominé à 74,4% par le secteur public.",
          },
          {
            tag: "MAROC | JET CONTRACTORS",
            titre: "Chiffre d'affaires en hausse de 10%, carnet de commandes en forte progression",
            texte:
              "Jet Contractors a réalisé un chiffre d'affaires consolidé de 1,607 MMDH au premier semestre 2026 (+10%), avec une accélération au T2 (+15%). Le carnet de commandes bondit de 39% à 12,8 MMDH, l'export en représentant 30%, porté par des chantiers comme la LGV Kénitra-Marrakech et l'extension de l'aéroport de Marrakech. L'endettement net progresse de 28% à 2,066 MMDH, lié aux préfinancements des nouveaux chantiers.",
          },
          {
            tag: "MAROC | RÉSIDENCES DAR SAADA",
            titre: "Chiffre d'affaires en hausse de 25%, préventes en forte accélération",
            texte:
              "Résidences Dar Saada affiche un chiffre d'affaires consolidé de 202 MDH au premier semestre 2026 (+25%), avec des préventes bondissant à 16.168 unités (contre 1.132 un an plus tôt), portées par de nouvelles conventions de relogement à Marrakech (plus de 15.400 unités). Le groupe évalue son potentiel de chiffre d'affaires en développement à 12,5 MMDH. L'endettement global s'établit à 1,93 MMDH à fin juin, après un remboursement de 340 MDH de dettes financières sur le semestre.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street termine août en baisse, pénalisée par la remontée du pétrole",
            texte:
              "La Bourse de New York a clôturé lundi en baisse, le Dow Jones cédant 0,70% à 53.185,90 points, le S&P 500 reculant de 0,33% à 7.686,14 points et le Nasdaq Composite abandonnant 0,12% à 26.370,89 points. Ce repli a été déclenché par une flambée des cours du pétrole après que les États-Unis ont frappé des lance-roquettes iraniens sur l'île de Larak, ravivant les tensions militaires directes entre Washington et Téhéran après plusieurs semaines d'accalmie relative. Le Brent a bondi de 2,71% à 90,49 dollars le baril et le WTI de 2,83% à 85,76 dollars, cette remontée des cours de l'énergie faisant craindre une résurgence des pressions inflationnistes susceptible de pousser la Fed vers une hausse des taux. Malgré ce repli de fin de mois, les indices affichent un bilan mensuel très positif : le Nasdaq gagne environ 3,9% sur août, le S&P 500 près de 2,6% et le Dow 1,3%, sa cinquième hausse mensuelle consécutive.",
          },
          {
            tag: "MOYEN-ORIENT | IRAN",
            titre: "Regain de tensions militaires directes entre Washington et Téhéran",
            texte:
              "Le commandement central américain a confirmé dimanche avoir frappé deux lance-roquettes situés sur l'île iranienne de Larak, marquant la première frappe américaine publiquement reconnue contre l'Iran depuis plusieurs semaines. Cet épisode ravive les inquiétudes entourant la sécurité du détroit d'Ormuz, corridor énergétique stratégique mondial, et contribue à la remontée des cours du pétrole observée en fin de séance de lundi.",
          },
          {
            tag: "EUROPE | CAC 40 & DAX",
            titre: "Marchés européens contrastés, l'Allemagne sous pression",
            texte:
              "Le CAC 40 a terminé lundi quasiment stable (+3,65 points), les investisseurs restant prudents avant la publication des chiffres d'inflation de la zone euro et une décision de la BCE en septembre désormais jugée plus incertaine par le marché. Le DAX allemand a en revanche nettement reculé, cédant 245 points à 30.538,56 points, les investisseurs intégrant progressivement la perspective d'un relèvement des taux de la BCE.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-31",
    pdfUrl: "/assets/briefs/2026-08-31.pdf",
    dateLabel: "31/08/2026",
    titre: "Le MASI recule pour une 2e séance, les échanges bondissent",
    resumeCourt:
      "Le MASI recule pour une 2e séance consécutive, cédant 0,61% vendredi à 18 931,06 points, tandis que les échanges bondissent à plus de 580 MDH contre 409,7 MDH la veille. BMCI publie un résultat net consolidé en bond de 62,4% au premier semestre, Bank of Africa un PNB en hausse de 1,5%. Wall Street termine en léger repli après le premier grand discours de Kevin Warsh à la tête de la Fed, tandis que le CAC 40 termine la semaine sur une note positive.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI recule pour une 2e séance, les échanges bondissent",
            texte:
              "La Bourse de Casablanca a achevé la séance de vendredi sur une note négative, le MASI cédant 0,61% à 18.931,06 points, marquant un deuxième repli consécutif. Le MASI 20 a reculé de 0,28% à 1.358,68 points. Le marché a été marqué par des évolutions contrastées selon les secteurs : la Sylviculture et le papier a enregistré la plus forte baisse sectorielle (-2,61%). Les échanges ont nettement bondi, dépassant les 580 millions de dirhams sur la séance, contre 409,7 millions la veille. La capitalisation boursière globale s'établit à 1.118,2 milliards de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | BMCI",
            titre: "Résultat net consolidé en bond de 62,4%",
            texte:
              "BMCI a réalisé un résultat net consolidé de 354 MDH au premier semestre 2026 (contre 218 MDH un an plus tôt, +62,4%), porté avant tout par un net recul du coût du risque (-62,3% à 150 MDH). Le produit net bancaire progresse plus modérément (+0,9% à 2,01 MMDH), la marge d'intérêt gagnant 3,4% tandis que les commissions et le résultat des activités de marché reculent légèrement. Le coefficient d'exploitation s'améliore à 59,2%. Les crédits à la clientèle progressent de 0,9% à 59,37 MMDH et les dépôts de 2,2% à 51,67 MMDH. Fitch a attribué à la banque une note long terme AA+(mar) avec perspective négative en juin.",
          },
          {
            tag: "MAROC | BANK OF AFRICA",
            titre: "PNB consolidé en hausse de 1,5%, dynamique commerciale solide",
            texte:
              "Bank of Africa affiche un PNB consolidé de 10,502 MMDH au premier semestre 2026 (+1,5% sur un an), avec une accélération au T2 seul (+4,9%). L'activité commerciale reste bien orientée : les crédits à la clientèle consolidés progressent de 4,3% à 243,5 MMDH et les dépôts de 4,1% à 286,5 MMDH. La banque a été désignée « Meilleure Banque d'Afrique du Nord 2026 » par The African Banker, pour la deuxième fois depuis 2023.",
          },
          {
            tag: "MAROC | TOTALENERGIES MARKETING MAROC",
            titre: "Chiffre d'affaires en hausse de 32%, malgré des volumes en repli",
            texte:
              "TotalEnergies Marketing Maroc a réalisé un chiffre d'affaires consolidé de 9,96 MMDH au premier semestre 2026, en progression de 32% sur un an, porté par le niveau élevé des cours pétroliers internationaux. Les volumes commercialisés reculent cependant de 3% à 852.000 tonnes, sur fond de repli de la demande. La société souligne que le chiffre d'affaires n'est pas, à lui seul, un indicateur pertinent du secteur compte tenu de sa forte sensibilité aux cours mondiaux. La situation nette créditrice s'établit à 290,6 MDH à fin juin, pour un réseau de 386 stations-service, dont 114 solarisées.",
          },
          {
            tag: "MAROC | MARSA MAROC",
            titre: "Chiffre d'affaires en hausse de 13%, investissements en forte accélération",
            texte:
              "Marsa Maroc a réalisé un chiffre d'affaires consolidé de 3,214 MMDH au premier semestre 2026 (+13%), porté par une hausse de 3% du trafic manutentionné à 34,5 millions de tonnes. Le trafic domestique de conteneurs progresse de 7%, tandis que le transbordement recule de 4% dans le cadre d'une stratégie de spécialisation des terminaux. Les investissements bondissent de 166% à 3,433 MMDH, principalement liés au développement de Nador West Med, dont les nouvelles entités (Nador Container Terminal, West Med Towage) intègrent désormais le périmètre. Le groupe conserve une trésorerie nette positive.",
          },
          {
            tag: "MAROC | RISMA",
            titre: "Chiffre d'affaires en hausse de 15%, désendettement après la cession du Sofitel",
            texte:
              "Risma a réalisé un chiffre d'affaires consolidé de 863 MDH au premier semestre 2026 (+15% en pro forma), avec un taux d'occupation en progression de 5 points à 64%. La cession du Sofitel Casablanca Tour Blanche (450 MDH), finalisée en mai, a permis de ramener la dette nette à 1,029 MMDH contre 1,444 MMDH au T1. Le groupe est par ailleurs devenu gestionnaire hôtelier via un contrat-cadre avec Accor portant sur 21 hôtels, tandis que le projet d'acquisition de l'hôtel Bavaro à Dakhla a été abandonné.",
          },
          {
            tag: "MAROC | HPS",
            titre: "Produits d'exploitation en hausse de 13,2%, portés par le Paiement",
            texte:
              "HPS affiche des produits d'exploitation consolidés de 761 MDH au premier semestre 2026 (+13,2%), avec une accélération au T2 (+15,3%). L'activité Paiement (y compris CR2) progresse de 18,7% et représente 88,3% des revenus, portée par les projets PowerCARD/BankWorld (+36,3%) et l'Upselling (+59,7%). L'Asie et les Amériques représentent désormais 28,1% des revenus, contre 17,5% un an plus tôt. Le backlog atteint 1.737 MDH (+3,9%). Le groupe confirme ses objectifs 2026 d'une croissance organique de 12 à 17%.",
          },
          {
            tag: "MAROC | VICENNE",
            titre: "Chiffre d'affaires en hausse de 12%, objectifs 2026 confirmés",
            texte:
              "Vicenne a réalisé un chiffre d'affaires consolidé de 591 MDH au premier semestre 2026 (+12%), avec une accélération marquée au T2 (+29% à 395 MDH), portée par la Business Unit Équipement (+41% au trimestre). La société affiche une trésorerie nette positive de 211 MDH, contre un endettement net un an plus tôt, grâce à l'augmentation de capital liée à son introduction en bourse. Vicenne confirme son objectif de chiffre d'affaires annuel autour de 1,2 MMDH.",
          },
          {
            tag: "MAROC | SONASID",
            titre: "Chiffre d'affaires stable, investissements en hausse de 48%",
            texte:
              "Sonasid affiche un chiffre d'affaires consolidé stable de 3,051 MMDH au premier semestre 2026, avec un net rebond au T2 (chiffre d'affaires social +12%) après un T1 pénalisé par une pluviométrie exceptionnelle. Les investissements bondissent de 48% à 149 MDH, sur une enveloppe totale de 514 MDH prévue pour 2026, notamment liés à un nouveau four à Nador. Le groupe conserve une trésorerie nette positive de 310 MDH.",
          },
          {
            tag: "MAROC | SANLAM MAROC",
            titre: "Chiffre d'affaires en hausse de 19,6%",
            texte:
              "Sanlam Maroc a réalisé un chiffre d'affaires global de 4,103 MMDH au premier semestre 2026, en progression de 19,6% sur un an, porté par une contribution exceptionnelle de la branche Vie et une hausse de 5,9% du Non-Vie. Les provisions techniques nettes progressent de 7,4% à 16,786 MMDH et les placements affectés aux opérations d'assurance de 5,1% à 18,880 MMDH.",
          },
          {
            tag: "MAROC | HOLCIM MAROC",
            titre: "Chiffre d'affaires quasi stable au S1, net rebond au T2",
            texte:
              "Holcim Maroc affiche un chiffre d'affaires consolidé quasi stable sur le semestre (-0,2%), la pluviométrie exceptionnelle de début d'année n'ayant été que partiellement compensée. Le T2 seul ressort toutefois en nette hausse (+12,7% à 2,378 MMDH), porté par une demande nationale de ciment en progression de 8%. L'endettement net atteint 5,093 MMDH (+4,4%). Le groupe reste confiant pour le second semestre, porté par les investissements liés à la Coupe du Monde 2030.",
          },
          {
            tag: "MAROC | MED PAPER",
            titre: "Chiffre d'affaires en repli, endettement en baisse",
            texte:
              "Med Paper affiche un chiffre d'affaires de 39 MDH au premier semestre 2026, en recul par rapport aux 42,4 MDH de l'an dernier. L'endettement diminue en revanche de 8,8 MDH sur un an, à 105,3 MDH. La société dit maintenir le cap sur sa stratégie et rester confiante dans les opportunités du marché marocain, notamment avec la mise en œuvre de la loi sur les préférences nationales.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street termine en léger repli après le discours de Kevin Warsh",
            texte:
              "La Bourse de New York a clôturé vendredi en légère baisse, les investisseurs digérant le premier grand discours de Kevin Warsh en tant que président de la Fed lors du symposium annuel de Jackson Hole. Le S&P 500 a cédé 0,25% à 7.711,76 points, le Nasdaq Composite a reculé de 0,52% à 26.402,42 points, pénalisé par les valeurs des semi-conducteurs, tandis que le Dow Jones a quasiment terminé stable (-0,02%) à 53.559,99 points. Sur l'ensemble de la semaine, les trois indices affichent néanmoins une performance positive : le S&P 500 gagne 0,5%, le Nasdaq 0,9% et le Dow 0,5%, sa première semaine de hausse en trois semaines.",
          },
          {
            tag: "USA | FED",
            titre: "Kevin Warsh maintient la pression sur l'inflation, les paris sur une hausse des taux se renforcent",
            texte:
              "Lors de son premier discours à Jackson Hole en tant que président de la Fed, Kevin Warsh a réaffirmé que la lutte contre l'inflation restait la priorité absolue de la banque centrale, jugeant que les récentes données, bien que meilleures que prévu, ne montraient pas d'amélioration significative de la tendance sous-jacente. Ces propos, perçus comme légèrement plus fermes qu'attendu par le marché obligataire, ont conduit les investisseurs à renforcer leurs paris sur une possible hausse des taux dès septembre, les rendements des bons du Trésor à 2 ans bondissant d'environ 8 points de base dans la foulée. Les traders restent désormais partagés entre un statu quo monétaire et un relèvement des taux lors de la prochaine réunion de la Fed.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "La Bourse de Paris termine la semaine sur une note positive",
            texte:
              "Le CAC 40 a signé une nouvelle séance de hausse vendredi (+1,08%), portant l'indice parisien à effacer une bonne partie de ses pertes récentes, dans un mouvement plus marqué que celui observé sur les autres places européennes.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-28",
    pdfUrl: "/assets/briefs/2026-08-28.pdf",
    dateLabel: "28/08/2026",
    titre: "Le MASI recule, les mines sous pression",
    resumeCourt:
      "Le MASI cède 0,40% jeudi à 19 046,92 points, pénalisé par le compartiment Mines (-1,59%), tandis que les Ingénieries et biens d'équipement industriels signent la meilleure performance sectorielle (+8,29%). CFG Bank publie un PNB en hausse de 6% au premier semestre, CMGP Group un chiffre d'affaires en bond de 41,7%. Nvidia bondit de 8,7% après des prévisions de croissance rassurantes, Wall Street signe sa meilleure séance depuis début août.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI recule, les mines sous pression",
            texte:
              "La Bourse de Casablanca a clôturé la séance de jeudi en baisse, le MASI cédant 0,40% à 19.046,92 points, après avoir touché 19.075,49 points à l'ouverture. Le MASI 20 a reculé de 0,36% à 1.362,56 points et le MASI ESG a plus nettement chuté de 0,82% à 1.422,28 points. Les petites et moyennes capitalisations ont mieux résisté, le MASI Mid and Small Cap limitant son repli à 0,06% à 1.816,40 points. Le compartiment Mines a enregistré la plus forte contraction sectorielle (-1,59%), pénalisé notamment par Promopharm (-5,92% à 1.223 DH) et Holcim Maroc (-2,38% à 1.766 DH). À l'inverse, les Ingénieries et biens d'équipement industriels ont signé la meilleure performance sectorielle (+8,29%). La capitalisation boursière globale s'établit à 1.126,8 milliards de dirhams, pour un volume global de 409,7 millions de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | CFG BANK",
            titre: "PNB en hausse de 6%, malgré le repli des activités de marché",
            texte:
              "CFG Bank a publié un produit net bancaire consolidé de 634 MDH au premier semestre 2026, en progression de 6% sur un an, porté par un PNB récurrent (banque commerciale et gestion d'épargne) en forte hausse de 18% à 549 MDH, dont une marge d'intérêt de 316 MDH (+29%). À l'inverse, le PNB lié aux marchés financiers a chuté de 36% à 85 MDH, pénalisé par des marchés actions et obligataire moins porteurs sur fond de tensions géopolitiques, après un premier semestre 2025 exceptionnel. Le résultat brut d'exploitation progresse plus vite que le PNB (+18% à 354 MDH), grâce à une bonne maîtrise des charges. Les encours de crédits bondissent de 20% sur un an à 20,6 MMDH, tirés par le segment Entreprises, tandis que les dépôts de la clientèle progressent de 17% à 22,1 MMDH. La banque a par ailleurs ouvert une 19e agence à Casablanca en avril, avec 6 autres en cours de construction d'ici 2028.",
          },
          {
            tag: "MAROC | CMGP GROUP",
            titre: "Chiffre d'affaires en hausse de 41,7% au premier semestre",
            texte:
              "CMGP Group a réalisé un chiffre d'affaires consolidé de 1.588 MDH au premier semestre 2026, en bond de 41,7% sur un an (+8,7% à périmètre comparable), porté par la dynamique agricole et l'intégration des nouvelles filiales CPCM, Agrosem et Sodipire, dont la contribution cumulée progresse de 27,2% en proforma. Dans l'agrofourniture, les films plastiques bondissent de 73,8%, les engrais de 19,4% et les produits phytosanitaires de 5,6%. Les activités hors agriculture (chimie industrielle, infrastructures) progressent de 9,4% en proforma. Les investissements ont atteint 73 MDH sur le semestre (contre 22 MDH un an plus tôt), notamment liés à l'acquisition de Sodipire, portant l'endettement net à 1.075 MDH contre 949 MDH fin 2025. Le groupe se dit confiant pour le second semestre, fort d'un carnet de commandes solide.",
          },
          {
            tag: "MAROC | IMMORENTE INVEST",
            titre: "Activité en progression, guidance 2026 maintenue",
            texte:
              "Immorente Invest a généré des produits immobiliers de 21,8 MDH au deuxième trimestre 2026 (+8% sur un an), portant le cumul semestriel à 43,1 MDH (+9%), porté par l'élargissement du périmètre après la livraison de l'usine Skylla fin 2025. Le chiffre d'affaires consolidé IFRS du trimestre s'établit à 21,3 MDH (+1%). Le portefeuille reste dominé par l'industriel (51%), devant les bureaux (29%), la santé (16%) et le commerce (4%), sans nouvel investissement sur le trimestre. Le ratio Loan to Value ressort à 28% à fin juin, pour une dette financière brute de 370 MDH et une trésorerie de 13,4 MDH. La société maintient sa guidance 2026 d'un FFO de 5,5 DH par action, après le versement d'un deuxième rendement trimestriel de 2,5 DH par action le 3 juillet.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street bondit, portée par Nvidia et Salesforce",
            texte:
              "La Bourse de New York a signé jeudi sa meilleure séance depuis début août, portée par des résultats trimestriels exceptionnels dans la tech. Le Nasdaq Composite a bondi de 1,57% à 26.541,35 points, le S&P 500 a progressé de 0,72% à 7.730,99 points, se rapprochant de son record du mois, et le Dow Jones a gagné 0,20% à 53.569,44 points. Les rendements obligataires à 10 ans se sont légèrement tendus à 4,66%, contre 4,65% la veille.",
          },
          {
            tag: "USA | NVIDIA",
            titre: "L'action bondit de 8,7% après des prévisions de croissance solides",
            texte:
              "Nvidia a de nouveau largement dépassé les attentes du marché, avec un chiffre d'affaires trimestriel plus que doublé sur un an et surtout des prévisions de croissance jugées rassurantes pour l'ensemble du secteur de l'intelligence artificielle : le concepteur de puces anticipe désormais une croissance de son chiffre d'affaires de 70% pour l'exercice 2028, contre 44% attendus par le consensus. L'action a bondi de 8,7% dans la foulée, entraînant dans son sillage les valeurs liées aux semi-conducteurs, avec Broadcom (+4,5%), Intel (+4%) et SK Hynix (+2%). Ces résultats ont contribué à apaiser les inquiétudes qui pesaient récemment sur l'ensemble de l'industrie de l'IA.",
          },
          {
            tag: "USA | FED",
            titre: "Un responsable de la Fed plaide pour une inflation encore trop élevée",
            texte:
              "Depuis le symposium annuel de Jackson Hole, le président de la Fed de Kansas City, Jeffrey Schmid, a estimé jeudi que l'inflation restait « persistante » et « tenace » aux États-Unis, sans toutefois appeler explicitement à une hausse des taux. Tous les regards se tournent désormais vers la prise de parole du président de la Fed, Kevin Warsh, attendue vendredi dans le cadre du symposium.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-27",
    pdfUrl: "/assets/briefs/2026-08-27.pdf",
    dateLabel: "27/08/2026",
    titre: "Le MASI se rapproche des 19.200 points",
    resumeCourt:
      "Le MASI progresse de 0,69% à 19 124,18 points, se rapprochant du seuil des 19.200 points, pour un volume de 316,3 MDH. AFMA publie un chiffre d'affaires en hausse de 8% au premier semestre, tandis que Cartier Saada recule sous la pression du marché américain. Nvidia dépasse largement les attentes mais recule après la clôture. Wall Street termine quasi stable avant ces résultats, le CAC 40 tente un rebond porté par le repli du pétrole.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI se rapproche des 19.200 points",
            texte:
              "La Bourse de Casablanca a poursuivi son ascension lors de la dernière séance, le MASI progressant de 0,69% pour s'établir à 19.124,18 points, se rapprochant du seuil symbolique des 19.200 points. Le MASI 20 a évolué dans le même sillage, gagnant 0,12% à 1.367,52 points. La capitalisation boursière globale ressort à environ 1.132,8 milliards de dirhams, pour un volume global d'échanges de 316,3 millions de dirhams sur la séance.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | AFMA",
            titre: "Chiffre d'affaires en hausse de 8% au premier semestre",
            texte:
              "Le courtier en assurances AFMA a réalisé un chiffre d'affaires consolidé de 191 MDH au premier semestre 2026, en progression de 8% par rapport à la même période de 2025. Sur le périmètre social, AFMA SA affiche la même dynamique avec un chiffre d'affaires de 162 MDH (+8%). Le groupe a investi 2,2 MDH sur la période et affiche un endettement net financier négatif de 8 MDH (position excédentaire), ce montant intégrant le dividende 2025 de 62 DH par action dont la distribution est prévue en septembre. Le périmètre de consolidation reste inchangé.",
          },
          {
            tag: "MAROC | CARTIER SAADA",
            titre: "Activité en repli au premier trimestre, sous pression du marché américain",
            texte:
              "Cartier Saada a vu son chiffre d'affaires reculer à 54,2 MDH au premier trimestre de l'exercice 2026/2027 (avril-juin 2026), contre 69,6 MDH un an plus tôt, les exportations représentant 97,7% du total. La société attribue ce repli à une pression accrue sur les prix aux États-Unis, certains clients se tournant vers des fournisseurs plus compétitifs, ainsi qu'à des perturbations logistiques liées aux tensions géopolitiques et à la fermeture du détroit d'Ormuz. Des conditions météorologiques exceptionnelles ayant affecté le port de Casablanca depuis début 2026 ont également pesé sur les délais d'exportation. Le groupe a néanmoins investi 1,1 MDH sur le trimestre, principalement dans le renouvellement de son matériel de manutention et de production.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street quasi stable avant les résultats de Nvidia",
            texte:
              "Mercredi, la Bourse de New York a terminé en légère baisse, les investisseurs restant à l'affût avant la publication des résultats trimestriels de Nvidia après la clôture. Le S&P 500 a clôturé quasiment stable à 7.675,70 points (-0,02%), le Nasdaq Composite a cédé 0,08% à 26.130,20 points et le Dow Jones a reculé de 0,21% à 53.463,88 points. L'indice PCE, la mesure d'inflation privilégiée par la Fed, est ressorti conforme aux attentes pour juillet (+0,2% sur le mois, +3,3% sur un an), sans toutefois modifier les anticipations d'une inflation toujours élevée. Les rendements obligataires à 10 ans se sont tendus à 4,66%, contre 4,63% la veille.",
          },
          {
            tag: "USA | NVIDIA",
            titre: "Nvidia dépasse largement les attentes, l'action recule après la clôture",
            texte:
              "Le concepteur de puces a publié un chiffre d'affaires trimestriel de 96,22 milliards de dollars, en plus que doublement sur un an et nettement au-dessus des 92,17 milliards attendus par le marché. Le bénéfice ajusté par action est ressorti à 2,22 dollars, contre un consensus de 2,10 dollars, porté notamment par des revenus liés aux centres de données de 89 milliards de dollars. Nvidia a par ailleurs évoqué un potentiel de chiffre d'affaires sur les puces d'IA pouvant dépasser 1.000 milliards de dollars d'ici 2027. Malgré ces résultats supérieurs aux attentes, l'action a reculé d'environ 1,5% dans les échanges after-hours, les investisseurs semblant avoir déjà largement anticipé cette performance.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "La Bourse de Paris tente un rebond avant Nvidia",
            texte:
              "Le CAC 40 a progressé mercredi, porté par le repli des cours pétroliers après des avancées diplomatiques autour du détroit d'Ormuz, Oman et l'Iran ayant évoqué un « couloir temporaire » de navigation. L'indice parisien a ainsi cherché à effacer une série récente de dix séances sur onze dans le rouge, les investisseurs restant par ailleurs attentifs aux résultats de Nvidia et aux indicateurs économiques américains du jour.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-17",
    pdfUrl: "/assets/briefs/2026-08-17.pdf",
    dateLabel: "17/08/2026",
    titre: "Le MASI quasiment stable, les petites capitalisations résistent",
    resumeCourt:
      "Le MASI cède 0,03% vendredi à 18 819,08 points, séance quasi stable. Les petites et moyennes capitalisations résistent (MASI Mid and Small Cap +0,16%). Aradei Capital publie un CA en hausse de 8% hors promotion immobilière, Maroc Leasing +10,4% au S1. Les réserves de change de Bank Al-Maghrib franchissent les 500 MMDH. Wall Street et le CAC 40 reculent.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI quasiment stable, les petites capitalisations résistent",
            texte:
              "La Bourse de Casablanca a terminé la dernière séance de la semaine sur une note quasi stable, le MASI cédant 0,03% à 18.819,08 points. Le MASI 20 a reculé de 0,01% à 1.359,41 points et le MASI ESG de 0,18% à 1.384,93 points. Les petites et moyennes capitalisations ont en revanche résisté à la tendance générale, le MASI Mid and Small Cap progressant de 0,16% à 1.817,47 points. Le compartiment Électricité a le plus pesé sur l'indice (-2,7%), pénalisé par Auto Nejma (-5,3% à 5.303 DH) et Taqa Morocco (-2,7% à 1.800 DH), tandis que la Sylviculture et papier s'est distinguée (+4,99%), portée par Alliances (+6,85% à 424,2 DH).",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | ARADEI CAPITAL",
            titre: "Chiffre d'affaires en hausse de 8% hors promotion immobilière",
            texte:
              "La foncière Aradei Capital affiche un chiffre d'affaires consolidé IFRS hors promotion immobilière de 334 MDH au premier semestre 2026 (+8% sur un an), porté par la croissance organique et l'ouverture fin 2025 de Sela Park Casablanca. En intégrant l'activité de promotion immobilière, le chiffre d'affaires total atteint 393 MDH. Le taux d'occupation du portefeuille ressort à 97%, pour une surface locative de 507.000 m². L'endettement net progresse à 3,142 MMDH, contre 2,805 MMDH fin 2025, dans un contexte d'accélération des investissements (222 MDH décaissés au semestre, contre 142 MDH un an plus tôt), principalement liés au futur complexe mixte de Casablanca et aux rénovations de Borj Fez et Almazar.",
          },
          {
            tag: "MAROC | MAROC LEASING",
            titre: "Revenus en progression de 10,4% au S1 2026",
            texte:
              "Maroc Leasing a réalisé un chiffre d'affaires de 2,38 MMDH au premier semestre 2026, en hausse de 10,4% sur un an, porté par un deuxième trimestre à 1,162 MMDH (+10,9%). Le produit net bancaire progresse de 6,1% à 181,7 MDH, tandis que le résultat net s'améliore de 5,1% à 55,4 MDH. L'encours financier atteint 14,26 MMDH à fin juin, en hausse de 3,6% depuis fin 2025, pour un endettement global de 12,52 MMDH (+4,4%).",
          },
        ],
      },
      {
        titre: "INDICATEURS MONÉTAIRES",
        items: [
          {
            tag: "MAROC | BANK AL-MAGHRIB",
            titre: "Les réserves de change franchissent les 500 MMDH",
            texte:
              "Selon les derniers indicateurs hebdomadaires de Bank Al-Maghrib, les avoirs officiels de réserve ont dépassé pour la première fois les 500 milliards de dirhams, s'établissant à 500,7 MMDH au 7 août (+0,5% sur une semaine, +22,6% sur un an). Le dirham s'est apprécié de 0,2% face à l'euro et de 0,1% face au dollar entre le 6 et le 12 août, sans intervention par adjudication sur le marché des changes. Le taux interbancaire est resté stable à 2,25%, tandis que la banque centrale a injecté 55 MMDH d'avances à 7 jours lors de l'appel d'offres du 12 août.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street recule après des indicateurs décevants",
            texte:
              "Vendredi, les indices américains se sont repliés depuis leurs niveaux record, l'indice de confiance des consommateurs de l'université du Michigan ayant chuté plus fortement que prévu en août. Les ventes au détail de juillet ont, elles, enregistré leur plus forte baisse en plus d'un an (-0,6%), bien au-delà des attentes. Ces signaux, conjugués à la remontée des taux obligataires et à la volatilité persistante du pétrole, ont pesé sur le sentiment des investisseurs en fin de semaine.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "La Bourse de Paris enchaîne une 4e séance de repli",
            texte:
              "Le CAC 40 a cédé 0,16% vendredi à 8.636,80 points, une quatrième séance consécutive de baisse qui l'éloigne de son record du 10 août (8.726,03 points). Sur la semaine, l'indice parisien recule de 0,9%, pénalisé par la poussée des taux obligataires et la volatilité des prix du pétrole, tandis que le S&P 500 américain progresse de 0,3% sur la même période.",
          },
          {
            tag: "ASIE | NIKKEI & HANG SENG",
            titre: "Les marchés asiatiques évoluent en ordre dispersé ce lundi",
            texte:
              "Ce lundi, les marchés asiatiques restent prudents dans l'attente d'avancées sur la réouverture du détroit d'Ormuz. Le Nikkei japonais progresse légèrement (+0,13% à +0,4% en intraday), tandis que le Topix recule de 0,45%. Hong Kong se distingue avec des contrats à terme sur le Hang Seng en hausse de 0,6%. La Bourse sud-coréenne est fermée pour un jour férié. Le pétrole reste sur des niveaux élevés, les flux en provenance du Moyen-Orient demeurant inférieurs de 10 à 15% à la normale.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-13",
    pdfUrl: "/assets/briefs/2026-08-13.pdf",
    dateLabel: "13/08/2026",
    titre: "Le MASI renoue avec la hausse, porté par les mines",
    resumeCourt:
      "Le MASI progresse de 0,65% mercredi à 18 825,54 points, effaçant le recul de la veille. Le compartiment Mines s'est distingué (+3,66%), Fenié Brossette signe la plus forte hausse (+6,67%). Alliances publie un CA en hausse de 30% au T2. Wall Street soulagée par une inflation conforme aux attentes, le Nikkei poursuit sa progression.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI renoue avec la hausse, porté par les mines",
            texte:
              "La Bourse de Casablanca a retrouvé une orientation positive mercredi, le MASI progressant de 0,65% à 18.825,54 points, effaçant le recul de la veille. Le MASI 20 a gagné 0,27% à 1.359,54 points et le MASI ESG s'est montré plus dynamique avec +1,17% à 1.387,43 points. Le compartiment Mines s'est distingué avec une hausse sectorielle de 3,66%, la plus forte de la séance : Fenie Brossette a signé la plus forte progression individuelle (+6,67% à 390,3 DH), devant Zellidja (+4,49% à 328 DH) et Managem (+4,23% à 1.700 DH). À l'inverse, l'Industrie agricole a cédé 2,74%, le repli sectoriel le plus marqué. Le volume s'est élevé à 148,9 MDH, pour une capitalisation proche de 1.106 milliards de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | ALLIANCES",
            titre: "Chiffre d'affaires en hausse de 30% au T2 2026",
            texte:
              "Alliances Développement Immobilier poursuit sa dynamique de croissance, avec un chiffre d'affaires consolidé de 803 MDH au T2 2026, contre 618 MDH un an plus tôt (+30%). Sur les six premiers mois, le chiffre d'affaires cumulé atteint 1,418 MMDH, contre 1,333 MMDH au premier semestre 2025. L'endettement net recule à 1,179 MMDH, contre 1,278 MMDH au trimestre précédent. Le groupe dispose d'un carnet de commandes sécurisé de 4,5 MMDH et de 6.312 unités en cours de production, avec des préventes en hausse de 16% au T2 (1.639 unités).",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street soulagée par une inflation conforme aux attentes",
            texte:
              "Mercredi, le Nasdaq a gagné 0,54% et le S&P 500 0,26%, tandis que le Dow Jones a cédé 0,04%. L'indice des prix à la consommation (CPI) de juillet est ressorti à 3,4% sur un an, en léger ralentissement par rapport à 3,5% en juin et conforme aux attentes des analystes, ce qui a rassuré les investisseurs sur la trajectoire de la Fed. Les valeurs technologiques liées à l'intelligence artificielle ont particulièrement progressé, portées par des résultats trimestriels bien accueillis.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "La Bourse de Paris consolide après ses récents records",
            texte:
              "Le CAC 40, qui avait touché la semaine dernière un pic inédit à 8.755,03 points, a cédé 0,46% mercredi à 8.674,94 points, pénalisé par les secteurs du luxe et de la consommation cyclique. Les indices européens ont globalement reflué après leurs récents sommets, les investisseurs restant attentifs aux négociations autour de la réouverture du détroit d'Ormuz.",
          },
          {
            tag: "ASIE | NIKKEI",
            titre: "Le Nikkei poursuit sa progression ce jeudi matin",
            texte:
              "Après un gain de 0,83% mercredi à 67.524,06 points, le Nikkei ajoute encore 0,86% ce jeudi matin, portant sa progression à environ 3% sur deux séances. L'indice se rapproche désormais de la résistance des 68.400 points.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-12",
    pdfUrl: "/assets/briefs/2026-08-12.pdf",
    dateLabel: "12/08/2026",
    titre: "Le MASI recule pour une 2e séance consécutive",
    resumeCourt:
      "Le MASI cède 0,68% mardi à 18 703,79 points, deuxième séance de repli d'affilée. Zellidja signe la plus forte baisse (-6,3%). Ciments du Maroc publie un CA en hausse de 4,8% au S1. Les taux obligataires secondaires légèrement orientés à la hausse. Wall Street prudent avant l'inflation américaine.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI recule pour une 2e séance consécutive",
            texte:
              "La Bourse de Casablanca a clôturé mardi en baisse pour la deuxième séance d'affilée, le MASI cédant 0,68% à 18.703,79 points. Le MASI 20 a reculé de 0,86% à 1.355,88 points et le MASI ESG de 0,45%. Le compartiment Ingénieries et biens d'équipement industriels a le plus pesé sur l'indice (-3,05%), suivi de la Chimie (-2,62%) et de l'Immobilier (-2,2%), tandis que l'Électricité s'est distinguée (+0,82%). Zellidja signe la plus forte baisse individuelle (-6,3% à 313,9 DH), devant Stroc Industrie (-3,65%) et SNEP (-3,13%). Le volume s'est élevé à 205,8 MDH, pour une capitalisation de 1.095,9 milliards de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | CIMENTS DU MAROC",
            titre: "Chiffre d'affaires en hausse de 4,8% au S1 2026",
            texte:
              "Ciments du Maroc affiche un chiffre d'affaires non consolidé de 2.033 MDH à fin juin 2026, en progression de 4,8% sur un an. Les investissements du T2 s'établissent à 4 MDH seulement (-87%), principalement de la maintenance, tandis que l'endettement financier recule de 800 MDH depuis fin 2025, à 1.833 MDH, grâce au remboursement partiel de l'emprunt lié à l'acquisition d'Asment de Témara.",
          },
        ],
      },
      {
        titre: "MARCHÉ OBLIGATAIRE",
        items: [
          {
            tag: "MAROC | MARCHÉ OBLIGATAIRE",
            titre: "Les taux secondaires légèrement orientés à la hausse",
            texte:
              "Selon la note hebdomadaire d'Attijari Global Research, les rendements obligataires ont légèrement progressé (moins de 2 points de base) durant la semaine du 31 juillet au 6 août. Sur le marché primaire, le Trésor a levé 800 MDH lors de sa deuxième séance d'adjudication d'août, pour une demande de 4,6 MMDH (taux de satisfaction de 17%). Les souscriptions cumulées atteignent 1,4 MMDH, soit 26% du besoin mensuel de 5,3 MMDH. AGR anticipe une pause monétaire prolongée de Bank Al-Maghrib jusqu'à fin 2026, dans l'attente d'une évaluation du choc énergétique sur l'inflation importée.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street prudent avant l'inflation américaine",
            texte:
              "Mardi, le Dow Jones a cédé 0,34%, le Nasdaq 0,60% et le S&P 500 0,32%, les investisseurs adoptant une posture attentiste à la veille de la publication de l'indice des prix à la consommation (CPI) américain de juillet, un indicateur clé pour la trajectoire des taux de la Fed.",
          },
          {
            tag: "ASIE | NIKKEI & KOSPI",
            titre: "Marchés asiatiques hésitants, le Kospi se distingue",
            texte:
              "Ce mercredi, le Nikkei évolue quasiment stable (+0,08%) après un jour férié, tandis que le Kospi sud-coréen bondit de 2,44% en cours de séance, en tête des gains régionaux. Le pétrole poursuit sa progression, le Brent approchant les 90 dollars le baril, sur fond de tensions persistantes dans le Golfe et d'attaques houthies contre des navires marchands, les investisseurs restant suspendus à la publication du CPI américain.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-11",
    pdfUrl: "/assets/briefs/2026-08-11.pdf",
    dateLabel: "11/08/2026",
    titre: "Le MASI marque une pause après sa forte semaine",
    resumeCourt:
      "Après une semaine exceptionnelle (+5,72%), le MASI cède 0,17% lundi à 18 832,18 points. Rebab Company signe le plus fort recul (-4,27%). SMI publie un chiffre d'affaires en hausse de 36% au S1, porté par la flambée du cours de l'argent. Addoha progresse de 9%. Wall Street glisse sous ses records, le pétrole grimpe.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI marque une pause après sa forte semaine",
            texte:
              "Après une semaine exceptionnelle (+5,72%), la Bourse de Casablanca a clôturé lundi en léger repli, le MASI cédant 0,17% à 18.832,18 points, dans un marché aux évolutions sectorielles contrastées. Sylviculture et papier a le plus reculé (-1,69%), tandis que la Chimie s'est distinguée avec un gain de 4,82%. Le volume s'est élevé à 181,2 MDH. Rebab Company signe le plus fort recul (-4,27%), suivie de Zellidja (-2,90%) et Involys (-2,21%).",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | SMI",
            titre: "Chiffre d'affaires en hausse de 36% au S1 2026",
            texte:
              "SMI a réalisé un chiffre d'affaires de 852 MDH au premier semestre 2026, en progression de 36% sur un an. Au seul deuxième trimestre, le chiffre d'affaires atteint 441 MDH, contre 326 MDH un an plus tôt. Cette performance s'explique principalement par la forte hausse du cours moyen de l'argent (+120%), qui a plus que compensé un recul de 38% des volumes vendus, lié à des travaux de maintenance et au décalage de la mise en exploitation du projet de carrière. Les investissements du semestre s'élèvent à 190 MDH, en hausse de 111%.",
          },
          {
            tag: "MAROC | ADDOHA",
            titre: "Chiffre d'affaires en progression de 9% au premier semestre",
            texte:
              "Le Groupe Addoha a réalisé un chiffre d'affaires consolidé de 1,41 milliard de dirhams au premier semestre 2026, en hausse de 9% sur un an, malgré l'impact du nouveau mode de comptabilisation applicable au secteur immobilier (le chiffre d'affaires aurait atteint 1,98 MMDH selon l'ancien mode). Les préventes progressent de 11% à 5.557 unités, et le chiffre d'affaires sécurisé atteint 12,1 MMDH. Le Groupe accélère sa production, avec 23.791 unités en cours, dont 35% en Afrique de l'Ouest, pour un chiffre d'affaires potentiel de 19,8 MMDH.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street glisse sous ses records, le pétrole grimpe",
            texte:
              "Lundi, le S&P 500 a cédé 0,06% à 7.753,11 points, le Dow Jones 0,11% à 53.975,98 points et le Nasdaq 0,32% à 26.605,36 points, les investisseurs restant prudents face à la remontée du pétrole sur fond d'incertitudes autour du détroit d'Ormuz. Intel a entraîné les valeurs technologiques à la baisse après l'annonce d'une levée de fonds de 15 milliards de dollars.",
          },
          {
            tag: "ASIE | NIKKEI & HANG SENG",
            titre: "Les marchés asiatiques évoluent en ordre dispersé ce mardi",
            texte:
              "Ce mardi matin, le Nikkei japonais gagne 1,92% tandis que le Hang Seng de Hong Kong recule de 0,81%. Le pétrole poursuit sa hausse, le WTI progressant à 82,39 dollars et le Brent à 87,96 dollars, sur fond de divergences entre Washington et Téhéran concernant les conditions de réouverture du détroit d'Ormuz.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-10",
    pdfUrl: "/assets/briefs/2026-08-10.pdf",
    dateLabel: "10/08/2026",
    titre: "Le MASI signe sa meilleure semaine depuis avril, à 18 864 points",
    resumeCourt:
      "Le MASI a gagné 2,08% sur la seule séance de vendredi à 18 864,02 points, portant sa performance hebdomadaire à 5,72% et effaçant ses pertes annuelles. Fenié Brossette signe la plus forte hausse (+7,05%), Rebab Company recule le plus (-5,99%). TGCC décroche le marché de reconstruction du stade Tessema pour 1,82 MMDH. Nouveau record pour le S&P 500.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI signe sa meilleure semaine depuis avril, à 18.864 points",
            texte:
              "La Bourse de Casablanca a clôturé vendredi sa meilleure semaine depuis avril 2026 : le MASI a gagné 2,08% sur la seule séance à 18.864,02 points, portant sa performance hebdomadaire à 5,72% et effaçant ses pertes annuelles (+0,09% depuis janvier). Le MASI 20 a progressé de 2,15% à 1.370,55 points, porté par les secteurs Santé (+3,6%), Holdings (+3,4%) et Immobilier (+3,26%). Le volume s'est élevé à 560 MDH, dominé par Managem (104 MDH, +2,33%), Maroc Telecom (74 MDH, +2,03%) et Attijariwafa bank (61 MDH, +2,68%). Fenie Brossette signe la plus forte hausse (+7,05%), tandis que Rebab Company recule le plus (-5,99%). La capitalisation globale dépasse désormais 1.101,7 milliards de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | TGCC",
            titre: "Décroche le marché de reconstruction du stade Tessema pour 1,82 MMDH",
            texte:
              "TGCC a remporté l'appel d'offres pour les gros œuvres de reconstruction du stade Tessema à Casablanca, pour un montant de 1,82 milliard de dirhams, devançant sa concurrente SGTM qui avait proposé 1,88 milliard de dirhams. Le marché porte sur le gros œuvre, la charpente métallique, l'étanchéité, les revêtements, les faux plafonds, les menuiseries et la peinture. Plus de 2,57 MMDH ont déjà été engagés au total sur ce chantier depuis le concours d'architecture.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Nouveau record pour le S&P 500 après un emploi américain décevant",
            texte:
              "Vendredi, le S&P 500 a signé un nouveau record de clôture (+0,62% à 7.757,64 points), le Dow Jones a gagné 0,28% et le Nasdaq 1,30%, portés par un rapport sur l'emploi américain nettement plus faible que prévu (-23.000 emplois en juillet contre +83.000 attendus), qui éloigne la perspective d'un resserrement monétaire de la Fed.",
          },
          {
            tag: "ASIE | NIKKEI & KOSPI",
            titre: "Les marchés asiatiques emboîtent le pas à Wall Street",
            texte:
              "Ce lundi matin, le Nikkei japonais progresse d'environ 2,0% et le Kospi sud-coréen entre 0,8% et 1,1%, dans le sillage des records de Wall Street. Les indices chinois évoluent en revanche en retrait (CSI 300 -0,4%), pénalisés par une inflation plus faible que prévu en juillet. Le pétrole progresse légèrement sur fond d'incertitudes autour des négociations de paix dans le Golfe.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-07b",
    pdfUrl: "/assets/briefs/weekly-2026-08-07.pdf",
    dateLabel: "31/07 — 07/08/2026",
    badge: "WEEKLY",
    badgeLarge: "WEEKLY · TAUX & MARCHÉS",
    titre: "Semaine du marché marocain : taux stables, meilleure semaine de Wall Street depuis avril",
    resumeCourt:
      "TMP interbancaire maintenu à 2,25%, MONIA moyen à 2,19%. Le Trésor lève 800 MDH lors de son adjudication du 4 août (taux de satisfaction 17%). L'EUR/USD clôture à 1,1557 (+0,32%). Wall Street signe sa meilleure semaine depuis avril (Dow +3%, S&P 500 +3,6%, Nasdaq +5,2%), le MASI progresse de 5,72% sur la semaine.",
    sections: [
      {
        titre: "MARCHÉ MONÉTAIRE",
        items: [
          {
            tag: "MAROC | MARCHÉ MONÉTAIRE",
            titre: "Le marché monétaire reste calme en ce début du mois d'août",
            texte:
              "Sur la période du 31 juillet au 6 août 2026, le marché interbancaire demeure stable, avec un TMP maintenu à 2,25%. Les volumes échangés se sont établis en moyenne à 2,51 MMDH, avec un pic de 2,88 MMDH le 5 août. Parallèlement, le taux MONIA s'est inscrit en baisse, passant de 2,231% à 2,156% entre le 31 juillet et le 5 août, avant de remonter légèrement à 2,179% le 6 août. Cette évolution traduit une détente des conditions de financement overnight, malgré la stabilité du taux interbancaire. L'écart entre le MONIA et le TMP interbancaire s'est ainsi accentué en cours de semaine, atteignant 7,1 pb au 6 août. Côté opérations de Bank Al-Maghrib, le total des interventions s'établit à 144,8 MMDH (contre 149,3 MMDH la semaine précédente), réparti entre avances à 7 jours (49,4 MMDH), pension livrée (47,9 MMDH) et prêts garantis (47,5 MMDH). Les avoirs officiels de réserve progressent de 22,3% à 496,8 MMDH, et la circulation fiduciaire de 18,4% à 532,6 MMDH.",
          },
        ],
      },
      {
        titre: "MARCHÉ OBLIGATAIRE",
        items: [
          {
            tag: "MAROC | MARCHÉ OBLIGATAIRE",
            titre: "Résultat de la séance d'adjudication du 04 août 2026",
            texte:
              "Le Trésor a proposé trois lignes lors de cette séance, pour un montant global demandé de 4,6 MMDH. Les soumissions se sont concentrées sur la maturité 52 semaines, pour une demande de 1,9 MMDH, dont 800 MDH ont finalement été retenus, soit un taux d'allocation de 42,1%. Le taux de rendement moyen ressort à 2,215%, en hausse de 0,9 point de base par rapport au dernier taux de référence. Aucune allocation n'a été retenue sur les lignes à 13 semaines et à 2 ans. Sur le marché secondaire, la courbe des taux comparée au 31/12/2025 montre un recul des taux courts (13 semaines : -5,8 pbs, 52 semaines : -13,6 pbs) mais une nette hausse des taux longs (10 ans : +33,6 pbs, 15 ans : +36,6 pbs, 30 ans : +23,1 pbs), traduisant une pentification de la courbe. Le taux de satisfaction du mois ressort à 17%, avec 26% du besoin mensuel de 5,3 MMDH couvert à date.",
          },
        ],
      },
      {
        titre: "MARCHÉ DES CHANGES",
        items: [
          {
            tag: "MAROC | MARCHÉ DES CHANGES",
            titre: "Un dollar sur la défensive après un emploi américain décevant",
            texte:
              "L'euro est resté globalement stable face au dollar sur la semaine, évoluant dans une fourchette étroite entre 1,1520 et 1,1581, pour clôturer à 1,1557 (+0,32% sur la semaine). Le billet vert a d'abord profité lundi d'un indice ISM manufacturier américain meilleur que prévu, avant de reculer progressivement à mesure que les indicateurs d'emploi (ADP, JOLTs) puis le rapport officiel sur l'emploi de vendredi se sont révélés nettement plus faibles qu'attendu — 23.000 destructions d'emplois en juillet contre 80.000 créations anticipées. Cette déception a ravivé les anticipations d'une pause prolongée de la Fed, pesant sur le dollar en fin de semaine.",
          },
        ],
      },
      {
        titre: "MARCHÉ INTERNATIONAL",
        items: [
          {
            tag: "MONDE | MARCHÉ INTERNATIONAL",
            titre: "La meilleure semaine de Wall Street depuis avril",
            texte:
              "Wall Street a signé sa meilleure semaine depuis avril 2026 : le Dow Jones a progressé de 3% (54.036,93 pts), le S&P 500 de 3,6% (record de clôture à 7.757,64 pts) et le Nasdaq de 5,2% (26.690,62 pts), ce dernier retrouvant le leadership technologique porté par de solides résultats et un regain d'enthousiasme pour l'intelligence artificielle. La semaine a démarré sur des signes d'apaisement au Moyen-Orient, avec des progrès dans les discussions sur la réouverture du détroit d'Ormuz. En Europe, le CAC 40 a enchaîné sept séances consécutives de hausse — une série inédite depuis février 2025 — clôturant vendredi à 8.714,93 points (+2,41% sur la semaine, 7e record consécutif). En Asie, le Nikkei a clôturé en léger repli (-0,2% à 65.606,71 pts) après une semaine volatile marquée par des prises de bénéfices sur la tech. Sur les matières premières, l'or a signé mercredi sa plus forte hausse quotidienne depuis février (+4%, ~4.253$), tandis que le Brent est repassé sous les 80 dollars. Le MASI, de son côté, a progressé de 5,72% sur la semaine — sa meilleure performance hebdomadaire depuis avril 2026.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-07",
    pdfUrl: "/assets/briefs/2026-08-07.pdf",
    dateLabel: "07/08/2026",
    titre: "Le MASI se rapproche des 18 560 points",
    resumeCourt:
      "Le MASI enchaîne les records et gagne 0,43% à 18 558,83 points ce vendredi matin, pour une capitalisation dépassant 1 081,8 milliards de dirhams. Akdital ouvre son capital international à Arab Invest. Wall Street marque une pause, nouveau record pour le CAC 40.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI se rapproche des 18.560 points",
            texte:
              "La séance de jeudi s'est clôturée en hausse, le MASI progressant de 0,82% à 18.479,44 points, porté par le MASI 20 (+0,85% à 1.341,75 pts) et le MASI ESG (+0,49% à 1.351,81 pts). Ce vendredi matin, l'indice poursuit sur sa lancée et gagne 0,43% à 18.558,83 points, pour une capitalisation boursière dépassant 1.081,8 milliards de dirhams.",
          },
        ],
      },
      {
        titre: "ACTUALITÉS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | AKDITAL",
            titre: "Arab Invest entre au capital de la holding internationale du groupe",
            texte:
              "Le groupe Akdital annonce l'entrée d'Arab Invest au capital de sa holding internationale basée à Riyad, via l'acquisition d'une participation de 15%. Cette opération vise à soutenir le financement de l'expansion régionale d'Akdital, avec un accent particulier sur l'Arabie saoudite, où le groupe développe actuellement quatre projets hospitaliers (deux à Riyad, un à La Mecque et un à Djeddah), avec l'ambition de dépasser 2.000 lits à l'international d'ici 2030.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Wall Street marque une pause après ses records",
            texte:
              "Jeudi, le Dow Jones a cédé 0,85% à 53.885,10 points, le S&P 500 0,18% à 7.709,96 points et le Nasdaq 0,06% à 26.348,35 points, plombés par la remontée du pétrole et des taux obligataires sur fond de regain d'incertitude au Moyen-Orient, malgré une saison de résultats d'entreprises toujours solide.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "Nouveau record, la Bourse de Paris franchit les 8.700 points",
            texte:
              "Le CAC 40 a signé un troisième record de clôture consécutif jeudi, à 8.699,71 points (+0,35%), après avoir touché 8.742,53 points en séance, porté par l'espoir d'une désescalade au Moyen-Orient et par de solides résultats semestriels des entreprises du CAC.",
          },
          {
            tag: "ASIE | NIKKEI & KOSPI",
            titre: "Les marchés asiatiques marquent le pas ce vendredi",
            texte:
              "Le Nikkei recule d'environ 0,9% ce matin et le Kospi sud-coréen cède près de 0,8%, portant sa baisse hebdomadaire à plus de 5%, les valeurs technologiques restant sous pression dans l'attente du rapport américain sur l'emploi (nonfarm payrolls) attendu ce vendredi.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-06",
    pdfUrl: "/assets/briefs/2026-08-06.pdf",
    dateLabel: "06/08/2026",
    titre: "Le MASI franchit les 18 300 points",
    resumeCourt:
      "Le MASI progresse de 1,48% à 18 329,91 points, porté par les secteurs Mines et Chimie. SNEP et Fenié Brossette signent les plus fortes hausses (+9,98%). Nouveau record pour Wall Street et le CAC 40, repli du Nikkei sur la tech.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI franchit les 18.300 points",
            texte:
              "Résumé de la séance du 5 août 2026 : le MASI progresse de 1,48% à 18.329,91 points, porté par les secteurs Mines (+8,6%) et Chimie (+8,56%). Le volume s'établit à 157,11 MDH, dominé par Managem (45,44 MDH), Marsa Maroc (20,72 MDH) et Maroc Telecom (12,18 MDH). SNEP et Fenie Brossette signent les plus fortes hausses de la séance (+9,98%), Managem progresse de 9,93% à 1.583 DH. À l'inverse, IB Maroc.com recule de 5,43%.",
          },
        ],
      },
      {
        titre: "RÉSULTATS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | ALUMINIUM DU MAROC",
            titre: "Chiffre d'affaires en repli de 8% au S1 2026",
            texte:
              "Aluminium du Maroc affiche un chiffre d'affaires de 585,31 MDH au premier semestre 2026, en baisse de 8%, pénalisé par le ralentissement de la demande à l'export dans un contexte de tensions géopolitiques et de prix élevés de l'aluminium.",
          },
          {
            tag: "MAROC | MANAGEM",
            titre: "Le titre continue de grimper après des indicateurs S1 solides",
            texte:
              "Après un chiffre d'affaires consolidé de 11,76 MMDH au S1 2026 (+166%), Managem poursuit son envol en Bourse avec un nouveau gain de 9,93% mercredi, porté par la montée en puissance des mines de Tizert et de Boto.",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA | WALL STREET",
            titre: "Le Dow Jones décroche un 3e record, S&P et Nasdaq marquent une pause",
            texte:
              "Mercredi, le Dow Jones a progressé de 0,49% à 54.349,12 points, un troisième record de clôture d'affilée, tandis que le S&P 500 a cédé 0,17% et le Nasdaq 0,83%, les investisseurs marquant une pause dans l'attente d'un accord entre Washington et Téhéran sur la réouverture du détroit d'Ormuz.",
          },
          {
            tag: "EUROPE | CAC 40",
            titre: "Nouveau record pour la Bourse de Paris",
            texte:
              "Le CAC 40 a signé un nouveau record à la clôture, à 8.669,30 points (+0,03%), après avoir touché 8.693,89 points en séance, porté par l'espoir d'un apaisement au Moyen-Orient et par de solides résultats semestriels des entreprises du CAC, dont les bénéfices cumulés progressent de 44% sur un an.",
          },
          {
            tag: "ASIE | NIKKEI",
            titre: "Repli des valeurs technologiques ce jeudi matin",
            texte:
              "Le Nikkei recule d'environ 1,6% ce matin, pénalisé par la baisse des semi-conducteurs dans le sillage de l'indice américain Philadelphia Semiconductor (SOX), malgré une majorité de valeurs en hausse à la Bourse de Tokyo.",
          },
        ],
      },
    ],
  },
  {
    date: "2026-08-05",
    pdfUrl: "/assets/briefs/2026-08-05.pdf",
    dateLabel: "05/08/2026",
    titre: "Le MASI franchit les 18 000 points — forte séance",
    resumeCourt:
      "Managem signe la plus forte hausse (+9,92%) et publie un CA en hausse de 166% au S1. Wall Street signe de nouveaux records, le Nikkei et le Kospi rebondissent fortement.",
    sections: [
      {
        titre: "MARCHÉ MAROCAIN",
        items: [
          {
            tag: "MAROC | BOURSE DE CASABLANCA",
            titre: "Le MASI franchit les 18.000 points — forte séance",
            texte:
              "Résumé de la séance du 4 août 2026 : le MASI progresse de 1,05% à 18.063,39 points, pour un volume total échangé de 1.255,16 MDH. Managem signe la plus forte hausse de la séance (+9,92%), tandis que CTM enregistre la plus forte baisse (-2,68%). Côté volumes, Douja Promotion Groupe Addoha domine les échanges avec 67,58 millions de titres traités, devant Managem (62,09 millions) et Label Vie (29,81 millions).",
          },
        ],
      },
      {
        titre: "RÉSULTATS DES SOCIÉTÉS COTÉES",
        items: [
          {
            tag: "MAROC | MANAGEM",
            titre: "Le chiffre d'affaires plus que double au S1 2026",
            texte:
              "Managem publie un chiffre d'affaires consolidé de 11,76 MMDH au premier semestre 2026, contre 4,42 MMDH un an plus tôt (+166%), porté par la montée en puissance des mines de Tizert et de Boto. L'endettement consolidé recule de plus de 20% depuis janvier, à 9,96 MMDH.",
          },
          {
            tag: "MAROC | SOTHEMA",
            titre: "Chiffre d'affaires en hausse de 16% au S1 2026",
            texte:
              "Sothema affiche un chiffre d'affaires consolidé de 1.795 MDH au premier semestre 2026 (+16%), après un deuxième trimestre à 917 MDH (+19%). Les investissements du T2 progressent de 79% à 34 MDH.",
          },
          {
            tag: "MAROC | DISWAY",
            titre: "Chiffre d'affaires en progression de 14,4% au S1 2026",
            texte:
              "Disway enregistre au premier semestre 2026 un chiffre d'affaires consolidé de 1.089 MDH, en hausse de 14,4%, après un T2 2026 à 591 MDH (+9,5%).",
          },
        ],
      },
      {
        titre: "MARCHÉS INTERNATIONAUX",
        items: [
          {
            tag: "USA & EUROPE | WALL STREET",
            titre: "Nouveaux records pour le Dow Jones et le S&P 500",
            texte:
              "Mardi, le Dow Jones a gagné 1,71% à 54.085,88 points et le S&P 500 1,79% à 7.736,52 points, deux clôtures record, tandis que le Nasdaq s'est envolé de 2,59%. À Paris, le CAC 40 a lui aussi signé un record à 8.666,63 points (+0,61%). La baisse du pétrole, sur fond d'espoirs de reprise du dialogue entre Washington et Téhéran, et de bons résultats d'entreprises ont porté les indices.",
          },
          {
            tag: "ASIE | NIKKEI & KOSPI",
            titre: "Fort rebond des places asiatiques ce mercredi",
            texte:
              "Dans le sillage des records de Wall Street, le Nikkei japonais gagne environ 3,0% et le Kospi sud-coréen près de 4,1% ce matin, portés par l'optimisme sur la tech et le repli des cours du pétrole. L'or progresse en parallèle à 4.130 dollars l'once.",
          },
        ],
      },
    ],
  },
];


const seanceHausses = [
  { code: "REB", nom: "Rebab Company", var: 6.00, cours: "93,29" },
  { code: "BAL", nom: "Balima", var: 5.99, cours: "199,90" },
  { code: "INV", nom: "Involys", var: 5.79, cours: "128,00" },
  { code: "SID", nom: "Sonasid", var: 2.94, cours: "1 999,00" },
  { code: "JET", nom: "Jet Contractors", var: 2.90, cours: "2 058,00" },
];
const seanceBaisses = [
  { code: "SAHM", nom: "Sanlam Maroc", var: -5.51, cours: "2 881,00" },
  { code: "MIC", nom: "Microdata", var: -4.94, cours: "712,00" },
  { code: "SRM", nom: "Réalisations Mécaniques", var: -4.01, cours: "450,00" },
  { code: "TMA", nom: "TotalEnergies Marketing Maroc", var: -3.69, cours: "1 435,00" },
  { code: "DHO", nom: "Delta Holding", var: -3.64, cours: "53,00" },
];
const seancePlusActives = [
  { nom: "CIH Bank", volume: "16,11 MDH", var: null, cours: null },
  { nom: "Attijariwafa Bank", volume: "11,05 MDH", var: null, cours: null },
  { nom: "TGCC", volume: "9,11 MDH", var: null, cours: null },
  { nom: "Maroc Telecom", volume: "6,33 MDH", var: null, cours: null },
];
const seanceSecteurs = null;

// ---- Widgets TradingView : données de marché réelles, en direct, via embed officiel ----
// TradingView propose ces widgets gratuitement pour l'intégration sur des sites tiers
// (voir tradingview.com/widget/) — pas de scraping, données mises à jour en continu.
// La Bourse de Casablanca est couverte nativement sous le préfixe "CSEMA:".

function TradingViewTickerTape() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbols: [
        { proName: "CSEMA:ADH", title: "ADH" },
        { proName: "CSEMA:ADI", title: "ADI" },
        { proName: "CSEMA:AFI", title: "AFI" },
        { proName: "CSEMA:AFM", title: "AFMA" },
        { proName: "CSEMA:AGM", title: "AGM" },
        { proName: "CSEMA:AKT", title: "AKT" },
        { proName: "CSEMA:ALM", title: "ALM" },
        { proName: "CSEMA:ARD", title: "ARD" },
        { proName: "CSEMA:ATH", title: "ATH" },
        { proName: "CSEMA:ATL", title: "ATL" },
        { proName: "CSEMA:ATW", title: "ATW" },
        { proName: "CSEMA:BAL", title: "BAL" },
        { proName: "CSEMA:BCI", title: "BCI" },
        { proName: "CSEMA:BCP", title: "BCP" },
        { proName: "CSEMA:BOA", title: "BOA" },
        { proName: "CSEMA:CAP", title: "CAP" },
        { proName: "CSEMA:CDM", title: "CDM" },
        { proName: "CSEMA:CFG", title: "CFG" },
        { proName: "CSEMA:CIH", title: "CIH" },
        { proName: "CSEMA:CMA", title: "CMA" },
        { proName: "CSEMA:CMG", title: "CMG" },
        { proName: "CSEMA:CMT", title: "CMT" },
        { proName: "CSEMA:COL", title: "COL" },
        { proName: "CSEMA:CRS", title: "CRS" },
        { proName: "CSEMA:CSR", title: "CSR" },
        { proName: "CSEMA:CTM", title: "CTM" },
        { proName: "CSEMA:DRI", title: "DRI" },
        { proName: "CSEMA:DHO", title: "DHO" },
        { proName: "CSEMA:DIS", title: "DIS" },
        { proName: "CSEMA:DLM", title: "DLM" },
        { proName: "CSEMA:DWY", title: "DWY" },
        { proName: "CSEMA:DYT", title: "DYT" },
        { proName: "CSEMA:EQD", title: "EQD" },
        { proName: "CSEMA:FBR", title: "FBR" },
        { proName: "CSEMA:GAZ", title: "GAZ" },
        { proName: "CSEMA:HPS", title: "HPS" },
        { proName: "CSEMA:IAM", title: "IAM" },
        { proName: "CSEMA:IBMC", title: "IBMC" },
        { proName: "CSEMA:IMO", title: "IMO" },
        { proName: "CSEMA:INV", title: "INV" },
        { proName: "CSEMA:JET", title: "JET" },
        { proName: "CSEMA:LBV", title: "LBV" },
        { proName: "CSEMA:LES", title: "LES" },
        { proName: "CSEMA:LHM", title: "LHM" },
        { proName: "CSEMA:M2M", title: "M2M" },
        { proName: "CSEMA:MAB", title: "MAB" },
        { proName: "CSEMA:MDP", title: "MDP" },
        { proName: "CSEMA:MIC", title: "MIC" },
        { proName: "CSEMA:MLE", title: "MLE" },
        { proName: "CSEMA:MNG", title: "MNG" },
        { proName: "CSEMA:MOX", title: "MOX" },
        { proName: "CSEMA:MSA", title: "MSA" },
        { proName: "CSEMA:MUT", title: "MUT" },
        { proName: "CSEMA:NAKL", title: "NAKL" },
        { proName: "CSEMA:NEJ", title: "NEJ" },
        { proName: "CSEMA:OUL", title: "OUL" },
        { proName: "CSEMA:PRO", title: "PRO" },
        { proName: "CSEMA:RDS", title: "RDS" },
        { proName: "CSEMA:REB", title: "REB" },
        { proName: "CSEMA:RIS", title: "RIS" },
        { proName: "CSEMA:S2M", title: "S2M" },
        { proName: "CSEMA:SAH", title: "SAH" },
        { proName: "CSEMA:SBM", title: "SBM" },
        { proName: "CSEMA:SLF", title: "SLF" },
        { proName: "CSEMA:SMI", title: "SMI" },
        { proName: "CSEMA:SNA", title: "SNA" },
        { proName: "CSEMA:SNP", title: "SNP" },
        { proName: "CSEMA:SRM", title: "SRM" },
        { proName: "CSEMA:STR", title: "STR" },
        { proName: "CSEMA:TGC", title: "TGC" },
        { proName: "CSEMA:TMA", title: "TMA" },
        { proName: "CSEMA:TQM", title: "TQM" },
        { proName: "CSEMA:UMR", title: "UMR" },
        { proName: "CSEMA:VCN", title: "VCN" },
        { proName: "CSEMA:WAA", title: "WAA" },
        { proName: "CSEMA:ZDJ", title: "ZDJ" },
      ],
      showSymbolLogo: false,
      isTransparent: true,
      displayMode: "adaptive",
      colorTheme: "light",
      locale: "fr",
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <div className="tv-widget-wrap tv-ticker-wrap">
      <div className="tradingview-widget-container" ref={ref}>
        <div className="tradingview-widget-container__widget"></div>
      </div>
    </div>
  );
}

function TradingViewMarketOverview() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("tv-market-overview")) return;

    if (!document.querySelector('script[data-tv-market-overview="1"]')) {
      const moduleScript = document.createElement("script");
      moduleScript.type = "module";
      moduleScript.src = "https://widgets.tradingview-widget.com/w/en/tv-market-overview.js";
      moduleScript.setAttribute("data-tv-market-overview", "1");
      document.head.appendChild(moduleScript);
    }

    const el = document.createElement("tv-market-overview");
    el.setAttribute(
      "symbol-sectors",
      JSON.stringify([
        {
          sectionName: "Indices",
          symbols: [
            "FOREXCOM:SPXUSD",
            "FOREXCOM:DJI",
            "FOREXCOM:NSXUSD",
            "FOREXCOM:FRXEUR",
            "XETR:DAX",
            "FOREXCOM:UKXGBP",
            "FOREXCOM:JPXJPY",
            "ASX:XJO",
            "CSEMA:MASI",
          ],
        },
        {
          sectionName: "Matières 1ères",
          symbols: ["TVC:GOLD", "TVC:SILVER", "TVC:UKOIL", "TVC:USOIL", "FOREXCOM:NATURALGAS"],
        },
      ])
    );
    ref.current.appendChild(el);
  }, []);
  return <div className="tradingview-widget-container tv-market-overview-wrap" ref={ref}></div>;
}

function TradingViewMasiOverview() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-symbol-overview.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbols: [["Bourse de Casablanca : MASI", "CSEMA:MASI|1D"]],
      chartOnly: false,
      width: "100%",
      height: "220",
      locale: "fr",
      colorTheme: "dark",
      isTransparent: true,
      autosize: true,
      showVolume: false,
      lineWidth: 2,
      lineType: 0,
      dateRanges: ["1d|15", "1m|30", "3m|60", "12m|1D"],
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <div className="tradingview-widget-container" ref={ref}>
      <div className="tradingview-widget-container__widget"></div>
    </div>
  );
}

function TradingViewSingleQuote({ symbol }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-single-quote.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbol: `CSEMA:${symbol}`,
      width: "100%",
      colorTheme: "light",
      isTransparent: true,
      locale: "fr",
    });
    ref.current.appendChild(script);
  }, [symbol]);
  return (
    <div className="tradingview-widget-container tv-single-quote" ref={ref}>
      <div className="tradingview-widget-container__widget"></div>
    </div>
  );
}

function TradingViewHotlist() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      colorTheme: "light",
      dateRange: "1D",
      exchange: "CSEMA",
      showChart: false,
      locale: "fr",
      largeChartUrl: "",
      isTransparent: true,
      showSymbolLogo: false,
      showFloatingTooltip: true,
      width: "100%",
      height: "450",
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <div className="tradingview-widget-container" ref={ref}>
      <div className="tradingview-widget-container__widget"></div>
    </div>
  );
}

function TradingViewScreener({ screen, title }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-screener.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      width: "100%",
      height: 400,
      defaultColumn: "overview",
      defaultScreen: screen,
      market: "morocco",
      showToolbar: false,
      colorTheme: "light",
      locale: "fr",
      isTransparent: true,
    });
    ref.current.appendChild(script);
  }, [screen]);
  return (
    <div className="palmares-card">
      <div className={`palmares-head ${screen === "top_gainers" ? "gain" : "loss"}`}>
        {screen === "top_gainers" ? <TrendingUp size={16} /> : <TrendingDown size={16} />} {title}
      </div>
      <div className="tradingview-widget-container" ref={ref}>
        <div className="tradingview-widget-container__widget"></div>
      </div>
    </div>
  );
}

function TradingViewMarketCapScreener() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-screener.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      width: "100%",
      height: 500,
      defaultColumn: "overview",
      defaultScreen: "general",
      market: "morocco",
      showToolbar: true,
      colorTheme: "light",
      locale: "fr",
      isTransparent: true,
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <div className="tradingview-widget-container" ref={ref}>
      <div className="tradingview-widget-container__widget"></div>
    </div>
  );
}

function TradingViewAllStocksScreener() {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || ref.current.querySelector("script")) return;
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-screener.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      width: "100%",
      height: 600,
      defaultColumn: "performance",
      defaultScreen: "general",
      market: "morocco",
      showToolbar: true,
      colorTheme: "light",
      locale: "fr",
      isTransparent: true,
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <div className="tradingview-widget-container" ref={ref}>
      <div className="tradingview-widget-container__widget"></div>
    </div>
  );
}

// Jours fériés marocains déjà déclarés plus haut (MOROCCO_HOLIDAYS_2026) —
// réutilisés ici pour le calcul du statut ouvert/fermé du marché en direct.
function getCasablancaMarketStatus() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Africa/Casablanca",
    weekday: "short",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(now);
  const get = (type) => parts.find((p) => p.type === type)?.value;
  const weekday = get("weekday");
  const isoDate = `${get("year")}-${get("month")}-${get("day")}`;
  const hour = parseInt(get("hour"), 10);
  const minute = parseInt(get("minute"), 10);
  const minutesNow = hour * 60 + minute;

  const isWeekday = !["Sat", "Sun"].includes(weekday);
  const isHoliday = MOROCCO_HOLIDAYS_2026.includes(isoDate);
  const openTime = 9 * 60 + 30; // 09h30
  const closeTime = 15 * 60 + 30; // 15h30
  const isOpen = isWeekday && !isHoliday && minutesNow >= openTime && minutesNow < closeTime;

  const hh = String(hour).padStart(2, "0");
  const mm = String(minute).padStart(2, "0");
  return { isOpen, isHoliday, timeLabel: `${hh}:${mm}` };
}

// Indices boursiers internationaux — instantané réel, source investing.com (début juillet 2026)
// Les cours évoluent en continu ; ceci est une photo à un instant T, pas un flux temps réel.
const globalIndicesDate = "clôture du 08/07/2026 (Nikkei 225 et S&P/ASX 200 : 07/07/2026)";
const globalIndices = [
  { nom: "S&P 500", pays: "États-Unis", valeur: "7 482,71", var: -0.28 },
  { nom: "Dow Jones", pays: "États-Unis", valeur: "52 348,39", var: -1.09 },
  { nom: "Nasdaq Composite", pays: "États-Unis", valeur: "25 870,65", var: 0.2 },
  { nom: "CAC 40", pays: "France", valeur: "8 252,66", var: -2.18 },
  { nom: "DAX", pays: "Allemagne", valeur: "24 897,45", var: -2.23 },
  { nom: "FTSE 100", pays: "Royaume-Uni", valeur: "10 489,04", var: -1.66 },
  { nom: "Nikkei 225", pays: "Japon", valeur: "66 819,05", var: -2.11 },
  { nom: "S&P/ASX 200", pays: "Australie", valeur: "8 785,10", var: -0.21 },
];

// Matières premières — instantané réel, source investing.com (fin juin / début juillet 2026)
const commodities = [
  { nom: "Or", unite: "$ / once", valeur: "4 030,68", var: -1.87 },
  { nom: "Argent", unite: "$ / once", valeur: "58,79", var: -4.15 },
  { nom: "Pétrole Brent", unite: "$ / baril", valeur: "78,15", var: 5.38 },
  { nom: "Gaz naturel", unite: "$ / MMBtu", valeur: "3,25", var: -0.03 },
  { nom: "Nickel", unite: "$ / tonne", valeur: "16 324,38", var: 0.04 },
];

// Contenu pédagogique — synthétisé à partir de casablanca-bourse.com et ammc.ma
const learnCards = [
  {
    title: "Qu'est-ce que la Bourse de Casablanca ?",
    text: "Fondée le 7 novembre 1929, la Bourse de Casablanca est l'une des plus anciennes places financières d'Afrique et la 2ᵉ du continent par capitalisation, derrière Johannesburg. C'est un marché réglementé où les entreprises marocaines lèvent des fonds en émettant des actions ou des obligations, et où les investisseurs achètent et revendent ces titres.",
  },
  {
    title: "Comment fonctionne une séance",
    text: "Le marché ouvre du lundi au vendredi : une phase de pré-ouverture permet de collecter les ordres, suivie du fixing puis de la cotation en continu. Les transactions ne peuvent se faire qu'à la Bourse, via une société de bourse agréée. Le règlement-livraison intervient 3 jours de bourse après la transaction (T+3), en dirham marocain.",
  },
  {
    title: "Les acteurs du marché",
    text: "La Bourse de Casablanca organise et fait fonctionner le marché. L'AMMC régule et surveille l'ensemble des intervenants. Maroclear, dépositaire central, assure la conservation des titres et le règlement des transactions. Les sociétés de bourse sont les seules habilitées à exécuter les ordres d'achat et de vente pour le compte des investisseurs.",
  },
  {
    title: "Le rôle de l'AMMC",
    text: "L'Autorité Marocaine du Marché des Capitaux a pour mission de protéger l'épargne investie en instruments financiers. Elle veille à l'égalité de traitement des épargnants, à la transparence du marché, contrôle les sociétés de gestion et de bourse, vise les notes d'information des émetteurs et contribue à l'éducation financière du public.",
  },
  {
    title: "Comment investir",
    text: "Avant d'investir, il s'agit de définir un objectif de placement, de s'informer sur les valeurs qui vous intéressent, puis d'ouvrir un compte-titres auprès d'un intermédiaire financier (banque ou société de bourse). Les ordres d'achat et de vente sont ensuite transmis à cet intermédiaire, qui les exécute sur le marché.",
  },
  {
    title: "L'introduction en bourse (IPO)",
    text: "S'introduire en bourse permet à une entreprise de lever des fonds, de gagner en notoriété et de moderniser sa gouvernance. Le marché principal s'adresse aux grandes entreprises, tandis que le marché alternatif est réservé aux PME (chiffre d'affaires, bilan ou effectifs sous certains seuils), avec des exigences allégées et des avantages fiscaux à la clé.",
  },
  {
    title: "Les indices phares : MASI et MADEX",
    text: "Le MASI (Moroccan All Shares Index) regroupe l'ensemble des sociétés cotées, pondérées par leur capitalisation flottante : c'est le baromètre général du marché. Le MADEX ne retient que les valeurs les plus liquides de la cote, pour une lecture plus resserrée de la tendance du marché.",
  },
  {
    title: "Se former : l'École de la Bourse",
    text: "Créée en 2000 par la Bourse de Casablanca, l'École de la Bourse propose des formations en présentiel et en ligne pour vulgariser les mécanismes boursiers auprès du grand public. Le Championnat de la Bourse, lui, permet de gérer virtuellement un portefeuille fictif d'un million de dirhams dans des conditions proches du marché réel.",
  },
];

// Calendrier des dividendes — structure et dates officielles reprises de casablanca-bourse.com
// (capture d'écran fournie par l'utilisateur, page "Calendrier des dividendes")
// Exercice 2025, dividendes versés en 2026. Pour les sociétés dont la date officielle
// n'a pas encore été communiquée, "À confirmer" est affiché plutôt qu'une date inventée.
const dividendStats = { distributrices: 52, sansDividende: 29, rendementMoyen: 3.48, cumul: 2460, suivies: 82 };

const dividend2026 = [
  { emetteur: "MAGHREB OXYGENE", secteur: "Matériaux", montant: 4, detachement: "24/03/2026", paiement: "02/04/2026", type: "Ordinaire" },
  { emetteur: "AFRIQUIA GAZ", secteur: "Énergie", montant: 175, detachement: "24/03/2026", paiement: "02/04/2026", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "22/04/2026", paiement: "04/05/2026", type: "Ordinaire" },
  { emetteur: "AUTO NEJMA", secteur: "Distribution", montant: 176, detachement: "30/04/2026", paiement: "11/05/2026", type: "Ordinaire" },
  { emetteur: "AUTO HALL", secteur: "Distribution", montant: 2, detachement: "15/05/2026", paiement: "26/05/2026", type: "Ordinaire" },
  { emetteur: "CREDIT DU MAROC", secteur: "Banques", montant: 48, detachement: "04/06/2026", paiement: "15/06/2026", type: "Ordinaire" },
  { emetteur: "CASH PLUS S.A", secteur: "Financement", montant: 9.73, detachement: "04/06/2026", paiement: "15/06/2026", type: "Ordinaire" },
  { emetteur: "SALAFIN", secteur: "Financement", montant: 30, detachement: "04/06/2026", paiement: "12/06/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE DES BOISSONS DU MAROC", secteur: "Agroalimentaire", montant: 107, detachement: "10/06/2026", paiement: "22/06/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE DES BOISSONS DU MAROC", secteur: "Agroalimentaire", montant: 20, detachement: "10/06/2026", paiement: "22/06/2026", type: "Exceptionnel" },
  { emetteur: "CFG BANK", secteur: "Banques", montant: 4, detachement: "10/06/2026", paiement: "22/06/2026", type: "Ordinaire" },
  { emetteur: "Holcim Maroc S.A", secteur: "Matériaux", montant: 96, detachement: "12/06/2026", paiement: "24/06/2026", type: "Ordinaire" },
  { emetteur: "WAFA ASSURANCE", secteur: "Assurances", montant: 150, detachement: "18/06/2026", paiement: "29/06/2026", type: "Ordinaire" },
  { emetteur: "TOTALENERGIES MARKETING MAROC", secteur: "Distribution", montant: 89.57, detachement: "18/06/2026", paiement: "29/06/2026", type: "Ordinaire" },
  { emetteur: "ATLANTASANAD", secteur: "Assurances", montant: 5.9, detachement: "19/06/2026", paiement: "30/06/2026", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 5.71, detachement: "19/06/2026", paiement: "30/06/2026", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 17.29, detachement: "19/06/2026", paiement: "30/06/2026", type: "Exceptionnel" },
  { emetteur: "AFRIC INDUSTRIES SA", secteur: "Biens d'équipement", montant: 20, detachement: "19/06/2026", paiement: "30/06/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE LES EAUX MINERALES D'OULMES", secteur: "Agroalimentaire", montant: 40.15, detachement: "19/06/2026", paiement: "30/06/2026", type: "Ordinaire" },
  { emetteur: "VICENNE", secteur: "Santé", montant: 8.44, detachement: "22/06/2026", paiement: "01/07/2026", type: "Ordinaire" },
  { emetteur: "RISMA", secteur: "Services", montant: 9, detachement: "22/06/2026", paiement: "01/07/2026", type: "Ordinaire" },
  { emetteur: "DISWAY", secteur: "Technologie", montant: 44, detachement: "24/06/2026", paiement: "03/07/2026", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 2.5, detachement: "24/06/2026", paiement: "03/07/2026", type: "Ordinaire" },
  { emetteur: "DISTY TECHNOLOGIES", secteur: "Technologie", montant: 19.5, detachement: "26/06/2026", paiement: "07/07/2026", type: "Ordinaire" },
  { emetteur: "LABEL VIE", secteur: "Distribution", montant: 120, detachement: "01/07/2026", paiement: "10/07/2026", type: "Ordinaire" },
  { emetteur: "MUTANDIS SCA", secteur: "Agroalimentaire", montant: 10.5, detachement: "01/07/2026", paiement: "10/07/2026", type: "Ordinaire" },
  { emetteur: "CREDIT IMMOBILIER ET HOTELIER", secteur: "Banques", montant: 14, detachement: "01/07/2026", paiement: "10/07/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE DE THERAPEUTIQUE MAROCAINE", secteur: "Pharmaceutiques", montant: 6.6, detachement: "01/07/2026", paiement: "10/07/2026", type: "Ordinaire" },
  { emetteur: "CIMENTS DU MAROC", secteur: "Matériaux", montant: 65, detachement: "06/07/2026", paiement: "15/07/2026", type: "Ordinaire" },
  { emetteur: "ENNAKL AUTOMOBILES", secteur: "Distributeurs", montant: 2.81, detachement: "06/07/2026", paiement: "15/07/2026", type: "Ordinaire" },
  { emetteur: "ATTIJARIWAFA BANK", secteur: "Banques", montant: 22, detachement: "08/07/2026", paiement: "17/07/2026", type: "Ordinaire" },
  { emetteur: "BANQUE CENTRALE POPULAIRE", secteur: "Banques", montant: 11, detachement: "09/07/2026", paiement: "20/07/2026", type: "Ordinaire" },
  { emetteur: "DELTA HOLDING", secteur: "Biens d'équipement", montant: 2, detachement: "13/07/2026", paiement: "22/07/2026", type: "Ordinaire" },
  { emetteur: "JET CONTRACTORS", secteur: "Biens d'équipement", montant: 20, detachement: "13/07/2026", paiement: "22/07/2026", type: "Ordinaire" },
  { emetteur: "ALUMINIUM DU MAROC", secteur: "Biens d'équipement", montant: 110, detachement: "14/07/2026", paiement: "23/07/2026", type: "Ordinaire" },
  { emetteur: "AGMA", secteur: "Assurances", montant: 310, detachement: "14/07/2026", paiement: "23/07/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE GENERALE DES TRAVAUX DU MAROC", secteur: "Biens d'équipement", montant: 12, detachement: "14/07/2026", paiement: "23/07/2026", type: "Ordinaire" },
  { emetteur: "MANAGEM", secteur: "Matériaux", montant: 55, detachement: "15/07/2026", paiement: "24/07/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE METALLURGIQUE D'IMITER", secteur: "Matériaux", montant: 150, detachement: "15/07/2026", paiement: "24/07/2026", type: "Ordinaire" },
  { emetteur: "HIGHTECH PAYMENT SYSTEMS", secteur: "Logiciels", montant: 8, detachement: "16/07/2026", paiement: "27/07/2026", type: "Ordinaire" },
  { emetteur: "BANK OF AFRICA", secteur: "Banques", montant: 5, detachement: "16/07/2026", paiement: "27/07/2026", type: "Ordinaire" },
  { emetteur: "BANQUE MAROCAINE POUR LE COMMERCE ET L'INDUSTRIE", secteur: "Banques", montant: 14, detachement: "17/07/2026", paiement: "28/07/2026", type: "Ordinaire" },
  { emetteur: "MICRODATA", secteur: "Logiciels", montant: 40, detachement: "17/07/2026", paiement: "28/07/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE D'EXPLOITATION DES PORTS - MARSA MAROC", secteur: "Transport", montant: 11, detachement: "17/07/2026", paiement: "28/07/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE NATIONALE DE SIDERURGIE SA", secteur: "Matériaux", montant: 52, detachement: "20/07/2026", paiement: "29/07/2026", type: "Ordinaire" },
  { emetteur: "ALLIANCES DEVELOPPEMENT IMMOBILIER SA", secteur: "Immobilier", montant: 4, detachement: "21/07/2026", paiement: "31/07/2026", type: "Ordinaire" },
  { emetteur: "COSUMAR", secteur: "Agroalimentaire", montant: 9, detachement: "22/07/2026", paiement: "03/08/2026", type: "Ordinaire" },
  { emetteur: "COSUMAR", secteur: "Agroalimentaire", montant: 1, detachement: "22/07/2026", paiement: "03/08/2026", type: "Exceptionnel" },
  { emetteur: "EQDOM", secteur: "Financement", montant: 57, detachement: "23/07/2026", paiement: "04/08/2026", type: "Ordinaire" },
  { emetteur: "BALIMA", secteur: "Immobilier", montant: 5.5, detachement: "24/07/2026", paiement: "05/08/2026", type: "Ordinaire" },
  { emetteur: "DARI COUSPATE", secteur: "Agroalimentaire", montant: 140, detachement: "31/07/2026", paiement: "11/08/2026", type: "Ordinaire" },
  { emetteur: "SANLAM MAROC", secteur: "Assurances", montant: 98, detachement: "19/08/2026", paiement: "03/09/2026", type: "Ordinaire" },
  { emetteur: "MAGHREBAIL", secteur: "Immobilier", montant: 53, detachement: "28/08/2026", paiement: "08/09/2026", type: "Ordinaire" },
  { emetteur: "ITISSALAT AL-MAGHRIB", secteur: "Télécommunications", montant: 4, detachement: "04/09/2026", paiement: "15/09/2026", type: "Ordinaire" },
  { emetteur: "SOCIETE DE PROMOTION PHARMACEUTIQUE DU MAGHREB S.A", secteur: "Pharmaceutiques", montant: 30, detachement: "11/09/2026", paiement: "22/09/2026", type: "Ordinaire" },
  { emetteur: "TAQA MOROCCO", secteur: "Utilities", montant: 38, detachement: "16/09/2026", paiement: "25/09/2026", type: "Ordinaire" },
];

const dividend2025Full = [
  { emetteur: "MAGHREB OXYGENE", secteur: "Matériaux", montant: 4, detachement: "25/03/2025", paiement: "08/04/2025", type: "Ordinaire" },
  { emetteur: "AFRIQUIA GAZ", secteur: "Énergie", montant: 175, detachement: "25/03/2025", paiement: "08/04/2025", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "18/04/2025", paiement: "29/04/2025", type: "Ordinaire" },
  { emetteur: "AUTO NEJMA", secteur: "Distribution", montant: 120, detachement: "22/05/2025", paiement: "02/06/2025", type: "Ordinaire" },
  { emetteur: "ENNAKL AUTOMOBILES", secteur: "Distributeurs", montant: 2.38, detachement: "27/05/2025", paiement: "05/06/2025", type: "Ordinaire" },
  { emetteur: "ATTIJARIWAFA BANK", secteur: "Banques", montant: 19, detachement: "27/05/2025", paiement: "05/06/2025", type: "Ordinaire" },
  { emetteur: "SALAFIN", secteur: "Financement", montant: 14.75, detachement: "06/06/2025", paiement: "17/06/2025", type: "Ordinaire" },
  { emetteur: "SALAFIN", secteur: "Financement", montant: 14.75, detachement: "06/06/2025", paiement: "17/06/2025", type: "Exceptionnel" },
  { emetteur: "SOCIETE DES BOISSONS DU MAROC", secteur: "Agroalimentaire", montant: 100, detachement: "10/06/2025", paiement: "19/06/2025", type: "Ordinaire" },
  { emetteur: "AFRIC INDUSTRIES SA", secteur: "Biens d'équipement", montant: 22, detachement: "10/06/2025", paiement: "19/06/2025", type: "Ordinaire" },
  { emetteur: "ATLANTASANAD", secteur: "Assurances", montant: 5.8, detachement: "10/06/2025", paiement: "19/06/2025", type: "Ordinaire" },
  { emetteur: "AUTO HALL", secteur: "Distribution", montant: 2, detachement: "10/06/2025", paiement: "18/06/2025", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 10.43, detachement: "11/06/2025", paiement: "20/06/2025", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 11.57, detachement: "11/06/2025", paiement: "20/06/2025", type: "Exceptionnel" },
  { emetteur: "COLORADO", secteur: "Chimie", montant: 2.6, detachement: "12/06/2025", paiement: "23/06/2025", type: "Ordinaire" },
  { emetteur: "Holcim Maroc S.A", secteur: "Matériaux", montant: 70, detachement: "13/06/2025", paiement: "24/06/2025", type: "Ordinaire" },
  { emetteur: "CFG BANK", secteur: "Banques", montant: 3.3, detachement: "13/06/2025", paiement: "24/06/2025", type: "Ordinaire" },
  { emetteur: "BANQUE MAROCAINE POUR LE COMMERCE ET L'INDUSTRIE", secteur: "Banques", montant: 18, detachement: "16/06/2025", paiement: "25/06/2025", type: "Ordinaire" },
  { emetteur: "WAFA ASSURANCE", secteur: "Assurances", montant: 140, detachement: "17/06/2025", paiement: "26/06/2025", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 2.2, detachement: "17/06/2025", paiement: "26/06/2025", type: "Ordinaire" },
  { emetteur: "SOCIETE LES EAUX MINERALES D'OULMES", secteur: "Agroalimentaire", montant: 23, detachement: "18/06/2025", paiement: "30/06/2025", type: "Ordinaire" },
  { emetteur: "TOTALENERGIES MARKETING MAROC", secteur: "Distribution", montant: 113, detachement: "19/06/2025", paiement: "30/06/2025", type: "Ordinaire" },
  { emetteur: "SOCIETE DE THERAPEUTIQUE MAROCAINE", secteur: "Pharmaceutiques", montant: 28, detachement: "20/06/2025", paiement: "02/07/2025", type: "Ordinaire" },
  { emetteur: "DISWAY", secteur: "Technologie", montant: 40, detachement: "30/06/2025", paiement: "09/07/2025", type: "Ordinaire" },
  { emetteur: "MUTANDIS SCA", secteur: "Agroalimentaire", montant: 10.5, detachement: "30/06/2025", paiement: "09/07/2025", type: "Ordinaire" },
  { emetteur: "LESIEUR CRISTAL", secteur: "Agroalimentaire", montant: 3, detachement: "30/06/2025", paiement: "09/07/2025", type: "Ordinaire" },
  { emetteur: "CREDIT IMMOBILIER ET HOTELIER", secteur: "Banques", montant: 14, detachement: "30/06/2025", paiement: "09/07/2025", type: "Ordinaire" },
  { emetteur: "SOCIETE METALLURGIQUE D'IMITER", secteur: "Matériaux", montant: 80, detachement: "30/06/2025", paiement: "08/07/2025", type: "Ordinaire" },
  { emetteur: "MANAGEM", secteur: "Matériaux", montant: 40, detachement: "30/06/2025", paiement: "08/07/2025", type: "Ordinaire" },
  { emetteur: "CREDIT DU MAROC", secteur: "Banques", montant: 41.7, detachement: "01/07/2025", paiement: "10/07/2025", type: "Ordinaire" },
  { emetteur: "DISTY TECHNOLOGIES", secteur: "Technologie", montant: 16.5, detachement: "09/07/2025", paiement: "18/07/2025", type: "Ordinaire" },
  { emetteur: "ALLIANCES DEVELOPPEMENT IMMOBILIER SA", secteur: "Immobilier", montant: 3.6, detachement: "10/07/2025", paiement: "21/07/2025", type: "Ordinaire" },
  { emetteur: "DELTA HOLDING", secteur: "Biens d'équipement", montant: 2.25, detachement: "10/07/2025", paiement: "21/07/2025", type: "Ordinaire" },
  { emetteur: "BANK OF AFRICA", secteur: "Banques", montant: 5, detachement: "10/07/2025", paiement: "21/07/2025", type: "Ordinaire" },
  { emetteur: "ALUMINIUM DU MAROC", secteur: "Biens d'équipement", montant: 100, detachement: "11/07/2025", paiement: "22/07/2025", type: "Ordinaire" },
  { emetteur: "AGMA", secteur: "Assurances", montant: 300, detachement: "15/07/2025", paiement: "24/07/2025", type: "Ordinaire" },
  { emetteur: "BANQUE CENTRALE POPULAIRE", secteur: "Banques", montant: 10.5, detachement: "15/07/2025", paiement: "24/07/2025", type: "Ordinaire" },
  { emetteur: "HIGHTECH PAYMENT SYSTEMS", secteur: "Logiciels", montant: 7, detachement: "16/07/2025", paiement: "25/07/2025", type: "Ordinaire" },
  { emetteur: "SOCIETE D'EXPLOITATION DES PORTS - MARSA MAROC", secteur: "Transport", montant: 9.5, detachement: "17/07/2025", paiement: "28/07/2025", type: "Ordinaire" },
  { emetteur: "CIMENTS DU MAROC", secteur: "Matériaux", montant: 60, detachement: "18/07/2025", paiement: "29/07/2025", type: "Ordinaire" },
  { emetteur: "BALIMA", secteur: "Immobilier", montant: 5.5, detachement: "18/07/2025", paiement: "29/07/2025", type: "Ordinaire" },
  { emetteur: "DARI COUSPATE", secteur: "Agroalimentaire", montant: 140, detachement: "18/07/2025", paiement: "29/07/2025", type: "Ordinaire" },
  { emetteur: "JET CONTRACTORS", secteur: "Biens d'équipement", montant: 15, detachement: "18/07/2025", paiement: "29/07/2025", type: "Ordinaire" },
  { emetteur: "MICRODATA", secteur: "Logiciels", montant: 40, detachement: "18/07/2025", paiement: "29/07/2025", type: "Ordinaire" },
  { emetteur: "COSUMAR", secteur: "Agroalimentaire", montant: 10, detachement: "21/07/2025", paiement: "31/07/2025", type: "Ordinaire" },
  { emetteur: "SOCIETE NATIONALE DE SIDERURGIE SA", secteur: "Matériaux", montant: 39, detachement: "21/07/2025", paiement: "31/07/2025", type: "Ordinaire" },
  { emetteur: "LABEL VIE", secteur: "Distribution", montant: 110.57, detachement: "21/07/2025", paiement: "31/07/2025", type: "Ordinaire" },
  { emetteur: "RISMA", secteur: "Services", montant: 7, detachement: "23/07/2025", paiement: "04/08/2025", type: "Ordinaire" },
  { emetteur: "AKDITAL", secteur: "Santé", montant: 10, detachement: "24/07/2025", paiement: "05/08/2025", type: "Ordinaire" },
  { emetteur: "TRAVAUX GENERAUX DE CONSTRUCTION DE CASABLANCA", secteur: "Biens d'équipement", montant: 11.5, detachement: "04/08/2025", paiement: "13/08/2025", type: "Ordinaire" },
  { emetteur: "SANLAM MAROC", secteur: "Assurances", montant: 81, detachement: "25/08/2025", paiement: "03/09/2025", type: "Ordinaire" },
  { emetteur: "MAGHREBAIL", secteur: "Immobilier", montant: 53, detachement: "27/08/2025", paiement: "08/09/2025", type: "Ordinaire" },
  { emetteur: "ITISSALAT AL-MAGHRIB", secteur: "Télécommunications", montant: 1.43, detachement: "01/09/2025", paiement: "12/09/2025", type: "Ordinaire" },
  { emetteur: "AFMA SA", secteur: "Assurances", montant: 60, detachement: "08/09/2025", paiement: "17/09/2025", type: "Ordinaire" },
  { emetteur: "CMGP GROUP", secteur: "Agriculture", montant: 6.3, detachement: "16/09/2025", paiement: "25/09/2025", type: "Ordinaire" },
  { emetteur: "TAQA MOROCCO", secteur: "Utilities", montant: 37, detachement: "16/09/2025", paiement: "25/09/2025", type: "Ordinaire" },
  { emetteur: "MAROC LEASING", secteur: "Financement", montant: 14, detachement: "17/09/2025", paiement: "26/09/2025", type: "Ordinaire" },
  { emetteur: "COMPAGNIE DE TRANSPORT AU MAROC", secteur: "Transport", montant: 25, detachement: "18/09/2025", paiement: "29/09/2025", type: "Ordinaire" },
  { emetteur: "DOUJA PROMOTION GROUPE ADDOHA SA", secteur: "Immobilier", montant: 0.5, detachement: "19/09/2025", paiement: "30/09/2025", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "23/09/2025", paiement: "02/10/2025", type: "Ordinaire" },
  { emetteur: "TOTALENERGIES MARKETING MAROC", secteur: "Distribution", montant: 67, detachement: "02/12/2025", paiement: "11/12/2025", type: "Exceptionnel" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "10/12/2025", paiement: "19/12/2025", type: "Ordinaire" },
];

const dividend2024Full = [
  { emetteur: "AFRIQUIA GAZ", secteur: "Énergie", montant: 140, detachement: "02/04/2024", paiement: "16/04/2024", type: "Ordinaire" },
  { emetteur: "MAGHREB OXYGENE", secteur: "Matériaux", montant: 4, detachement: "03/04/2024", paiement: "16/04/2024", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "22/04/2024", paiement: "30/04/2024", type: "Ordinaire" },
  { emetteur: "AUTO NEJMA", secteur: "Distribution", montant: 94, detachement: "23/05/2024", paiement: "03/06/2024", type: "Ordinaire" },
  { emetteur: "SALAFIN", secteur: "Financement", montant: 14.25, detachement: "27/05/2024", paiement: "05/06/2024", type: "Ordinaire" },
  { emetteur: "SALAFIN", secteur: "Financement", montant: 14.25, detachement: "27/05/2024", paiement: "05/06/2024", type: "Exceptionnel" },
  { emetteur: "SOCIETE DES BOISSONS DU MAROC", secteur: "Agroalimentaire", montant: 160, detachement: "06/06/2024", paiement: "20/06/2024", type: "Ordinaire" },
  { emetteur: "COLORADO", secteur: "Chimie", montant: 2.25, detachement: "06/06/2024", paiement: "20/06/2024", type: "Ordinaire" },
  { emetteur: "Holcim Maroc S.A", secteur: "Matériaux", montant: 66, detachement: "06/06/2024", paiement: "20/06/2024", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 2.2, detachement: "11/06/2024", paiement: "24/06/2024", type: "Ordinaire" },
  { emetteur: "WAFA ASSURANCE", secteur: "Assurances", montant: 140, detachement: "11/06/2024", paiement: "26/06/2024", type: "Ordinaire" },
  { emetteur: "CFG BANK", secteur: "Banques", montant: 3.3, detachement: "11/06/2024", paiement: "24/06/2024", type: "Ordinaire" },
  { emetteur: "TOTALENERGIES MARKETING MAROC", secteur: "Distribution", montant: 56, detachement: "19/06/2024", paiement: "27/06/2024", type: "Ordinaire" },
  { emetteur: "AUTO HALL", secteur: "Distribution", montant: 2, detachement: "20/06/2024", paiement: "01/07/2024", type: "Ordinaire" },
  { emetteur: "ATLANTASANAD", secteur: "Assurances", montant: 5.7, detachement: "20/06/2024", paiement: "28/06/2024", type: "Ordinaire" },
  { emetteur: "EQDOM", secteur: "Financement", montant: 55, detachement: "20/06/2024", paiement: "01/07/2024", type: "Ordinaire" },
  { emetteur: "SOCIETE METALLURGIQUE D'IMITER", secteur: "Matériaux", montant: 80, detachement: "20/06/2024", paiement: "01/07/2024", type: "Ordinaire" },
  { emetteur: "LABEL VIE", secteur: "Distribution", montant: 96.75, detachement: "20/06/2024", paiement: "01/07/2024", type: "Ordinaire" },
  { emetteur: "MANAGEM", secteur: "Matériaux", montant: 30, detachement: "20/06/2024", paiement: "01/07/2024", type: "Ordinaire" },
  { emetteur: "TAQA MOROCCO", secteur: "Utilities", montant: 35, detachement: "20/06/2024", paiement: "28/06/2024", type: "Ordinaire" },
  { emetteur: "SOCIETE DE THERAPEUTIQUE MAROCAINE", secteur: "Pharmaceutiques", montant: 17, detachement: "21/06/2024", paiement: "02/07/2024", type: "Ordinaire" },
  { emetteur: "DISWAY", secteur: "Technologie", montant: 35, detachement: "25/06/2024", paiement: "04/07/2024", type: "Ordinaire" },
  { emetteur: "LESIEUR CRISTAL", secteur: "Agroalimentaire", montant: 2, detachement: "26/06/2024", paiement: "05/07/2024", type: "Ordinaire" },
  { emetteur: "SOCIETE LES EAUX MINERALES D'OULMES", secteur: "Agroalimentaire", montant: 22, detachement: "26/06/2024", paiement: "05/07/2024", type: "Ordinaire" },
  { emetteur: "MUTANDIS SCA", secteur: "Agroalimentaire", montant: 10.5, detachement: "27/06/2024", paiement: "10/07/2024", type: "Ordinaire" },
  { emetteur: "CIMENTS DU MAROC", secteur: "Matériaux", montant: 60, detachement: "02/07/2024", paiement: "15/07/2024", type: "Ordinaire" },
  { emetteur: "CIMENTS DU MAROC", secteur: "Matériaux", montant: 10, detachement: "02/07/2024", paiement: "15/07/2024", type: "Exceptionnel" },
  { emetteur: "JET CONTRACTORS", secteur: "Biens d'équipement", montant: 7, detachement: "09/07/2024", paiement: "18/07/2024", type: "Ordinaire" },
  { emetteur: "DISTY TECHNOLOGIES", secteur: "Technologie", montant: 15, detachement: "09/07/2024", paiement: "18/07/2024", type: "Ordinaire" },
  { emetteur: "CREDIT DU MAROC", secteur: "Banques", montant: 34.2, detachement: "09/07/2024", paiement: "18/07/2024", type: "Ordinaire" },
  { emetteur: "CREDIT IMMOBILIER ET HOTELIER", secteur: "Banques", montant: 14, detachement: "09/07/2024", paiement: "18/07/2024", type: "Ordinaire" },
  { emetteur: "DELTA HOLDING", secteur: "Biens d'équipement", montant: 1.5, detachement: "10/07/2024", paiement: "19/07/2024", type: "Ordinaire" },
  { emetteur: "ENNAKL AUTOMOBILES", secteur: "Distributeurs", montant: 1.99, detachement: "10/07/2024", paiement: "19/07/2024", type: "Ordinaire" },
  { emetteur: "ATTIJARIWAFA BANK", secteur: "Banques", montant: 16.5, detachement: "10/07/2024", paiement: "19/07/2024", type: "Ordinaire" },
  { emetteur: "ALLIANCES DEVELOPPEMENT IMMOBILIER SA", secteur: "Immobilier", montant: 3, detachement: "11/07/2024", paiement: "22/07/2024", type: "Ordinaire" },
  { emetteur: "COSUMAR", secteur: "Agroalimentaire", montant: 7, detachement: "11/07/2024", paiement: "22/07/2024", type: "Ordinaire" },
  { emetteur: "COSUMAR", secteur: "Agroalimentaire", montant: 3, detachement: "11/07/2024", paiement: "22/07/2024", type: "Exceptionnel" },
  { emetteur: "SOCIETE NATIONALE DE SIDERURGIE SA", secteur: "Matériaux", montant: 21, detachement: "12/07/2024", paiement: "23/07/2024", type: "Ordinaire" },
  { emetteur: "TRAVAUX GENERAUX DE CONSTRUCTION DE CASABLANCA", secteur: "Biens d'équipement", montant: 7.5, detachement: "12/07/2024", paiement: "23/07/2024", type: "Ordinaire" },
  { emetteur: "MICRODATA", secteur: "Logiciels", montant: 34, detachement: "15/07/2024", paiement: "24/07/2024", type: "Ordinaire" },
  { emetteur: "BALIMA", secteur: "Immobilier", montant: 5.5, detachement: "16/07/2024", paiement: "25/07/2024", type: "Ordinaire" },
  { emetteur: "AFRIC INDUSTRIES SA", secteur: "Biens d'équipement", montant: 20, detachement: "16/07/2024", paiement: "25/07/2024", type: "Ordinaire" },
  { emetteur: "AGMA", secteur: "Assurances", montant: 275, detachement: "16/07/2024", paiement: "25/07/2024", type: "Ordinaire" },
  { emetteur: "HIGHTECH PAYMENT SYSTEMS", secteur: "Logiciels", montant: 6.8, detachement: "17/07/2024", paiement: "26/07/2024", type: "Ordinaire" },
  { emetteur: "BANK OF AFRICA", secteur: "Banques", montant: 4, detachement: "17/07/2024", paiement: "26/07/2024", type: "Ordinaire" },
  { emetteur: "BANQUE MAROCAINE POUR LE COMMERCE ET L'INDUSTRIE", secteur: "Banques", montant: 18, detachement: "17/07/2024", paiement: "26/07/2024", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 5.88, detachement: "18/07/2024", paiement: "29/07/2024", type: "Ordinaire" },
  { emetteur: "ARADEI CAPITAL", secteur: "Immobilier", montant: 14.59, detachement: "18/07/2024", paiement: "29/07/2024", type: "Exceptionnel" },
  { emetteur: "RISMA", secteur: "Services", montant: 6, detachement: "18/07/2024", paiement: "29/07/2024", type: "Ordinaire" },
  { emetteur: "DARI COUSPATE", secteur: "Agroalimentaire", montant: 120, detachement: "18/07/2024", paiement: "29/07/2024", type: "Ordinaire" },
  { emetteur: "BANQUE CENTRALE POPULAIRE", secteur: "Banques", montant: 10, detachement: "19/07/2024", paiement: "31/07/2024", type: "Ordinaire" },
  { emetteur: "SOCIETE D'EXPLOITATION DES PORTS - MARSA MAROC", secteur: "Transport", montant: 8.5, detachement: "24/07/2024", paiement: "07/08/2024", type: "Ordinaire" },
  { emetteur: "AKDITAL", secteur: "Santé", montant: 6, detachement: "31/07/2024", paiement: "09/08/2024", type: "Ordinaire" },
  { emetteur: "ALUMINIUM DU MAROC", secteur: "Biens d'équipement", montant: 90, detachement: "01/08/2024", paiement: "09/08/2024", type: "Ordinaire" },
  { emetteur: "MAGHREBAIL", secteur: "Immobilier", montant: 50, detachement: "06/08/2024", paiement: "15/08/2024", type: "Ordinaire" },
  { emetteur: "SANLAM MAROC", secteur: "Assurances", montant: 77, detachement: "22/08/2024", paiement: "30/08/2024", type: "Ordinaire" },
  { emetteur: "AFMA SA", secteur: "Assurances", montant: 55, detachement: "03/09/2024", paiement: "12/09/2024", type: "Ordinaire" },
  { emetteur: "ITISSALAT AL-MAGHRIB", secteur: "Télécommunications", montant: 4.2, detachement: "03/09/2024", paiement: "12/09/2024", type: "Ordinaire" },
  { emetteur: "UNIMER", secteur: "Agroalimentaire", montant: 1, detachement: "09/09/2024", paiement: "20/09/2024", type: "Ordinaire" },
  { emetteur: "COMPAGNIE DE TRANSPORT AU MAROC", secteur: "Transport", montant: 15, detachement: "10/09/2024", paiement: "23/09/2024", type: "Ordinaire" },
  { emetteur: "MAROC LEASING", secteur: "Financement", montant: 14, detachement: "18/09/2024", paiement: "27/09/2024", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "19/09/2024", paiement: "30/09/2024", type: "Ordinaire" },
  { emetteur: "IMMORENTE INVEST", secteur: "Immobilier", montant: 1, detachement: "11/12/2024", paiement: "20/12/2024", type: "Ordinaire" },
];

const dividendByYear = {
  "2026": { data: dividend2026, label: "Calendrier des dividendes 2026", note: "Exercice 2025 · versements en 2026" },
  "2025": { data: dividend2025Full, label: "Calendrier des dividendes 2025", note: "Exercice 2024 · versements en 2025" },
  "2024": { data: dividend2024Full, label: "Calendrier des dividendes 2024", note: "Exercice 2023 · versements en 2024" },
};

const dividendSansDividende2026 = [
  "BALIMA", "BMCI", "Banque Centrale Populaire", "Cartier Saada", "Dari Couspate", "Delattre Levivier Maroc",
  "Diac Salaf", "Douja Prom Addoha", "Fenie Brossette", "IB Maroc.com", "Involys", "Lesieur Cristal", "Lydec",
  "M2M Group", "Maroc Leasing", "Med Paper", "Minière Touissit", "Réalisations Mécaniques", "Rebab Company",
  "Res Dar Saada", "S.M Monétique", "Snep", "Stokvis Nord Afrique", "Stroc Industrie", "Samir",
  "TotalEnergies Marketing Maroc", "Timar", "Unimer", "Zellidja",
];

// Historique 2025 — dividendes réellement versés au titre de l'exercice 2025
// (source : casablancabourse.com, classement des entreprises par dividendes yield 2025)
const dividend2025Stats = { total: 80, distributrices: 56, rendementMoyen: 3.1, montantMoyen: 41.77 };
const dividend2025Top = [
  { code: "NKL", nom: "Ennakl", rendement: 6.78, montant: 2.38 },
  { code: "AFI", nom: "Afric Industries", rendement: 6.41, montant: 22.0 },
  { code: "TMA", nom: "TotalEnergies Marketing Maroc", rendement: 6.01, montant: 113.0 },
  { code: "NEJ", nom: "Auto Nejma", rendement: 5.8, montant: 120.0 },
  { code: "IMO", nom: "Immorente Invest", rendement: 5.78, montant: 4.2 },
  { code: "MAB", nom: "Maghrebail", rendement: 5.3, montant: 53.0 },
  { code: "ALM", nom: "Aluminium du Maroc", rendement: 5.09, montant: 100.0 },
  { code: "DWY", nom: "Disway", rendement: 5.03, montant: 40.0 },
  { code: "ARD", nom: "Aradei Capital", rendement: 4.95, montant: 22.0 },
  { code: "SLF", nom: "Salafin", rendement: 4.56, montant: 29.5 },
];

// Capitalisation boursière — top 5 réel, séance du 13 mai 2026
// (source : La Vie Éco)
const capDate = "13 mai 2026";
const capTop5 = [
  { code: "MNG", nom: "Managem", secteur: "Mines", cap: 168.0 },
  { code: "ATW", nom: "Attijariwafa Bank", secteur: "Banques", cap: 148.7 },
  { code: "IAM", nom: "Maroc Telecom", secteur: "Télécommunications", cap: 82.6 },
  { code: "MSA", nom: "Marsa Maroc", secteur: "Transport & logistique", cap: 61.8 },
  { code: "BCP", nom: "Banque Centrale Populaire", secteur: "Banques", cap: 48.6 },
];
const capMarketStats = { total: 1000, societes: 79, secteurBanques: 35, secteurTelecoms: 17.7 };

// Univers de valeurs pour le simulateur de portefeuille — cours réels récents
// (source : investing.com et casablancabourse.com, début juillet 2026, sauf mention contraire)
const stocksUniverse = [
  { code: "IAM", nom: "Maroc Telecom", cours: 92.2 },
  { code: "ATW", nom: "Attijariwafa Bank", cours: 680.0 },
  { code: "BCP", nom: "Banque Centrale Populaire", cours: 239.8 },
  { code: "CIH", nom: "CIH Bank", cours: 398.5 },
  { code: "BOA", nom: "Bank of Africa", cours: 202.3 },
  { code: "CFG", nom: "CFG Bank", cours: 203.0 },
  { code: "LHM", nom: "LafargeHolcim Maroc", cours: 1780.0 },
  { code: "CMA", nom: "Ciments du Maroc", cours: 1650.0 },
  { code: "SID", nom: "Sonasid", cours: 1989.0 },
  { code: "MNG", nom: "Managem", cours: 12822.0 },
  { code: "ADH", nom: "Douja Prom Addoha", cours: 31.9 },
  { code: "TQM", nom: "Taqa Morocco", cours: 1042.0 },
  { code: "SNP", nom: "Snep", cours: 348.0 },
  { code: "RIS", nom: "Risma", cours: 322.5 },
  { code: "DHO", nom: "Delta Holding", cours: 60.0 },
  { code: "MSA", nom: "Marsa Maroc", cours: 828.0 },
  { code: "CSR", nom: "Cosumar", cours: 280.0 },
  { code: "WAA", nom: "Wafa Assurance", cours: 5620.0 },
  { code: "LBV", nom: "Label'Vie", cours: 3950.0 },
  { code: "GAZ", nom: "Afriquia Gaz", cours: 3812.0 },
  { code: "NEJ", nom: "Auto Nejma", cours: 4834.0 },
  { code: "SBM", nom: "Sté des Boissons du Maroc", cours: 2449.0 },
  { code: "AGM", nom: "AGMA", cours: 7199.0 },
  { code: "ALM", nom: "Aluminium du Maroc", cours: 1896.0 },
];

function Variation({ value, size = "md" }) {
  const up = value >= 0;
  const Icon = up ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={`variation ${up ? "up" : "down"} ${size}`}>
      <Icon size={size === "lg" ? 18 : 14} strokeWidth={2.5} />
      {up ? "+" : ""}{value.toFixed(2)}%
    </span>
  );
}

function PercentCell({ value }) {
  const v = value ?? 0;
  const cls = v > 0 ? "up" : v < 0 ? "down" : "flat";
  const sign = v > 0 ? "+" : "";
  return <td className={`perf-cell ${cls}`}>{sign}{v.toFixed(2)}%</td>;
}


export default function Sahm() {
  const [tab, setTab] = useState(opcvmCategoryList[0]);
  const [opcvmPageTab, setOpcvmPageTab] = useState(opcvmCategoryList[0]);
  const [opcvmSearch, setOpcvmSearch] = useState("");
  const [selectedOpcvm, setSelectedOpcvm] = useState(null);
  const [actionsData, setActionsData] = useState(null);
  const [actionsSearch, setActionsSearch] = useState("");
  const [selectedAction, setSelectedAction] = useState(null);
  // morningBriefs est une constante statique déjà chargée (pas un fetch
  // async comme actionsData) — on peut donc restaurer le brief précis
  // directement à l'initialisation, avant que l'effet de synchronisation
  // d'URL ne réécrive le chemin sans le connaître (ce qui écraserait la
  // date et casserait le lien "Lire le brief complet" reçu par email).
  const [selectedBrief, setSelectedBrief] = useState(() => {
    const [first, briefDate] = parsePath();
    if (first === "brief-detail" && briefDate) {
      return morningBriefs.find((b) => b.date === briefDate) || null;
    }
    return null;
  });

  // Favoris (watchlist)
  const [favoris, setFavoris] = useState(() => {
    try { return JSON.parse(localStorage.getItem("sahm-favoris") || "[]"); } catch { return []; }
  });
  React.useEffect(() => {
    try { localStorage.setItem("sahm-favoris", JSON.stringify(favoris)); } catch {}
  }, [favoris]);
  const toggleFavori = (ticker) => {
    setFavoris((prev) => prev.includes(ticker) ? prev.filter((t) => t !== ticker) : [...prev, ticker]);
  };

  // Navigue vers la fiche détail d'une action à partir de son nom (palmarès, etc.)
  const goToActionByName = (name) => {
    if (!actionsData?.companies || !name) return;
    const norm = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
    const target = norm(name);
    const found = actionsData.companies.find((c) => {
      const cn = norm(c.nom);
      return cn === target || cn.includes(target) || target.includes(cn);
    });
    if (found) {
      setSelectedAction(found);
      setPage("actions-detail");
      window.scrollTo(0, 0);
    }
  };
  const [showFavorisOnly, setShowFavorisOnly] = useState(false);

  // Comparateur d'actions
  const [compareTickers, setCompareTickers] = useState(["", "", ""]);

  // Tri du tableau des actions (PER, rendement, capitalisation…)
  const [actionsSortKey, setActionsSortKey] = useState(null);
  const [actionsSortDir, setActionsSortDir] = useState("desc");
  const toggleActionsSort = (key) => {
    if (actionsSortKey === key) {
      setActionsSortDir((d) => (d === "desc" ? "asc" : "desc"));
    } else {
      setActionsSortKey(key);
      setActionsSortDir("desc");
    }
  };

  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/actions.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setActionsData(data);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const [historiqueCache, setHistoriqueCache] = useState({});
  const [histRange, setHistRange] = useState("1A");
  React.useEffect(() => {
    const ticker = selectedAction?.ticker;
    if (!ticker || historiqueCache[ticker] !== undefined) return;
    let cancelled = false;
    fetch(`/data/historique/${ticker}.json`, { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled) setHistoriqueCache((prev) => ({ ...prev, [ticker]: data || [] }));
      })
      .catch(() => {
        if (!cancelled) setHistoriqueCache((prev) => ({ ...prev, [ticker]: [] }));
      });
    return () => { cancelled = true; };
  }, [selectedAction]);
  const VALID_PAGES = ["accueil", "apprendre", "seance", "opcvm", "actions", "comparateur", "data", "portefeuille", "actions-detail", "opcvm-detail", "brief-detail", "obligataire", "actualites"];

  // Convertit le chemin d'URL actuel (ex: "/actions/ATW") en ["actions", "ATW"]
  function parsePath() {
    try {
      const parts = window.location.pathname.replace(/^\/|\/$/g, "").split("/").filter(Boolean);
      return parts.length ? parts : ["accueil"];
    } catch { return ["accueil"]; }
  }

  const [page, setPage] = useState(() => {
    const [first] = parsePath();
    return VALID_PAGES.includes(first) ? first : "accueil";
  });

  // Garde l'URL (le vrai chemin, pas une ancre #) synchronisée avec la page
  // affichée — survit au F5, le bouton précédent/suivant du navigateur
  // fonctionne, et chaque page est une vraie URL indexable par Google
  // (ex: bourseinfo.ma/actions, bourseinfo.ma/seance...).
  React.useEffect(() => {
    try {
      let path = page === "accueil" ? "/" : `/${page}/`;
      if (page === "actions-detail" && selectedAction?.ticker) path = `/actions-detail/${selectedAction.ticker}`;
      if (page === "brief-detail" && selectedBrief?.date) path = `/brief-detail/${selectedBrief.date}`;
      if (window.location.pathname !== path) window.history.pushState(null, "", path);
    } catch {}
  }, [page, selectedAction, selectedBrief]);

  React.useEffect(() => {
    const onPopState = () => {
      const [first] = parsePath();
      if (VALID_PAGES.includes(first)) setPage(first);
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  // Restaure la fiche action précise si l'URL pointe dessus après un F5
  React.useEffect(() => {
    if (!actionsData?.companies) return;
    const [first, ticker] = parsePath();
    if (first === "actions-detail" && ticker && !selectedAction) {
      const found = actionsData.companies.find((c) => c.ticker === ticker);
      if (found) setSelectedAction(found);
      else setPage("actions");
    }
  }, [actionsData]);

  React.useEffect(() => {
    if (page === "opcvm-detail" && !selectedOpcvm) {
      setPage("opcvm");
    }
  }, [page, selectedOpcvm]);

  // Si on arrive sur brief-detail sans brief sélectionné (lien invalide/
  // ancien, ou navigation directe) et que la restauration à l'init n'a rien
  // trouvé, retombe sur l'accueil.
  React.useEffect(() => {
    if (page === "brief-detail" && !selectedBrief) {
      setPage("accueil");
    }
  }, [page, selectedBrief]);

  // Titre + meta description propres à chaque page — utile pour l'utilisateur
  // (onglet du navigateur) et pour le référencement (Google lit le titre
  // après exécution du JavaScript).
  React.useEffect(() => {
    const pageMeta = {
      "accueil": ["BourseInfo.ma — Votre référence pour les marchés financiers marocains", "Cours en direct, indices MASI, palmarès de la séance et actualité quotidienne de la Bourse de Casablanca."],
      "apprendre": ["Apprendre la Bourse — BourseInfo.ma", "Guides et lexique pour comprendre les marchés financiers marocains, du débutant à l'investisseur confirmé."],
      "seance": ["Séance Boursière en direct — BourseInfo.ma", "Indices MASI, MASI 20, MASI ESG, palmarès et tableau complet des valeurs cotées à la Bourse de Casablanca."],
      "opcvm": ["OPCVM Maroc — Classement et performances — BourseInfo.ma", "Classement des OPCVM marocains par catégorie, performances et rendements à jour."],
      "actions": ["Actions cotées à la Bourse de Casablanca — BourseInfo.ma", "Cours, PER, rendement du dividende et fiches détaillées de toutes les sociétés cotées à la Bourse de Casablanca."],
      "actions-detail": [selectedAction ? `${selectedAction.nom} (${selectedAction.ticker}) — Cours et analyse — BourseInfo.ma` : "Fiche action — BourseInfo.ma", selectedAction ? `Cours, capitalisation, PER, dividende et historique des cours de ${selectedAction.nom} à la Bourse de Casablanca.` : ""],
      "comparateur": ["Comparateur d'actions marocaines — BourseInfo.ma", "Comparez PER, rendement, capitalisation et marges de plusieurs sociétés cotées à la Bourse de Casablanca."],
      "obligataire": ["Marché obligataire marocain — Courbe des taux — BourseInfo.ma", "Courbe des taux du marché obligataire marocain, adjudications du Trésor et évolution des taux."],
      "data": ["Calendrier des dividendes — Bourse de Casablanca — BourseInfo.ma", "Calendrier complet des dividendes versés par les sociétés cotées à la Bourse de Casablanca."],
      "portefeuille": ["Mon Portefeuille — BourseInfo.ma", "Suivez la performance de votre portefeuille d'actions marocaines virtuel."],
      "actualites": ["Actualité des marchés marocains — BourseInfo.ma", "Le Morning Brief quotidien et les rapports hebdomadaires sur les marchés financiers marocains."],
      "brief-detail": [selectedBrief ? `${selectedBrief.titre} — BourseInfo.ma` : "Actualité — BourseInfo.ma", selectedBrief?.resumeCourt || ""],
    };
    const [title, description] = pageMeta[page] || pageMeta["accueil"];
    document.title = title;
    let meta = document.querySelector('meta[name="description"]');
    if (meta && description) meta.setAttribute("content", description);
  }, [page, selectedAction, selectedBrief]);

  const [dataTab, setDataTab] = useState("dividendes");
  const [dividendYear, setDividendYear] = useState("2026");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [allPagesOpen, setAllPagesOpen] = useState(false);
  const [marketStatus, setMarketStatus] = useState(() => getCasablancaMarketStatus());

  React.useEffect(() => {
    const id = setInterval(() => setMarketStatus(getCasablancaMarketStatus()), 30000);
    return () => clearInterval(id);
  }, []);

  // MASI en direct (mis à jour toutes les 15 min par un robot GitHub,
  // source e-bourse.ma — plateforme officielle de la Bourse de Casablanca)
  const [marketData, setMarketData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/masi.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setMarketData(data);
      })
      .catch(() => {
        // Pas grave — le site retombe sur la donnée statique de secours
      });
    return () => { cancelled = true; };
  }, []);

  // Palmarès en direct (mis à jour toutes les 15 min par un robot GitHub,
  // source casablancabourse.com — site tiers, cours parfois retardés)
  const [palmaresData, setPalmaresData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/palmares.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setPalmaresData(data);
      })
      .catch(() => {
        // Pas grave — le site retombe sur le widget TradingView
      });
    return () => { cancelled = true; };
  }, []);

  // Top OPCVM en direct (mis à jour toutes les 15 min par un robot GitHub,
  // source API ASFIM)
  const [opcvmData, setOpcvmData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/opcvm.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setOpcvmData(data);
      })
      .catch(() => {
        // Pas grave — le site retombe sur les données statiques de secours
      });
    return () => { cancelled = true; };
  }, []);

  // Capitalisation boursière (mise à jour manuelle, transmise par capture d'écran)
  const [capData, setCapData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/capitalisation.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setCapData(data);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Courbe des taux (marché obligataire) — historique quotidien depuis 2025
  const [courbeTauxData, setCourbeTauxData] = useState(null);
  const [courbeTauxDate, setCourbeTauxDate] = useState(null);
  const [courbeTauxMaturite, setCourbeTauxMaturite] = useState("10A");
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/courbe_taux.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data && data.length) {
          setCourbeTauxData(data);
          setCourbeTauxDate(data[data.length - 1].date);
        }
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  const maturitesListe = [
    { key: "13S", label: "13 sem." },
    { key: "26S", label: "26 sem." },
    { key: "52S", label: "52 sem." },
    { key: "2A", label: "2 ans" },
    { key: "5A", label: "5 ans" },
    { key: "10A", label: "10 ans" },
    { key: "15A", label: "15 ans" },
    { key: "20A", label: "20 ans" },
    { key: "30A", label: "30 ans" },
  ];

  // Comparaison de la courbe des taux : dernière séance vs J-1, rendu façon
  // "bougie" (barre flottante entre les deux valeurs, verte si le taux a
  // monté, rouge si le taux a baissé).
  function renderCourbeComparaison() {
    if (!courbeTauxData || courbeTauxData.length < 2) return null;
    const dernier = courbeTauxData[courbeTauxData.length - 1];
    const precedent = courbeTauxData[courbeTauxData.length - 2];
    const data = maturitesListe.map((m) => {
      const a = precedent[m.key];
      const b = dernier[m.key];
      const variationPbs = (b - a) * 100; // 1% = 100 points de base
      return { maturite: m.label, j1: a, jour: b, variationPbs };
    });
    return (
      <>
        <div className="section-head">
          <div className="section-title" style={{ fontSize: 20 }}>Variation des taux (J vs J-1)</div>
          <div className="section-note">
            {new Date(precedent.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}
            {" → "}
            {new Date(dernier.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}
          </div>
        </div>
        <div className="official-table-card" style={{ marginBottom: 36 }}>
          <div className="cap-table-scroll">
            <table className="official-table">
              <thead>
                <tr>
                  <th>Maturité</th>
                  <th style={{ textAlign: "right" }}>Taux J-1</th>
                  <th style={{ textAlign: "right" }}>Taux J</th>
                  <th style={{ textAlign: "right" }}>Variation</th>
                </tr>
              </thead>
              <tbody>
                {data.map((d) => {
                  const hausse = d.variationPbs >= 0;
                  // Couleur inversée par rapport à une variation "classique" : une
                  // hausse des taux fait baisser le prix des obligations (rouge),
                  // une baisse des taux fait monter leur prix (vert).
                  return (
                    <tr key={d.maturite}>
                      <td className="official-emetteur">{d.maturite}</td>
                      <td className="mono" style={{ textAlign: "right", color: "var(--ink-soft)" }}>{d.j1.toFixed(3)}%</td>
                      <td className="mono" style={{ textAlign: "right", fontWeight: 600 }}>{d.jour.toFixed(3)}%</td>
                      <td style={{ textAlign: "right" }}>
                        <span className={`variation ${hausse ? "down" : "up"} md`}>
                          {hausse ? "+" : "−"}{Math.abs(d.variationPbs).toFixed(1)} pbs
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }

  // Évolution d'une maturité choisie dans le temps, sur tout l'historique disponible.
  function renderEvolutionTaux() {
    if (!courbeTauxData || courbeTauxData.length < 2) return null;
    return (
      <>
        <div className="section-head">
          <div className="section-title" style={{ fontSize: 20 }}>Évolution de la courbe dans le temps</div>
          <div className="section-note">Depuis le {new Date(courbeTauxData[0].date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
          {maturitesListe.map((m) => (
            <button
              key={m.key}
              onClick={() => setCourbeTauxMaturite(m.key)}
              style={{
                fontSize: 12, padding: "6px 14px", borderRadius: 16,
                border: "1px solid var(--hairline)",
                background: courbeTauxMaturite === m.key ? "var(--gold)" : "transparent",
                color: courbeTauxMaturite === m.key ? "#fff" : "var(--ink-soft)",
                cursor: "pointer", fontFamily: "inherit",
              }}
            >
              {m.label}
            </button>
          ))}
        </div>
        <div className="opcvm-card" style={{ padding: 20 }}>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={courbeTauxData}>
              <CartesianGrid stroke="var(--hairline)" strokeDasharray="3 3" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 11, fill: "var(--ink-soft)" }}
                interval={Math.max(1, Math.floor(courbeTauxData.length / 6))}
                tickFormatter={(v) => new Date(v).toLocaleDateString("fr-FR", { month: "short", year: "2-digit" })}
              />
              <YAxis tick={{ fontSize: 11, fill: "var(--ink-soft)" }} unit="%" width={48} domain={["auto", "auto"]} />
              <Tooltip
                formatter={(v) => [`${v.toFixed(3)}%`, "Taux"]}
                labelFormatter={(v) => new Date(v).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
              />
              <Line type="monotone" dataKey={courbeTauxMaturite} stroke="var(--green)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </>
    );
  }

  // Instruments les plus actifs par volume (mise à jour manuelle)
  const [volumesData, setVolumesData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/volumes_actifs.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setVolumesData(data);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Séance boursière — tableau complet (mise à jour manuelle via fichier Excel)
  const [seanceBourseData, setSeanceBourseData] = useState(null);
  React.useEffect(() => {
    let cancelled = false;
    fetch("/data/seance_bourse.json", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setSeanceBourseData(data);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Authentification (Supabase) — pour "Mon Portefeuille"
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authMode, setAuthMode] = useState("signin"); // "signin" | "signup"
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authError, setAuthError] = useState(null);
  const [authMessage, setAuthMessage] = useState(null);
  const [authBusy, setAuthBusy] = useState(false);
  const [showAuthPassword, setShowAuthPassword] = useState(false);

  React.useEffect(() => {
    let cancelled = false;
    supabase.auth.getSession().then(({ data }) => {
      if (!cancelled) {
        setUser(data.session?.user || null);
        setAuthLoading(false);
      }
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => {
      cancelled = true;
      listener.subscription.unsubscribe();
    };
  }, []);

  async function handleAuthSubmit(e) {
    e.preventDefault();
    setAuthError(null);
    setAuthMessage(null);
    setAuthBusy(true);
    try {
      if (authMode === "signup") {
        const { error } = await supabase.auth.signUp({ email: authEmail, password: authPassword });
        if (error) throw error;
        setAuthMessage("Compte créé ! Si la confirmation par e-mail est activée, vérifiez votre boîte mail, sinon vous êtes déjà connecté(e).");
        setAuthMode("signin");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
        if (error) throw error;
      }
      setAuthPassword("");
    } catch (err) {
      setAuthError(err.message || "Une erreur est survenue.");
    } finally {
      setAuthBusy(false);
    }
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    setHoldings([]);
  }

  // Portefeuille
  // Univers de sociétés utilisé par le formulaire : dérivé des vraies données
  // (actionsData, les ~80 sociétés réelles) une fois chargées, avec repli sur
  // l'ancienne liste statique le temps du chargement initial.
  const stockUniverse =
    actionsData?.companies?.length
      ? actionsData.companies.map((c) => ({ code: c.ticker, nom: c.nom, cours: c.prix ?? 0 })).sort((a, b) => a.nom.localeCompare(b.nom))
      : stocksUniverse;

  const [holdings, setHoldings] = useState([]);
  const [ptfLoading, setPtfLoading] = useState(true);
  const [ptfError, setPtfError] = useState(null);
  const [formCode, setFormCode] = useState(stocksUniverse[0].code);
  const [formQte, setFormQte] = useState("");
  const [formPrix, setFormPrix] = useState("");
  const [formError, setFormError] = useState(null);

  // Une fois les vraies données chargées, si le code sélectionné par défaut
  // n'existe pas dans la vraie liste, bascule sur la première société réelle.
  React.useEffect(() => {
    if (actionsData?.companies?.length && !actionsData.companies.some((c) => c.ticker === formCode)) {
      setFormCode(actionsData.companies[0].ticker);
    }
  }, [actionsData]);

  React.useEffect(() => {
    if (!user) {
      setHoldings([]);
      setPtfLoading(false);
      return;
    }
    let cancelled = false;
    setPtfLoading(true);
    supabase
      .from("portfolio_holdings")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) setPtfError("Impossible de charger votre portefeuille.");
        else {
          setPtfError(null);
          setHoldings(
            (data || []).map((h) => ({
              id: h.id, code: h.code, nom: h.nom, quantite: h.quantite, prixAchat: h.prix_achat,
            }))
          );
        }
        setPtfLoading(false);
      });
    return () => { cancelled = true; };
  }, [user]);

  async function addHolding(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!user) {
      setFormError("Connectez-vous pour ajouter une valeur à votre portefeuille.");
      return;
    }
    try {
      const qte = parseFloat(String(formQte).replace(",", "."));
      const prix = parseFloat(String(formPrix).replace(",", "."));
      if (!qte || qte <= 0 || !prix || prix <= 0) {
        setFormError("Merci de renseigner une quantité et un prix d'achat valides (supérieurs à 0).");
        return;
      }
      setFormError(null);
      const stock = stockUniverse.find((s) => s.code === formCode) || stockUniverse[0];
      const { data, error } = await supabase
        .from("portfolio_holdings")
        .insert({ user_id: user.id, code: stock.code, nom: stock.nom, quantite: qte, prix_achat: prix })
        .select()
        .single();
      if (error) {
        setPtfError("La sauvegarde a échoué. Réessaie.");
        return;
      }
      setPtfError(null);
      setHoldings((prev) => [
        ...prev,
        { id: data.id, code: data.code, nom: data.nom, quantite: data.quantite, prixAchat: data.prix_achat },
      ]);
      setFormQte("");
      setFormPrix("");
    } catch (err) {
      setFormError("Une erreur inattendue est survenue : " + (err && err.message ? err.message : String(err)));
    }
  }

  async function removeHolding(id) {
    const prev = holdings;
    setHoldings(holdings.filter((h) => h.id !== id));
    const { error } = await supabase.from("portfolio_holdings").delete().eq("id", id);
    if (error) {
      setPtfError("La suppression a échoué. Réessaie.");
      setHoldings(prev);
    }
  }

  // Cherche le dernier cours réel (source: séance boursière, mise à jour manuelle
  // quotidienne) correspondant à un code du portefeuille.
  function getDernierCoursSeance(code) {
    if (!seanceBourseData?.companies) return null;
    const stock = stockUniverse.find((s) => s.code === code);
    if (!stock) return null;
    const norm = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
    const target = norm(stock.nom);
    const found = seanceBourseData.companies.find((c) => {
      const cn = norm(c.instrument);
      return cn === target || cn.includes(target) || target.includes(cn);
    });
    if (!found || found.dernier_cours == null) return null;
    const val = parseFloat(String(found.dernier_cours).replace(/[\s\u00a0]/g, "").replace(",", "."));
    return isNaN(val) ? null : val;
  }

  const ptfRows = holdings.map((h) => {
    const stock = stockUniverse.find((s) => s.code === h.code) || { cours: h.prixAchat };
    const coursSeance = getDernierCoursSeance(h.code);
    const coursUtilise = coursSeance != null ? coursSeance : stock.cours;
    const valeur = coursUtilise * h.quantite;
    const cout = h.prixAchat * h.quantite;
    const pv = valeur - cout;
    const pvPct = cout > 0 ? (pv / cout) * 100 : 0;
    return { ...h, cours: coursUtilise, coursSource: coursSeance != null ? "seance" : "reference", valeur, cout, pv, pvPct };
  });
  const ptfTotalValeur = ptfRows.reduce((s, r) => s + r.valeur, 0);
  const ptfTotalCout = ptfRows.reduce((s, r) => s + r.cout, 0);
  const ptfTotalPV = ptfTotalValeur - ptfTotalCout;
  const ptfTotalPVPct = ptfTotalCout > 0 ? (ptfTotalPV / ptfTotalCout) * 100 : 0;

  return (
    <div className="sahm">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

        .sahm {
          --ink: #1C242C;
          --ink-soft: #5B6773;
          --paper: #FFFFFF;
          --paper-raised: #FFFFFF;
          --navy: #2B3A4A;
          --navy-deep: #1F2A36;
          --gold: #7C8896;
          --gold-soft: #D8DBE0;
          --green: #2E7D5B;
          --green-soft: #E4F0EA;
          --red: #B4453D;
          --red-soft: #F5E7E5;
          --hairline: #DDE1E5;
          font-family: 'Inter', sans-serif;
          background: var(--paper);
          color: var(--ink);
          min-height: 100vh;
        }
        .sahm * { box-sizing: border-box; }
        .mono { font-family: 'IBM Plex Mono', monospace; }
        .serif { font-family: 'Space Grotesk', sans-serif; }

        /* ---- Ticker ---- */
        .ticker-wrap {
          background: var(--navy-deep);
          overflow: hidden;
          white-space: nowrap;
          border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .ticker-track {
          display: inline-block;
          padding: 7px 0;
          animation: scroll-left 32s linear infinite;
        }
        .ticker-item {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          margin-right: 34px;
          font-family: 'IBM Plex Mono', monospace;
          font-size: 12px;
          color: #C9D6DB;
          letter-spacing: 0.02em;
        }
        .ticker-item .code { color: #fff; font-weight: 600; }
        .ticker-item .up { color: #7FCB9B; }
        .ticker-item .down { color: #E29999; }
        @keyframes scroll-left {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }

        /* ---- Navbar ---- */
        .navbar {
          background: var(--paper-raised);
          border-bottom: 1px solid var(--hairline);
          padding: 14px 5vw;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
        }
        .navbar-v2 {
          flex-direction: column;
          align-items: stretch;
          padding: 0;
          gap: 0;
        }
        .navbar-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 14px 5vw;
          position: relative;
        }
        .navbar-top-left {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .navbar-top-right {
          display: flex;
          align-items: center;
          gap: 18px;
        }
        .nav-logo-center {
          position: absolute;
          left: 50%;
          transform: translateX(-50%);
        }
        .account-link {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13.5px;
          font-weight: 600;
          color: var(--ink);
          cursor: pointer;
          white-space: nowrap;
        }
        .account-cta {
          background: var(--gold);
          color: #fff;
          border: none;
          border-radius: 20px;
          padding: 9px 20px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          font-family: inherit;
          white-space: nowrap;
        }
        .navbar-tabs {
          display: flex;
          align-items: center;
          gap: 26px;
          padding: 0 5vw 14px;
          overflow-x: auto;
          border-top: 1px solid var(--hairline);
          padding-top: 12px;
        }
        @media (max-width: 900px) {
          .nav-logo-center { position: static; transform: none; }
          .navbar-top { justify-content: space-between; }
        }
        .navbar-left {
          display: flex;
          align-items: center;
          gap: 32px;
        }
        .nav-logo {
          display: flex;
          align-items: center;
          gap: 9px;
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 19px;
          color: var(--navy);
          white-space: nowrap;
        }
        .icon-badge {
          height: 38px;
          width: auto;
          object-fit: contain;
        }
        .nav-link {
          font-size: 14.5px;
          color: var(--ink-soft);
          font-weight: 500;
          text-decoration: none;
        }
        .nav-link.active { color: var(--navy); font-weight: 600; }
        .nav-search {
          flex: 1;
          max-width: 420px;
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--paper);
          border: 1px solid var(--hairline);
          border-radius: 24px;
          padding: 9px 16px;
          color: var(--ink-soft);
          font-size: 13.5px;
        }
        .navbar-right {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .badge-new {
          display: flex;
          align-items: center;
          gap: 6px;
          background: var(--navy);
          color: #EEF1F4;
          padding: 7px 14px;
          border-radius: 20px;
          font-size: 12.5px;
          font-weight: 600;
          white-space: nowrap;
        }
        .badge-new .pill-tag {
          background: var(--gold-soft);
          color: var(--navy);
          border-radius: 12px;
          padding: 2px 8px;
          font-size: 10.5px;
          margin-right: 2px;
        }
        .icon-btn {
          width: 36px; height: 36px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          background: var(--paper-raised);
          color: var(--ink-soft);
          border: 1px solid var(--hairline);
          cursor: pointer;
        }
        .account-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          border: 1px solid var(--hairline);
          border-radius: 24px;
          padding: 5px 14px 5px 5px;
          font-size: 13.5px;
          font-weight: 500;
          color: var(--ink);
          white-space: nowrap;
        }
        .account-pill .avatar {
          width: 26px; height: 26px;
          border-radius: 50%;
          background: var(--gold-soft);
          color: var(--navy);
          display: flex; align-items: center; justify-content: center;
        }

        /* ---- Navigation mobile ---- */
        .nav-links-desktop {
          display: flex;
          align-items: center;
          gap: 32px;
        }
        .nav-burger {
          display: none;
          width: 38px; height: 38px;
          align-items: center;
          justify-content: center;
          background: transparent;
          border: 1px solid var(--hairline);
          border-radius: 8px;
          color: var(--navy);
          cursor: pointer;
        }
        .mobile-menu {
          display: none;
        }
        @media (max-width: 900px) {
          .nav-links-desktop,
          .nav-search-desktop,
          .nav-right-desktop {
            display: none;
          }
          .nav-burger { display: flex; }
          .navbar { padding: 12px 5vw; }
          .navbar-left { gap: 0; }
          .mobile-menu {
            display: flex;
            flex-direction: column;
            background: var(--paper-raised);
            border-bottom: 1px solid var(--hairline);
            padding: 16px 5vw 20px;
          }
          .mobile-link {
            padding: 13px 4px;
            font-size: 15px;
            font-weight: 500;
            color: var(--ink);
            text-decoration: none;
            border-bottom: 1px solid var(--hairline);
          }
          .mobile-link.active { color: var(--navy); font-weight: 700; }
          .mobile-menu-footer {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 16px;
          }
        }

        /* ---- Ticker (light) ---- */
        .ticker-wrap-light {
          background: var(--paper-raised);
          border-bottom: 1px solid var(--hairline);
          overflow: hidden;
          white-space: nowrap;
        }
        .ticker-item-light {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          margin-right: 36px;
          font-family: 'IBM Plex Mono', monospace;
          font-size: 13px;
        }
        .ticker-avatar {
          width: 24px; height: 24px;
          border-radius: 50%;
          background: var(--navy);
          color: #D8DBE0;
          font-size: 9px;
          font-weight: 700;
          display: flex; align-items: center; justify-content: center;
        }
        .tl-code { color: var(--ink); font-weight: 600; }
        .tl-var.up { color: var(--green); }
        .tl-var.down { color: var(--red); }
        .dot {
          width: 7px; height: 7px; border-radius: 50%;
          background: #E9A5A5;
        }

        /* ---- Hero ---- */
        .hero {
          background: linear-gradient(180deg, var(--navy) 0%, #1A2530 100%);
          color: #EEF1F4;
          padding: 56px 0 60px;
        }
        .hero-centered { text-align: center; }
        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.16);
          padding: 8px 18px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;
          color: #C9D6DB;
          margin-bottom: 30px;
        }
        .hero-badge.market-open {
          background: rgba(127,203,155,0.12);
          border-color: rgba(127,203,155,0.35);
          color: #8FDBB0;
        }
        .hero-badge.market-open .dot {
          background: #7FCB9B;
        }
        .hero-badge-time {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 12px;
          color: #8DA0A8;
          padding-left: 6px;
          border-left: 1px solid rgba(255,255,255,0.15);
          margin-left: 2px;
        }
        .hero-title {
          font-size: clamp(32px, 4.6vw, 50px);
          font-weight: 600;
          line-height: 1.12;
          margin: 0 auto 16px;
          max-width: 780px;
          color: #EEF1F4;
        }
        .hero-subtitle {
          font-size: 16px;
          color: #A9BAC1;
          max-width: 560px;
          margin: 0 auto 46px;
        }
        .hero-stats-row {
          display: flex;
          justify-content: center;
          flex-wrap: wrap;
          gap: 0;
        }
        .hero-live-masi {
          max-width: 720px;
          margin: 34px auto 0;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 12px;
          padding: 16px 18px 6px;
        }
        .hero-stat {
          padding: 0 34px;
          border-right: 1px solid rgba(255,255,255,0.14);
        }
        .hero-stat:last-child { border-right: none; }
        .hero-stat .value {
          font-size: 27px;
          font-weight: 600;
          color: #EEF1F4;
        }
        .hero-stat .label {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: #8DA0A8;
          margin-top: 8px;
        }
        @media (max-width: 640px) {
          .hero-stat { padding: 0 16px 16px; border-right: none; border-bottom: 1px solid rgba(255,255,255,0.14); }
        }

        /* ---- Layout ---- */
        .container {
          max-width: 1180px;
          margin: 0 auto;
          padding: 0 5vw;
        }

        .variation {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          font-family: 'IBM Plex Mono', monospace;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: 20px;
        }
        .variation.lg { font-size: 17px; padding: 6px 14px; }
        .variation.md { font-size: 13px; }
        .variation.up { background: rgba(127,203,155,0.14); color: #8FDBB0; }
        .variation.down { background: rgba(226,153,153,0.14); color: #E9A5A5; }

        /* ---- Section shell ---- */
        .section {
          padding: 52px 0;
          border-bottom: 1px solid var(--hairline);
        }
        .section-head {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          margin-bottom: 26px;
          flex-wrap: wrap;
          gap: 10px;
        }
        .section-title {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 27px;
          font-weight: 600;
          color: var(--ink);
        }
        .section-note {
          font-size: 12.5px;
          color: var(--ink-soft);
          font-family: 'IBM Plex Mono', monospace;
        }

        /* ---- Palmares tables ---- */
        .palmares-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 28px;
        }
        @media (max-width: 780px) {
          .palmares-grid { grid-template-columns: 1fr; }
        }
        /* Sur l'accueil, le palmarès partage l'espace avec le fil d'actualité :
           on empile systématiquement les 2 cartes, peu importe la largeur
           d'écran, pour éviter que les pourcentages soient coupés. */
        .palmares-grid-narrow {
          grid-template-columns: 1fr !important;
        }
        .palmares-card {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 12px;
          overflow: hidden;
        }
        .palmares-head {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 14px 18px;
          font-weight: 600;
          font-size: 14px;
          border-bottom: 1px solid var(--hairline);
        }
        .palmares-head.gain { color: var(--green); }
        .palmares-head.loss { color: var(--red); }
        table { width: 100%; border-collapse: collapse; }
        .palmares-card tr:not(:last-child) td {
          border-bottom: 1px solid var(--hairline);
        }
        .palmares-card td {
          padding: 12px 18px;
          font-size: 14px;
        }
        .stock-code {
          font-family: 'IBM Plex Mono', monospace;
          font-weight: 600;
          color: var(--ink);
        }
        .stock-nom {
          color: var(--ink-soft);
          font-size: 12.5px;
        }
        .stock-cours {
          font-family: 'IBM Plex Mono', monospace;
          color: var(--ink-soft);
          text-align: right;
        }

        /* ---- OPCVM ---- */
        .tabs {
          display: flex;
          gap: 6px;
          flex-wrap: wrap;
        }
        .tab-btn {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 12.5px;
          padding: 8px 16px;
          border-radius: 20px;
          border: 1px solid var(--hairline);
          background: transparent;
          color: var(--ink-soft);
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .tab-btn.active {
          background: var(--navy);
          border-color: var(--navy);
          color: #EEF1F4;
        }
        .opcvm-card {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 12px;
          overflow: hidden;
        }
        .opcvm-row-head td {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--ink-soft);
          padding: 10px 18px;
          background: #EAEDEF;
        }
        .opcvm-card td {
          padding: 14px 18px;
          font-size: 14px;
          vertical-align: middle;
        }
        .opcvm-card tr:not(:last-child) td {
          border-bottom: 1px solid var(--hairline);
        }
        .fund-name { font-weight: 600; color: var(--ink); }
        .fund-gerant { font-size: 12px; color: var(--ink-soft); margin-top: 2px; }
        .fund-gerant.up { color: var(--green); }
        .fund-gerant.down { color: var(--red); }
        .opcvm-scroll {
          overflow-x: auto;
        }
        .opcvm-scroll table { min-width: 780px; }
        .cap-table-scroll {
          overflow-x: auto;
        }
        .cap-table-scroll table { width: 100%; }
        .perf-cell {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 13px;
          text-align: right;
          white-space: nowrap;
        }
        .perf-cell.up { color: var(--green); }
        .perf-cell.down { color: var(--red); }
        .perf-cell.flat { color: #9CA4AC; }
        .ytd-value {
          font-family: 'IBM Plex Mono', monospace;
          font-weight: 600;
          text-align: right;
          white-space: nowrap;
        }
        .ytd-value.up { color: var(--green); }
        .ytd-value.down { color: var(--red); }

        .opcvm-footnote {
          margin-top: 14px;
          font-size: 12.5px;
          line-height: 1.6;
          color: var(--ink-soft);
          max-width: 760px;
        }

        /* ---- Nouvelles pages (Apprendre / Data) ---- */
        .page-shell {
          padding: 48px 0 60px;
        }
        .page-header {
          max-width: 720px;
          margin-bottom: 40px;
        }
        .eyebrow-mono {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 11.5px;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          color: var(--gold);
          margin-bottom: 12px;
        }
        .page-title {
          font-size: clamp(28px, 4vw, 40px);
          font-weight: 600;
          color: var(--ink);
          margin: 0 0 12px;
        }
        .page-subtitle {
          font-size: 15.5px;
          color: var(--ink-soft);
          line-height: 1.6;
        }
        .page-footnote {
          margin-top: 28px;
          font-size: 12.5px;
          line-height: 1.6;
          color: var(--ink-soft);
          max-width: 760px;
        }

        .opcvm-search {
          width: 100%;
          max-width: 420px;
          font-family: 'Inter', sans-serif;
          font-size: 14px;
          padding: 10px 16px;
          border: 1px solid var(--hairline);
          border-radius: 24px;
          background: var(--paper-raised);
          color: var(--ink);
        }
        .opcvm-search:focus {
          outline: none;
          border-color: var(--navy);
        }

        .opcvm-row-clickable {
          cursor: pointer;
        }
        .opcvm-row-clickable:hover {
          background: #EFF2F4;
        }

        .opcvm-back-link {
          display: inline-block;
          font-family: 'IBM Plex Mono', monospace;
          font-size: 13px;
          color: var(--ink-soft);
          text-decoration: none;
        }
        .opcvm-back-link:hover { color: var(--navy); }

        .opcvm-detail-price {
          display: flex;
          align-items: center;
          gap: 14px;
          flex-wrap: wrap;
          font-size: 26px;
          font-weight: 600;
          margin-top: 6px;
        }

        .opcvm-detail-facts {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 12px;
          overflow: hidden;
        }
        .opcvm-detail-facts > div {
          display: flex;
          justify-content: space-between;
          gap: 16px;
          padding: 13px 18px;
          font-size: 13.5px;
          border-bottom: 1px solid var(--hairline);
        }
        .opcvm-detail-facts > div:last-child { border-bottom: none; }
        .opcvm-detail-facts > div > span:first-child {
          color: var(--ink-soft);
        }
        .opcvm-detail-facts > div > span:last-child {
          font-weight: 600;
          color: var(--ink);
          text-align: right;
        }

        .learn-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 20px;
        }
        @media (max-width: 780px) {
          .learn-grid { grid-template-columns: 1fr; }
        }
        .learn-card {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 12px;
          padding: 22px 24px;
        }
        .learn-card h3 {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 18px;
          font-weight: 600;
          color: var(--navy);
          margin: 0 0 10px;
        }
        .learn-card p {
          font-size: 14px;
          line-height: 1.65;
          color: var(--ink-soft);
          margin: 0;
        }

        .kpi-row {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 1px;
          background: var(--hairline);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          overflow: hidden;
        }
        @media (max-width: 700px) {
          .kpi-row { grid-template-columns: 1fr 1fr; }
        }
        .kpi-cell {
          background: var(--paper-raised);
          padding: 18px 20px;
        }
        .kpi-value {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 24px;
          font-weight: 600;
          color: var(--navy);
        }
        .kpi-label {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--ink-soft);
          margin-top: 6px;
        }

        .mini-head {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--ink-soft);
          margin-bottom: 10px;
        }

        .two-col {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 28px;
        }
        @media (max-width: 780px) {
          .two-col { grid-template-columns: 1fr; }
        }

        .cap-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .cap-row {
          display: grid;
          grid-template-columns: 28px 220px 1fr 110px;
          align-items: center;
          gap: 16px;
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          padding: 14px 18px;
        }
        @media (max-width: 700px) {
          .cap-row { grid-template-columns: 24px 1fr; grid-template-areas: "rank name" "bar bar" "val val"; }
          .cap-bar-track { grid-area: bar; }
          .cap-value { grid-area: val; text-align: left !important; }
        }
        .cap-rank {
          font-family: 'IBM Plex Mono', monospace;
          font-weight: 700;
          color: var(--gold);
          font-size: 15px;
        }
        .cap-bar-track {
          height: 8px;
          background: #E5E8EB;
          border-radius: 4px;
          overflow: hidden;
        }
        .cap-bar-fill {
          height: 100%;
          background: var(--navy);
          border-radius: 4px;
        }
        .cap-value {
          font-weight: 600;
          text-align: right;
          white-space: nowrap;
        }

        .official-table-card {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          overflow: hidden;
        }
        .official-table {
          width: 100%;
          border-collapse: collapse;
        }
        .official-table thead th {
          background: #E3E8EF;
          text-align: left;
          font-size: 12.5px;
          font-weight: 700;
          color: var(--ink);
          padding: 14px 18px;
          white-space: nowrap;
          border-bottom: 1px solid var(--hairline);
        }
        .official-table tbody td {
          padding: 13px 18px;
          font-size: 13.5px;
          color: var(--ink);
          border-bottom: 1px solid #E7EAED;
          white-space: nowrap;
        }
        .official-table tbody tr:last-child td { border-bottom: none; }
        .official-table tbody tr:hover { background: var(--gold-soft); }
        .official-emetteur { color: #2E5E8C; font-weight: 500; }
        .official-table td.muted { color: var(--ink-soft); font-style: italic; }
        .type-badge {
          font-size: 11.5px;
          color: var(--ink-soft);
        }
        .type-badge.exceptionnel {
          color: var(--gold);
          font-weight: 600;
        }

        .chip-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .chip {
          font-size: 12.5px;
          color: var(--ink-soft);
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 20px;
          padding: 6px 14px;
        }

        .all-pages-menu {
          position: absolute;
          top: calc(100% + 8px);
          left: 0;
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          box-shadow: 0 8px 24px rgba(0,0,0,0.12);
          padding: 8px;
          display: flex;
          flex-direction: column;
          min-width: 220px;
          z-index: 50;
        }
        .all-pages-link {
          display: block;
          padding: 9px 12px;
          border-radius: 6px;
          font-size: 13.5px;
          color: var(--ink);
          text-decoration: none;
        }
        .all-pages-link:hover {
          background: var(--gold-soft);
        }
        .all-pages-link.active {
          color: var(--gold);
          font-weight: 700;
        }

        .homepage-grid {
          display: grid;
          grid-template-columns: 1.7fr 1fr;
          gap: 32px;
          align-items: start;
        }
        .homepage-sidebar {
          position: sticky;
          top: 90px;
        }
        @media (max-width: 900px) {
          .homepage-grid { grid-template-columns: 1fr; }
          .homepage-sidebar { position: static; }
        }

        .brief-card {
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          padding: 16px;
          margin-bottom: 14px;
          cursor: pointer;
          transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        .brief-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0,0,0,0.08);
        }
        .brief-badge {
          background: var(--navy);
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          padding: 3px 9px;
          border-radius: 10px;
          letter-spacing: 0.3px;
          white-space: nowrap;
        }
        .brief-badge-lg {
          font-size: 12px;
          padding: 5px 12px;
          border-radius: 12px;
        }
        .brief-titre {
          font-size: 13.5px;
          font-weight: 700;
          line-height: 1.35;
          margin-bottom: 8px;
        }
        .brief-resume {
          font-size: 11.5px;
          color: var(--ink-soft);
          line-height: 1.55;
          margin-bottom: 10px;
        }
        .brief-lien {
          font-size: 11.5px;
          color: var(--gold);
          font-weight: 600;
        }
        .brief-header {
          background: var(--navy);
          color: #fff;
          padding: 24px 28px;
          border-radius: 10px;
        }
        .brief-header-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
        }
        .brief-header-logo {
          background: #fff;
          color: var(--ink);
          border-radius: 8px;
          padding: 8px 14px;
          font-size: 13px;
        }

        .resume-jour {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 10px;
          padding: 18px 24px;
          max-width: 820px;
          margin: 0 auto;
        }
        .resume-jour-titre {
          font-size: 13.5px;
          font-weight: 700;
          margin-bottom: 4px;
        }
        .resume-jour-texte {
          font-size: 13.5px;
          color: var(--ink-soft);
          line-height: 1.6;
        }
        @media (max-width: 640px) {
          .resume-jour { padding: 14px 16px; }
          .resume-jour-titre, .resume-jour-texte { font-size: 13px; }
        }

        .ptf-form {
          display: flex;
          align-items: flex-end;
          gap: 16px;
          flex-wrap: wrap;
          background: var(--paper-raised);
          border: 1px solid var(--hairline);
          border-radius: 12px;
          padding: 20px 22px;
        }
        .ptf-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .ptf-field label {
          font-size: 11.5px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: var(--ink-soft);
        }
        .ptf-field select,
        .ptf-field input {
          font-family: 'Inter', sans-serif;
          font-size: 14px;
          padding: 9px 12px;
          border: 1px solid var(--hairline);
          border-radius: 8px;
          background: var(--paper-raised);
          color: var(--ink);
          min-width: 160px;
        }
        .ptf-field input {
          min-width: 140px;
        }
        .ptf-add-btn {
          font-family: 'Inter', sans-serif;
          font-weight: 600;
          font-size: 14px;
          background: var(--navy);
          color: #EEF1F4;
          border: none;
          border-radius: 8px;
          padding: 11px 22px;
          cursor: pointer;
        }
        .ptf-add-btn:hover { background: #1A2530; }
        .ptf-error {
          color: var(--red);
          font-size: 13px;
          margin-top: 10px;
        }
        .ptf-empty {
          margin-top: 28px;
          padding: 36px 24px;
          text-align: center;
          background: var(--paper-raised);
          border: 1px dashed var(--hairline);
          border-radius: 12px;
          color: var(--ink-soft);
          font-size: 14px;
        }
        .ptf-remove-btn {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 11.5px;
          color: var(--ink-soft);
          background: transparent;
          border: 1px solid var(--hairline);
          border-radius: 14px;
          padding: 5px 12px;
          cursor: pointer;
        }
        .ptf-remove-btn:hover { color: var(--red); border-color: var(--red); }

        .tv-single-quote {
          min-width: 140px;
          max-width: 220px;
        }
        .tv-market-overview-wrap {
          width: 100%;
        }
        .tv-market-overview-wrap tv-market-overview {
          display: block;
          width: 100%;
        }

        /* ---- Footer ---- */
        .footer {
          padding: 28px 0 40px;
          text-align: center;
          font-size: 12px;
          color: var(--ink-soft);
        }

        @media (max-width: 640px) {
          .stat-grid { grid-template-columns: 1fr; }
          .cap-grid { grid-template-columns: 1fr !important; }
          .compare-select-grid { grid-template-columns: 1fr !important; }
          .section-title { font-size: 20px; }
          .section-note { font-size: 11px; }
          .section { padding: 34px 0; }

          /* Hero */
          .hero { padding: 32px 0 36px; }
          .hero-badge { font-size: 12px; padding: 6px 14px; margin-bottom: 20px; }
          .hero-title { font-size: 26px; margin-bottom: 12px; }
          .hero-subtitle { font-size: 14px; margin-bottom: 30px; }
          .hero-stats-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px 0;
            width: 100%;
          }
          .hero-stat {
            padding: 0 8px 14px !important;
            border-right: none !important;
            border-bottom: 1px solid rgba(255,255,255,0.14);
          }
          .hero-stat:nth-child(2n) { border-right: none; }
          .hero-stat .value { font-size: 20px; }
          .hero-live-masi { padding: 12px 12px 4px; margin-top: 24px; }

          /* Capitalisation globale : éviter le débordement du montant */
          .kpi-cell .kpi-value { word-break: break-word; }

          /* Table des meilleures capitalisations : tenir sur l'écran sans scroll horizontal */
          .cap-table-scroll .official-table th,
          .cap-table-scroll .official-table td {
            white-space: normal;
            padding: 11px 12px;
            font-size: 12.5px;
          }
        }

        @media (max-width: 420px) {
          .hero-title { font-size: 22px; }
          .kpi-cell .kpi-value { font-size: 20px !important; }
        }

        @media print {
          .navbar, .ticker-wrap-light, .mobile-menu, .footer, .nav-burger, .no-print,
          .hero-badge, .tabs { display: none !important; }
          .sahm { background: #fff !important; color: #000 !important; }
          .page-shell { padding-top: 0 !important; }
          .official-table-card, .opcvm-card { box-shadow: none !important; border: 1px solid #ccc !important; }
          a { text-decoration: none !important; color: inherit !important; }
        }
      `}</style>

      {/* Navbar */}
      <nav className="navbar navbar-v2">
        <div className="navbar-top">
          <div className="navbar-top-left">
            <div style={{ position: "relative" }}>
              <button
                className="icon-btn"
                onClick={() => setAllPagesOpen((v) => !v)}
                aria-label="Toutes les pages"
                title="Toutes les pages"
              >
                <Menu size={18} />
              </button>
              {allPagesOpen && (
                <>
                  <div
                    onClick={() => setAllPagesOpen(false)}
                    style={{ position: "fixed", inset: 0, zIndex: 40 }}
                  />
                  <div className="all-pages-menu">
                    {[
                      { key: "accueil", label: "Accueil" },
                      { key: "apprendre", label: "Apprendre sur la bourse" },
                      { key: "seance", label: "Séance Boursière" },
                      { key: "opcvm", label: "OPCVM" },
                      { key: "actions", label: "Actions" },
                      { key: "comparateur", label: "Comparateur" },
                      { key: "obligataire", label: "Obligataire" },
                      { key: "data", label: "Calendrier Dividende" },
                      { key: "portefeuille", label: "Mon Portefeuille" },
                    ].map((p) => (
                      <a
                        key={p.key}
                        href="#"
                        className={`all-pages-link ${page === p.key ? "active" : ""}`}
                        onClick={(e) => { e.preventDefault(); setPage(p.key); setAllPagesOpen(false); }}
                      >
                        {p.label}
                      </a>
                    ))}
                  </div>
                </>
              )}
            </div>
            <div className="nav-search nav-search-desktop">
              <Search size={15} />
              Recherche
            </div>
          </div>

          <div className="nav-logo nav-logo-center">
            <img src="/assets/logo-icon.png?v=2" alt="BourseInfo.ma" className="icon-badge" />
            BourseInfo<span style={{ color: "var(--gold)" }}>.ma</span>
          </div>

          <div className="navbar-top-right nav-right-desktop">
            <div
              className="account-link"
              onClick={() => setPage("portefeuille")}
              title={user ? user.email : "Se connecter"}
            >
              <User size={15} />
              {user ? user.email.split("@")[0] : "Se connecter"}
            </div>
            <button className="account-cta" onClick={() => setPage("portefeuille")}>
              Mon Compte
            </button>
          </div>

          <button className="nav-burger" onClick={() => setMobileNavOpen((v) => !v)} aria-label="Menu">
            {mobileNavOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <div className="navbar-tabs nav-links-desktop">
          <a className={`nav-link ${page === "accueil" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("accueil"); }}>Accueil</a>
          <a className={`nav-link ${page === "apprendre" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("apprendre"); }}>Apprendre sur la bourse</a>
          <a className={`nav-link ${page === "seance" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("seance"); }}>Séance Boursière</a>
          <a className={`nav-link ${page === "opcvm" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("opcvm"); }}>OPCVM</a>
          <a className={`nav-link ${page === "actions" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("actions"); }}>Actions</a>
          <a className={`nav-link ${page === "comparateur" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("comparateur"); }}>Comparateur</a>
          <a className={`nav-link ${page === "obligataire" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("obligataire"); }}>Obligataire</a>
          <a className={`nav-link ${page === "data" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("data"); }}>Calendrier Dividende</a>
          <a className={`nav-link ${page === "portefeuille" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("portefeuille"); }}>Mon Portefeuille</a>
        </div>
      </nav>

      {mobileNavOpen && (
        <div className="mobile-menu">
          <div className="nav-search" style={{ marginBottom: 14 }}>
            <Search size={15} />
            Rechercher une entreprise...
          </div>
          <a className={`mobile-link ${page === "accueil" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("accueil"); setMobileNavOpen(false); }}>Accueil</a>
          <a className={`mobile-link ${page === "apprendre" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("apprendre"); setMobileNavOpen(false); }}>Apprendre sur la bourse</a>
          <a className={`mobile-link ${page === "seance" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("seance"); setMobileNavOpen(false); }}>Séance Boursière</a>
          <a className={`mobile-link ${page === "opcvm" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("opcvm"); setMobileNavOpen(false); }}>OPCVM</a>
          <a className={`mobile-link ${page === "actions" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("actions"); setMobileNavOpen(false); }}>Actions</a>
          <a className={`mobile-link ${page === "comparateur" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("comparateur"); setMobileNavOpen(false); }}>Comparateur</a>
          <a className={`mobile-link ${page === "obligataire" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("obligataire"); setMobileNavOpen(false); }}>Obligataire</a>
          <a className={`mobile-link ${page === "data" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("data"); setMobileNavOpen(false); }}>Calendrier Dividende</a>
          <a className={`mobile-link ${page === "portefeuille" ? "active" : ""}`} href="#" onClick={(e) => { e.preventDefault(); setPage("portefeuille"); setMobileNavOpen(false); }}>Mon Portefeuille</a>
          <div className="mobile-menu-footer">
            <button className="icon-btn"><Settings size={16} /></button>
            <div
              className="account-pill"
              onClick={() => { setPage("portefeuille"); setMobileNavOpen(false); }}
              style={{ cursor: "pointer" }}
            >
              <span className="avatar"><User size={14} /></span>
              {user ? user.email.split("@")[0] : "Mon Compte"}
            </div>
          </div>
        </div>
      )}

      {/* Ticker — données réelles en direct (TradingView), visible sur toutes les pages */}
      <TradingViewTickerTape />

      {page === "accueil" && (
      <>
      {/* Hero */}
      <section className="hero hero-centered">
        <div className="container">
          <div className={`hero-badge ${marketStatus.isOpen ? "market-open" : ""}`}>
            <span className="dot" />
            {marketStatus.isOpen ? "Marché Ouvert" : marketStatus.isHoliday ? "Jour férié — Marché Fermé" : "Marché Fermé"}
            <span className="hero-badge-time">{marketStatus.timeLabel}</span>
          </div>
          <h1 className="hero-title serif">Votre référence pour les marchés financiers marocains</h1>
          <p className="hero-subtitle">
            Suivez toutes les entreprises cotées à la Bourse de Casablanca en temps réel
          </p>
          <div className="hero-stats-row">
            <div className="hero-stat">
              <div className="value mono">18,8x</div>
              <div className="label">PER 2026E &middot; marché</div>
            </div>
            <div className="hero-stat">
              <div className="value mono">
                {marketData?.masi
                  ? <>{marketData.masi.value.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span style={{ color: marketData.masi.change_pct >= 0 ? "#8FDBB0" : "#E9A5A5", fontSize: 15 }}>{marketData.masi.change_pct >= 0 ? "▲" : "▼"} {marketData.masi.change_pct >= 0 ? "+" : ""}{marketData.masi.change_pct.toFixed(2)}%</span></>
                  : <>{seanceIndices[0].valeur} <span style={{ color: seanceIndices[0].var >= 0 ? "#8FDBB0" : "#E9A5A5", fontSize: 15 }}>{seanceIndices[0].var >= 0 ? "▲" : "▼"} {seanceIndices[0].var >= 0 ? "+" : ""}{seanceIndices[0].var.toFixed(2)}%</span></>
                }
              </div>
              <div className="label">MASI</div>
            </div>
            <div className="hero-stat">
              <div className="value mono">{seanceStats.volumeCentral}</div>
              <div className="label">Volume (marché central)</div>
            </div>
            <div className="hero-stat">
              <div className="value mono">{seanceStats.capitalisation}</div>
              <div className="label">Capitalisation</div>
            </div>
          </div>
        </div>
      </section>

      {/* Résumé de la séance + Palmarès (colonne principale) + Fil d'actualité (colonne latérale) */}
      <section className="section">
        <div className="container">
          <div className="homepage-grid">
            <div className="homepage-main">

              {/* Résumé de la séance — figé sur la dernière clôture, ne bouge pas
                  avec les données intrajournalières affichées ailleurs sur le site */}
              {(() => {
                const c = derniereCloture;
                const enHausse = c.masiVar >= 0;
                const seanceQualifiee = Math.abs(c.masiVar) >= 1 ? (enHausse ? "Forte séance" : "Séance difficile") : "Séance calme";
                return (
                  <div
                    className="resume-jour"
                    style={{ borderLeft: `4px solid ${enHausse ? "var(--green)" : "var(--red)"}`, marginBottom: 28 }}
                  >
                    {enHausse ? <TrendingUp size={20} color="var(--green)" style={{ flexShrink: 0 }} /> : <TrendingDown size={20} color="var(--red)" style={{ flexShrink: 0 }} />}
                    <div>
                      <div className="resume-jour-titre">
                        Résumé de la séance du {c.date} <span style={{ color: "var(--ink-soft)", fontWeight: 400 }}>· {seanceQualifiee}</span>
                      </div>
                      <div className="resume-jour-texte">
                        Le MASI {enHausse ? "progresse" : "recule"} de {Math.abs(c.masiVar).toFixed(2)}% à {c.masiValeur} points,
                        {" "}pour un volume total échangé de {c.volume}.
                        {" "}{c.meilleureHausse.nom} signe la plus forte hausse de la séance ({c.meilleureHausse.var >= 0 ? "+" : ""}{c.meilleureHausse.var.toFixed(2)}%),
                        {" "}tandis que {c.plusForteBaisse.nom} enregistre la plus forte baisse ({c.plusForteBaisse.var.toFixed(2)}%).
                        {c.topActifs?.length === 3 && (
                          <> Côté volumes, {c.topActifs[0].nom} avait dominé les échanges avec {c.topActifs[0].volume.toLocaleString("fr-FR")}{c.topActifsUnite || " titres traités"},
                          {" "}devant {c.topActifs[1].nom} ({c.topActifs[1].volume.toLocaleString("fr-FR")}) et {c.topActifs[2].nom} ({c.topActifs[2].volume.toLocaleString("fr-FR")}).</>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })()}

              {derniereCloture.top10Volumes?.length > 0 && (
                <div style={{ marginBottom: 28 }}>
                  <div className="section-head">
                    <div className="section-title" style={{ fontSize: 16 }}>Les 10 plus gros volumes traités</div>
                  </div>
                  <div className="official-table-card">
                    <div className="cap-table-scroll">
                      <table className="official-table">
                        <thead>
                          <tr>
                            <th>Instrument</th>
                            <th style={{ textAlign: "right" }}>Volume (MAD)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {derniereCloture.top10Volumes.map((v) => (
                            <tr key={v.nom}>
                              <td className="official-emetteur">{v.nom}</td>
                              <td className="mono" style={{ textAlign: "right" }}>{v.volume.toLocaleString("fr-FR")}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Palmarès */}
              <div className="section-head">
                <div className="section-title">Palmarès de la séance</div>
                <div className="section-note">
                  Données en direct
                </div>
              </div>
              {palmaresData ? (
                <div className="palmares-grid palmares-grid-narrow">
                  <div className="palmares-card">
                    <div className="palmares-head gain">
                      <TrendingUp size={16} /> Plus fortes hausses
                    </div>
                    <table>
                      <tbody>
                        {palmaresData.top_hausses.map((s) => (
                          <tr key={s.name} onClick={() => goToActionByName(s.name)} style={{ cursor: "pointer" }}>
                            <td className="stock-code">{s.name}</td>
                            <td className="stock-cours">{s.price.toLocaleString("fr-FR")} DH</td>
                            <td><Variation value={s.change_pct} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="palmares-card">
                    <div className="palmares-head loss">
                      <TrendingDown size={16} /> Plus fortes baisses
                    </div>
                    <table>
                      <tbody>
                        {palmaresData.top_baisses.map((s) => (
                          <tr key={s.name} onClick={() => goToActionByName(s.name)} style={{ cursor: "pointer" }}>
                            <td className="stock-code">{s.name}</td>
                            <td className="stock-cours">{s.price.toLocaleString("fr-FR")} DH</td>
                            <td><Variation value={s.change_pct} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="opcvm-card" style={{ padding: "12px 8px" }}>
                  <TradingViewHotlist />
                </div>
              )}
            </div>

            {/* Fil d'actualité */}
            <div className="homepage-sidebar">
              <div className="section-title" style={{ fontSize: 18, marginBottom: 14 }}>Fil d'actualité</div>
              {morningBriefs.slice(0, 3).map((b) => (
                <div
                  key={b.date}
                  className="brief-card"
                  onClick={() => { setSelectedBrief(b); setPage("brief-detail"); window.scrollTo(0, 0); }}
                >
                  <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                    <span className="brief-badge">{b.badge || "MORNING BRIEF"}</span>
                    <span style={{ fontSize: 10.5, color: "var(--ink-soft)" }}>{b.dateLabel}</span>
                  </div>
                  <div className="brief-titre">{b.titre}</div>
                  <div className="brief-resume">{b.resumeCourt}</div>
                  <span className="brief-lien">Lire le brief complet →</span>
                </div>
              ))}
              {morningBriefs.length > 3 && (
                <div style={{ textAlign: "center", marginTop: 4 }}>
                  <div style={{ color: "var(--ink-soft)", fontSize: 20, letterSpacing: 3, marginBottom: 8 }}>•••</div>
                  <a
                    href="#"
                    onClick={(e) => { e.preventDefault(); setPage("actualites"); window.scrollTo(0, 0); }}
                    style={{ color: "var(--gold)", fontWeight: 600, fontSize: 13, textDecoration: "none" }}
                  >
                    Cliquez ici pour voir toute l'actualité
                  </a>
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* Capitalisation boursière */}
      <section className="section">
        <div className="container">
          {!capData ? null : (
            <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 28, alignItems: "start" }} className="cap-grid">
              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 20 }}>Dix meilleures capitalisations</div>
                </div>
                <div className="official-table-card">
                  <div className="cap-table-scroll">
                    <table className="official-table">
                      <thead>
                        <tr>
                          <th>Instrument</th>
                          <th style={{ textAlign: "right" }}>Capitalisation (MAD)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {capData.top10.map((c) => (
                          <tr key={c.nom}>
                            <td className="official-emetteur">{c.nom}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.capitalisation.toLocaleString("fr-FR")}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 20 }}>Capitalisation globale</div>
                </div>
                <div className="kpi-cell" style={{ background: "var(--gold)", borderRadius: 12, padding: "18px 20px", marginBottom: 28 }}>
                  <div className="kpi-value" style={{ color: "#fff", fontSize: 26 }}>{capData.global.toLocaleString("fr-FR")} MAD</div>
                </div>

                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 20 }}>Capitalisation sectorielle</div>
                </div>
                <div className="opcvm-card" style={{ padding: 20 }}>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie
                        data={capData.secteurs}
                        dataKey="pct"
                        nameKey="nom"
                        innerRadius={55}
                        outerRadius={90}
                        paddingAngle={2}
                      >
                        {capData.secteurs.map((_, i) => (
                          <Cell key={i} fill={["#B4453D", "#3B6FA0", "#2E7D5B", "#7C8896", "#D8A23B"][i % 5]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v) => `${v}%`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
                    {capData.secteurs.map((s, i) => (
                      <div key={s.nom} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
                        <span style={{ width: 10, height: 10, borderRadius: "50%", background: ["#B4453D", "#3B6FA0", "#2E7D5B", "#7C8896", "#D8A23B"][i % 5], flexShrink: 0 }} />
                        <span style={{ color: "var(--ink)" }}>{s.nom}</span>
                        <span style={{ color: "var(--ink-soft)", marginLeft: "auto" }}>{s.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Obligataire — comparaison et évolution des taux */}
      {courbeTauxData && (
        <section className="section">
          <div className="container">
            <div className="section-head">
              <div className="section-title">Marché obligataire</div>
              <div className="section-note">
                <a href="#" onClick={(e) => { e.preventDefault(); setPage("obligataire"); }} style={{ color: "var(--gold)", fontWeight: 600 }}>
                  Voir la page complète →
                </a>
              </div>
            </div>
            {renderCourbeComparaison()}
            {renderEvolutionTaux()}
          </div>
        </section>
      )}

      {/* OPCVM */}
      <section className="section" style={{ borderBottom: "none" }}>
        <div className="container">
          <div className="section-head">
            <div className="section-title">Top 5 des OPCVM</div>
            <div className="section-note">Au {opcvmData?.source_date_label || opcvmSourceDate}</div>
          </div>

          <div className="tabs" style={{ marginBottom: 20 }}>
            {opcvmCategoryList.map((c) => (
              <button
                key={c}
                className={`tab-btn ${tab === c ? "active" : ""}`}
                onClick={() => setTab(c)}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="opcvm-card">
            <div className="opcvm-scroll">
              <table>
                <tbody>
                  <tr className="opcvm-row-head">
                    <td>Nom de l'OPCVM</td>
                    <td style={{ textAlign: "right" }}>Valeur</td>
                    <td style={{ textAlign: "right" }}>1 mois</td>
                    <td style={{ textAlign: "right" }}>3 mois</td>
                    <td style={{ textAlign: "right" }}>6 mois</td>
                    <td style={{ textAlign: "right" }}>1 an</td>
                    <td style={{ textAlign: "right" }}>2 ans</td>
                    <td style={{ textAlign: "right" }}>5 ans</td>
                  </tr>
                  {(opcvmData?.categories?.[tab]?.slice(0, 5) || opcvmFunds[tab]).map((f) => (
                    <tr
                      key={f.code}
                      className="opcvm-row-clickable"
                      onClick={() => { setSelectedOpcvm(f); setPage("opcvm-detail"); }}
                    >
                      <td>
                        <div className="fund-name">{f.nom}</div>
                        <div className="fund-gerant">{f.code}</div>
                      </td>
                      <td style={{ textAlign: "right" }}>
                        <div className="mono" style={{ fontWeight: 600 }}>{f.valeur} MAD</div>
                        <div className={`fund-gerant ${f.jour >= 0 ? "up" : "down"}`}>
                          {f.jour >= 0 ? "+" : ""}{f.jour.toFixed(2)}%/jour
                        </div>
                      </td>
                      <PercentCell value={f.m1} />
                      <PercentCell value={f.m3} />
                      <PercentCell value={f.m6} />
                      <PercentCell value={f.a1} />
                      <PercentCell value={f.a2} />
                      <PercentCell value={f.a5} />
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <p className="opcvm-footnote">
            Situation au {opcvmData?.source_date_label || opcvmSourceDate}. Performances passées, ne préjugent pas des performances
            futures.
          </p>
        </div>
      </section>

      {/* Marchés mondiaux */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div className="section-title">Marchés mondiaux</div>
            <div className="section-note">Données en direct</div>
          </div>
          <div className="opcvm-card" style={{ padding: "12px 8px" }}>
            <TradingViewMarketOverview />
          </div>
        </div>
      </section>


      </>
      )}

      {page === "apprendre" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Éducation financière</div>
              <h1 className="page-title serif">Apprendre sur la bourse</h1>
              <p className="page-subtitle">
                Les bases pour comprendre le fonctionnement de la Bourse de Casablanca et le rôle
                de son régulateur, l'AMMC — pour investir en connaissance de cause.
              </p>
            </div>

            <div className="learn-grid">
              {learnCards.map((c) => (
                <div className="learn-card" key={c.title}>
                  <h3>{c.title}</h3>
                  <p>{c.text}</p>
                </div>
              ))}
            </div>

            <p className="page-footnote">
              Contenu pédagogique général, ne constitue pas un conseil en investissement.
            </p>
          </div>
        </section>
      )}

      {page === "seance" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Détail de séance</div>
              <h1 className="page-title serif">Séance Boursière</h1>
              <p className="page-subtitle">
                Compte-rendu détaillé de la dernière séance de cotation de la Bourse de Casablanca —
                {" "}{seanceDate}.
              </p>
            </div>

            <div className="kpi-row">
              {seanceIndices.map((idx) => (
                <div className="kpi-cell" key={idx.nom}>
                  <div className="kpi-value" style={{ color: idx.var >= 0 ? "var(--green)" : "var(--red)" }}>
                    {idx.valeur}
                  </div>
                  <div className="kpi-label">
                    {idx.nom} &middot; {idx.var >= 0 ? "+" : ""}{idx.var.toFixed(2)}%
                    {idx.ytd !== null && ` (YTD ${idx.ytd >= 0 ? "+" : ""}${idx.ytd.toFixed(2)}%)`}
                  </div>
                </div>
              ))}
              <div className="kpi-cell">
                <div className="kpi-value">{seanceStats.capitalisation}</div>
                <div className="kpi-label">Capitalisation boursière</div>
              </div>
            </div>

            <div className="section-head" style={{ marginTop: 40 }}>
              <div className="section-title" style={{ fontSize: 22 }}>Volume &amp; largeur de marché</div>
            </div>
            <div className="two-col" style={{ marginBottom: 36 }}>
              <div className="opcvm-card" style={{ padding: "18px 22px" }}>
                <div className="mini-head">Volume global des échanges</div>
                <div className="kpi-value" style={{ fontSize: 26, marginBottom: 10 }}>{seanceStats.volume}</div>
                <div className="fund-gerant">Marché central : {seanceStats.volumeCentral} &middot; Marché de blocs : {seanceStats.volumeBlocs}</div>
              </div>
              <div className="opcvm-card" style={{ padding: "18px 22px" }}>
                <div className="mini-head">Meilleure hausse / plus forte baisse</div>
                {(() => {
                  const meilleureHausse = palmaresData?.top_hausses?.[0];
                  const plusForteBaisse = palmaresData?.top_baisses?.[0];
                  if (!meilleureHausse || !plusForteBaisse) {
                    return <div className="fund-gerant" style={{ marginTop: 10 }}>Données indisponibles</div>;
                  }
                  return (
                    <div style={{ display: "flex", gap: 22, marginTop: 6 }}>
                      <div>
                        <div className="kpi-value" style={{ color: "var(--green)", fontSize: 20 }}>
                          {meilleureHausse.change_pct >= 0 ? "+" : ""}{meilleureHausse.change_pct.toFixed(2)}%
                        </div>
                        <div className="fund-gerant">{meilleureHausse.name}</div>
                      </div>
                      <div>
                        <div className="kpi-value" style={{ color: "var(--red)", fontSize: 20 }}>
                          {plusForteBaisse.change_pct >= 0 ? "+" : ""}{plusForteBaisse.change_pct.toFixed(2)}%
                        </div>
                        <div className="fund-gerant">{plusForteBaisse.name}</div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>

            {seanceSecteurs && (
              <>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 22 }}>Secteurs : meilleure et pire performance</div>
                </div>
                <div className="two-col" style={{ marginBottom: 36 }}>
                  <div className="opcvm-card" style={{ padding: "16px 22px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div className="fund-name">{seanceSecteurs.meilleur.nom}</div>
                      <div className="fund-gerant">Meilleur secteur de la séance</div>
                    </div>
                    <div className="ytd-value up">+{seanceSecteurs.meilleur.var.toFixed(2)}%</div>
                  </div>
                  <div className="opcvm-card" style={{ padding: "16px 22px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div className="fund-name">{seanceSecteurs.pire.nom}</div>
                      <div className="fund-gerant">Pire secteur de la séance</div>
                    </div>
                    <div className="ytd-value down">{seanceSecteurs.pire.var.toFixed(2)}%</div>
                  </div>
                </div>
              </>
            )}

            <div className="section-head">
              <div className="section-title" style={{ fontSize: 22 }}>Palmarès de la séance</div>
              <div className="section-note">
                Données en direct
              </div>
            </div>
            {palmaresData ? (
              <div className="palmares-grid" style={{ marginBottom: 36 }}>
                <div className="palmares-card">
                  <div className="palmares-head gain">
                    <TrendingUp size={16} /> Plus fortes hausses
                  </div>
                  <table>
                    <tbody>
                      {palmaresData.top_hausses.map((s) => (
                        <tr key={s.name} onClick={() => goToActionByName(s.name)} style={{ cursor: "pointer" }}>
                          <td className="stock-code">{s.name}</td>
                          <td className="stock-cours">{s.price.toLocaleString("fr-FR")} DH</td>
                          <td><Variation value={s.change_pct} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="palmares-card">
                  <div className="palmares-head loss">
                    <TrendingDown size={16} /> Plus fortes baisses
                  </div>
                  <table>
                    <tbody>
                      {palmaresData.top_baisses.map((s) => (
                        <tr key={s.name} onClick={() => goToActionByName(s.name)} style={{ cursor: "pointer" }}>
                          <td className="stock-code">{s.name}</td>
                          <td className="stock-cours">{s.price.toLocaleString("fr-FR")} DH</td>
                          <td><Variation value={s.change_pct} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="opcvm-card" style={{ padding: "12px 8px", marginBottom: 36 }}>
                <TradingViewHotlist />
              </div>
            )}

            <div className="section-head">
              <div className="section-title" style={{ fontSize: 22 }}>Toutes les valeurs cotées</div>
            </div>
            {!seanceBourseData ? (
              <p className="page-subtitle">Chargement…</p>
            ) : (
              <div className="opcvm-card" style={{ padding: "12px 8px" }}>
                <div className="opcvm-scroll">
                  <table className="official-table" style={{ minWidth: 1400 }}>
                    <thead>
                      <tr>
                        <th>Instrument</th>
                        <th style={{ textAlign: "right" }}>Cours réf.</th>
                        <th style={{ textAlign: "right" }}>Ouverture</th>
                        <th style={{ textAlign: "right" }}>Dernier cours</th>
                        <th style={{ textAlign: "right" }}>Quantité</th>
                        <th style={{ textAlign: "right" }}>Volume</th>
                        <th style={{ textAlign: "right" }}>Variation</th>
                        <th style={{ textAlign: "right" }}>+ haut</th>
                        <th style={{ textAlign: "right" }}>+ bas</th>
                        <th style={{ textAlign: "right" }}>Meilleur achat</th>
                        <th style={{ textAlign: "right" }}>Meilleur vente</th>
                        <th style={{ textAlign: "right" }}>Capitalisation</th>
                        <th style={{ textAlign: "right" }}>Transactions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[...seanceBourseData.companies].sort((a, b) => a.instrument.localeCompare(b.instrument, "fr")).map((c) => {
                        const isUp = typeof c.variation_pct === "string" && c.variation_pct.trim().startsWith("-") === false && !c.variation_pct.startsWith("0,00");
                        const isDown = typeof c.variation_pct === "string" && c.variation_pct.trim().startsWith("-");
                        return (
                          <tr key={c.instrument} onClick={() => goToActionByName(c.instrument)} style={{ cursor: "pointer" }}>
                            <td className="official-emetteur">{c.instrument}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.cours_ref}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.ouverture}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.dernier_cours}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.quantite}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.volume}</td>
                            <td className="mono" style={{ textAlign: "right", color: isDown ? "var(--red)" : isUp ? "var(--green)" : "inherit", fontWeight: 600 }}>{c.variation_pct}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.haut}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.bas}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.meilleur_achat}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.meilleur_vente}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.capitalisation}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{c.nb_transactions}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {page === "actions-detail" && selectedAction && (
        <section className="page-shell">
          <div className="container">
            <a
              href="#"
              className="opcvm-back-link"
              onClick={(e) => { e.preventDefault(); setPage("actions"); }}
            >
              ← Retour à la liste des actions
            </a>

            <div className="page-header" style={{ marginTop: 18 }}>
              <div className="eyebrow-mono" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                <span>{selectedAction.secteur} &middot; {selectedAction.ticker}</span>
                <button
                  onClick={() => toggleFavori(selectedAction.ticker)}
                  style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "1px solid var(--hairline)", borderRadius: 20, padding: "6px 14px", cursor: "pointer", color: "var(--ink)", fontSize: 13, fontFamily: "inherit" }}
                >
                  <Star size={14} color={favoris.includes(selectedAction.ticker) ? "var(--gold)" : "var(--ink-soft)"} fill={favoris.includes(selectedAction.ticker) ? "var(--gold)" : "none"} />
                  {favoris.includes(selectedAction.ticker) ? "Dans mes favoris" : "Ajouter aux favoris"}
                </button>
              </div>
              <h1 className="page-title serif">{selectedAction.nom}</h1>
              <div className="opcvm-detail-price">
                <span className="mono">
                  {selectedAction.prix != null ? `${selectedAction.prix.toLocaleString("fr-FR")} MAD` : "—"}
                </span>
                {selectedAction.variation_jour != null && <Variation value={selectedAction.variation_jour} size="lg" />}
              </div>
            </div>

            <div className="kpi-row" style={{ marginBottom: 32 }}>
              <div className="kpi-cell">
                <div className="kpi-value">
                  {selectedAction.capitalisation != null
                    ? `${(selectedAction.capitalisation / 1e9).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} Mrd`
                    : "—"}
                </div>
                <div className="kpi-label">Capitalisation (MAD)</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value">{selectedAction.per ?? "—"}</div>
                <div className="kpi-label">P/E Ratio</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value">{selectedAction.rendement_dividende != null ? `${selectedAction.rendement_dividende}%` : "—"}</div>
                <div className="kpi-label">Rendement dividende</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value">{selectedAction.classement != null ? `#${selectedAction.classement}` : "—"}</div>
                <div className="kpi-label">Classement (capitalisation)</div>
              </div>
            </div>

            <div className="section-head">
              <div className="section-title" style={{ fontSize: 20 }}>Évolution du cours</div>
            </div>
            <div className="opcvm-card" style={{ padding: 20, marginBottom: 32 }}>
              {historiqueCache[selectedAction.ticker] === undefined ? (
                <p className="fund-gerant" style={{ padding: "24px 4px" }}>Chargement de l'historique…</p>
              ) : historiqueCache[selectedAction.ticker] && historiqueCache[selectedAction.ticker].length > 1 ? (
                (() => {
                  const full = historiqueCache[selectedAction.ticker];
                  const ranges = { "3M": 90, "6M": 182, "1A": 365, "3A": 1095, "Tout": null };
                  const range = histRange in ranges ? histRange : "1A";
                  const lastDate = new Date(full[full.length - 1].date);
                  const data = ranges[range] == null
                    ? full
                    : full.filter((d) => (lastDate - new Date(d.date)) / 86400000 <= ranges[range]);
                  const tickEvery = Math.max(1, Math.floor(data.length / 6));
                  return (
                    <>
                      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
                        {Object.keys(ranges).map((r) => (
                          <button
                            key={r}
                            onClick={() => setHistRange(r)}
                            style={{
                              fontSize: 12, padding: "5px 12px", borderRadius: 14,
                              border: "1px solid var(--hairline)",
                              background: range === r ? "var(--gold)" : "transparent",
                              color: range === r ? "#fff" : "var(--ink-soft)",
                              cursor: "pointer", fontFamily: "inherit",
                            }}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                      <ResponsiveContainer width="100%" height={260}>
                        <LineChart data={data}>
                          <CartesianGrid stroke="var(--hairline)" strokeDasharray="3 3" />
                          <XAxis
                            dataKey="date"
                            tick={{ fontSize: 11, fill: "var(--ink-soft)" }}
                            interval={tickEvery}
                            tickFormatter={(v) => {
                              const d = new Date(v);
                              return d.toLocaleDateString("fr-FR", { month: "short", year: "2-digit" });
                            }}
                          />
                          <YAxis tick={{ fontSize: 11, fill: "var(--ink-soft)" }} domain={["auto", "auto"]} width={54} />
                          <Tooltip
                            formatter={(v) => [`${v.toLocaleString("fr-FR")} MAD`, "Cours"]}
                            labelFormatter={(v) => new Date(v).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
                          />
                          <Line type="monotone" dataKey="prix" stroke="var(--gold)" strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </>
                  );
                })()
              ) : (
                <p className="fund-gerant" style={{ padding: "24px 4px" }}>
                  Historique des cours pas encore disponible pour cette valeur. Il sera affiché ici dès que les données seront transmises.
                </p>
              )}
            </div>

            {selectedAction.description && (
              <p className="page-subtitle" style={{ marginBottom: 28, maxWidth: 760 }}>{selectedAction.description}</p>
            )}

            <div className="two-col" style={{ marginBottom: 32 }}>
              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 22 }}>Caractéristiques</div>
                </div>
                <div className="opcvm-detail-facts">
                  <div><span>Secteur</span><span>{selectedAction.secteur || "—"}</span></div>
                  <div><span>Ticker</span><span>{selectedAction.ticker || "—"}</span></div>
                  <div><span>Date IPO</span><span>{selectedAction.date_ipo || "—"}</span></div>
                  <div><span>Nombre d'actions</span><span>{selectedAction.nombre_actions != null ? selectedAction.nombre_actions.toLocaleString("fr-FR") : "—"}</span></div>
                  <div><span>Chiffre d'affaires</span><span>{selectedAction.chiffre_affaires != null ? `${(selectedAction.chiffre_affaires / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} MDH` : "—"}</span></div>
                  <div><span>Résultat net</span><span>{selectedAction.resultat_net != null ? `${(selectedAction.resultat_net / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} MDH` : "—"}</span></div>
                  <div><span>Marge opérationnelle</span><span>{selectedAction.marge_operationnelle != null ? `${selectedAction.marge_operationnelle}%` : "—"}</span></div>
                  <div><span>Marge nette</span><span>{selectedAction.marge_nette != null ? `${selectedAction.marge_nette}%` : "—"}</span></div>
                </div>
              </div>
              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 22 }}>Structure actionnariale</div>
                </div>
                {selectedAction.actionnariat && selectedAction.actionnariat.length > 0 ? (
                  <div className="opcvm-detail-facts">
                    {selectedAction.actionnariat.map((a) => (
                      <div key={a.nom}>
                        <span>{a.nom}</span>
                        <span>{a.pct != null ? `${a.pct}%` : "—"}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="page-subtitle">Structure actionnariale non disponible pour cette valeur.</p>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {page === "actualites" && (
        <section className="page-shell">
          <div className="container" style={{ maxWidth: 760 }}>
            <div className="page-header">
              <div className="eyebrow-mono">The Morning Brief</div>
              <h1 className="page-title serif">Toute l'actualité</h1>
              <p className="page-subtitle">L'historique complet des briefs quotidiens, du plus récent au plus ancien.</p>
            </div>
            {morningBriefs.map((b) => (
              <div
                key={b.date}
                className="brief-card"
                onClick={() => { setSelectedBrief(b); setPage("brief-detail"); window.scrollTo(0, 0); }}
              >
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
                  <span className="brief-badge">{b.badge || "MORNING BRIEF"}</span>
                  <span style={{ fontSize: 10.5, color: "var(--ink-soft)" }}>{b.dateLabel}</span>
                </div>
                <div className="brief-titre">{b.titre}</div>
                <div className="brief-resume">{b.resumeCourt}</div>
                <span className="brief-lien">Lire le brief complet →</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {page === "brief-detail" && selectedBrief && (
        <section className="page-shell">
          <div className="container" style={{ maxWidth: 760 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
              <button
                onClick={() => setPage("accueil")}
                style={{ background: "none", border: "none", color: "var(--ink-soft)", cursor: "pointer", fontFamily: "inherit", fontSize: 13, padding: 0 }}
              >
                ← Retour à l'accueil
              </button>
              {selectedBrief.pdfUrl && (
                <a
                  href={selectedBrief.pdfUrl}
                  download
                  className="tab-btn"
                  style={{ display: "flex", alignItems: "center", gap: 6, textDecoration: "none" }}
                >
                  <Download size={14} /> Télécharger en PDF
                </a>
              )}
            </div>

            <div className="brief-header">
              <div className="brief-header-top">
                <span className="brief-badge brief-badge-lg">{selectedBrief.badgeLarge || "THE MORNING BRIEF"}</span>
                <div className="brief-header-logo">
                  <span style={{ fontWeight: 700 }}>BourseInfo<span style={{ color: "var(--gold)" }}>.ma</span></span>
                  <div style={{ fontSize: 11, color: "var(--ink-soft)" }}>Marchés financiers marocains</div>
                </div>
              </div>
              <div style={{ fontSize: 12, color: "var(--gold)", marginTop: 14, letterSpacing: 0.5 }}>
                | CASABLANCA | {selectedBrief.dateLabel}
              </div>
            </div>

            {selectedBrief.sections.map((section, i) => (
              <div key={i} style={{ marginTop: i === 0 ? 28 : 32 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                  <span style={{ width: 14, height: 14, background: "var(--gold)", flexShrink: 0 }} />
                  <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: 0.3 }}>{section.titre}</div>
                </div>
                {section.items.map((item, j) => (
                  <div key={j} style={{ marginBottom: 18 }}>
                    <p style={{ margin: "0 0 4px", fontSize: 14 }}>
                      <strong>{item.tag}</strong> | <strong>{item.titre}</strong>
                    </p>
                    <p style={{ margin: 0, fontSize: 14, lineHeight: 1.65, color: "var(--ink-soft)" }}>{item.texte}</p>
                  </div>
                ))}
              </div>
            ))}

            <p className="page-footnote" style={{ marginTop: 32 }}>
              Contenu à but informatif, ne constitue pas un conseil en investissement.
            </p>
          </div>
        </section>
      )}

      {page === "obligataire" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Marché de la dette</div>
              <h1 className="page-title serif">Obligataire</h1>
              <p className="page-subtitle">
                La courbe des taux du marché marocain des bons du Trésor, mise à jour au fil des
                séances. Elle indique le rendement exigé par le marché selon la durée du prêt à
                l'État — un indicateur suivi de près pour anticiper l'évolution des taux d'intérêt.
              </p>
            </div>

            {!courbeTauxData ? (
              <p className="page-subtitle">Chargement…</p>
            ) : (
              <>
                {(() => {
                  const point = courbeTauxData.find((d) => d.date === courbeTauxDate) || courbeTauxData[courbeTauxData.length - 1];
                  const courbeChartData = maturitesListe.map((m) => ({ maturite: m.label, taux: point[m.key] }));

                  return (
                    <>
                      <div className="section-head">
                        <div className="section-title" style={{ fontSize: 20 }}>Courbe des taux</div>
                        <div className="section-note">
                          Au {new Date(courbeTauxDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                        </div>
                      </div>
                      <div className="opcvm-card" style={{ padding: 20, marginBottom: 12 }}>
                        <ResponsiveContainer width="100%" height={280}>
                          <LineChart data={courbeChartData}>
                            <CartesianGrid stroke="var(--hairline)" strokeDasharray="3 3" />
                            <XAxis dataKey="maturite" tick={{ fontSize: 11, fill: "var(--ink-soft)" }} />
                            <YAxis tick={{ fontSize: 11, fill: "var(--ink-soft)" }} unit="%" width={48} domain={["auto", "auto"]} />
                            <Tooltip formatter={(v) => [`${v.toFixed(3)}%`, "Taux"]} />
                            <Line type="monotone" dataKey="taux" stroke="var(--gold)" strokeWidth={2.5} dot={{ r: 3 }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={courbeTauxData.length - 1}
                        value={courbeTauxData.findIndex((d) => d.date === courbeTauxDate)}
                        onChange={(e) => setCourbeTauxDate(courbeTauxData[Number(e.target.value)].date)}
                        style={{ width: "100%", marginBottom: 36, accentColor: "var(--gold)" }}
                      />
                    </>
                  );
                })()}

                {renderCourbeComparaison()}
                {renderEvolutionTaux()}

                <p className="page-footnote" style={{ marginTop: 32 }}>
                  Données transmises manuellement, à but informatif — ne constituent pas un conseil en investissement.
                </p>
              </>
            )}
          </div>
        </section>
      )}

      {page === "comparateur" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Analyse comparative</div>
              <h1 className="page-title serif">Comparateur d'actions</h1>
              <p className="page-subtitle">
                Sélectionnez jusqu'à 3 sociétés pour comparer leurs principaux indicateurs côte à côte.
              </p>
            </div>

            {!actionsData ? (
              <p className="page-subtitle" style={{ marginTop: 16 }}>Chargement des données…</p>
            ) : (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }} className="compare-select-grid">
                  {[0, 1, 2].map((i) => (
                    <select
                      key={i}
                      value={compareTickers[i]}
                      onChange={(e) => {
                        const next = [...compareTickers];
                        next[i] = e.target.value;
                        setCompareTickers(next);
                      }}
                      style={{ fontSize: 14, padding: "10px 12px", border: "1px solid var(--hairline)", borderRadius: 8, background: "var(--paper-raised)", color: "var(--ink)", fontFamily: "inherit" }}
                    >
                      <option value="">— Choisir une société {i + 1} —</option>
                      {actionsData.companies.map((c) => (
                        <option key={c.ticker} value={c.ticker}>{c.nom} ({c.ticker})</option>
                      ))}
                    </select>
                  ))}
                </div>

                {(() => {
                  const selected = compareTickers
                    .filter(Boolean)
                    .map((t) => actionsData.companies.find((c) => c.ticker === t))
                    .filter(Boolean);

                  if (selected.length < 2) {
                    return (
                      <p className="page-subtitle">Choisissez au moins 2 sociétés pour lancer la comparaison.</p>
                    );
                  }

                  const rows = [
                    { label: "Secteur", get: (c) => c.secteur || "—" },
                    { label: "Prix", get: (c) => (c.prix != null ? `${c.prix.toLocaleString("fr-FR")} MAD` : "—") },
                    { label: "Variation du jour", get: (c) => (c.variation_jour != null ? `${c.variation_jour >= 0 ? "+" : ""}${c.variation_jour.toFixed(2)}%` : "—"), color: (c) => (c.variation_jour >= 0 ? "var(--green)" : "var(--red)") },
                    { label: "Capitalisation", get: (c) => (c.capitalisation != null ? `${(c.capitalisation / 1e9).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} Mrd MAD` : "—") },
                    { label: "P/E (PER)", get: (c) => c.per ?? "—" },
                    { label: "Rendement dividende", get: (c) => (c.rendement_dividende != null ? `${c.rendement_dividende}%` : "—") },
                    { label: "Chiffre d'affaires", get: (c) => (c.chiffre_affaires != null ? `${(c.chiffre_affaires / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} MDH` : "—") },
                    { label: "Résultat net", get: (c) => (c.resultat_net != null ? `${(c.resultat_net / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} MDH` : "—") },
                    { label: "Marge opérationnelle", get: (c) => (c.marge_operationnelle != null ? `${c.marge_operationnelle}%` : "—") },
                    { label: "Marge nette", get: (c) => (c.marge_nette != null ? `${c.marge_nette}%` : "—") },
                    { label: "Classement (capitalisation)", get: (c) => (c.classement != null ? `#${c.classement}` : "—") },
                    { label: "Date IPO", get: (c) => c.date_ipo || "—" },
                  ];

                  return (
                    <div className="official-table-card">
                      <div className="opcvm-scroll">
                        <table className="official-table">
                          <thead>
                            <tr>
                              <th>Indicateur</th>
                              {selected.map((c) => (
                                <th key={c.ticker} style={{ textAlign: "right" }}>{c.nom}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {rows.map((row) => (
                              <tr key={row.label}>
                                <td className="official-emetteur">{row.label}</td>
                                {selected.map((c) => (
                                  <td
                                    key={c.ticker}
                                    className="mono"
                                    style={{ textAlign: "right", color: row.color ? row.color(c) : undefined }}
                                  >
                                    {row.get(c)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })()}
              </>
            )}
          </div>
        </section>
      )}

      {page === "actions" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Sociétés cotées</div>
              <h1 className="page-title serif">Actions de la Bourse de Casablanca</h1>
              <p className="page-subtitle">
                Les ~79 sociétés cotées, avec prix, capitalisation, P/E et rendement du dividende —
                données réelles, actualisées automatiquement une fois par jour.
              </p>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <input
                type="text"
                className="opcvm-search"
                placeholder="Rechercher une société par nom ou ticker..."
                value={actionsSearch}
                onChange={(e) => setActionsSearch(e.target.value)}
                style={{ flex: 1, minWidth: 220 }}
              />
              <button
                className={`tab-btn ${showFavorisOnly ? "active" : ""}`}
                onClick={() => setShowFavorisOnly((v) => !v)}
                style={{ display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}
              >
                <Star size={14} fill={showFavorisOnly ? "currentColor" : "none"} />
                Favoris {favoris.length > 0 ? `(${favoris.length})` : ""}
              </button>
            </div>

            {!actionsData ? (
              <p className="page-subtitle" style={{ marginTop: 16 }}>Chargement des données…</p>
            ) : (
              <div className="opcvm-card" style={{ marginTop: 16 }}>
                <div className="opcvm-scroll">
                  <table>
                    <tbody>
                      <tr className="opcvm-row-head">
                        <td style={{ width: 34 }}></td>
                        <td>Société</td>
                        <td>Secteur</td>
                        <td style={{ textAlign: "right", cursor: "pointer" }} onClick={() => toggleActionsSort("prix")}>
                          Prix <ArrowUpDown size={11} style={{ verticalAlign: -1, opacity: actionsSortKey === "prix" ? 1 : 0.35 }} />
                        </td>
                        <td style={{ textAlign: "right", cursor: "pointer" }} onClick={() => toggleActionsSort("capitalisation")}>
                          Capitalisation <ArrowUpDown size={11} style={{ verticalAlign: -1, opacity: actionsSortKey === "capitalisation" ? 1 : 0.35 }} />
                        </td>
                        <td style={{ textAlign: "right", cursor: "pointer" }} onClick={() => toggleActionsSort("per")}>
                          P/E <ArrowUpDown size={11} style={{ verticalAlign: -1, opacity: actionsSortKey === "per" ? 1 : 0.35 }} />
                        </td>
                        <td style={{ textAlign: "right", cursor: "pointer" }} onClick={() => toggleActionsSort("rendement_dividende")}>
                          Dividende <ArrowUpDown size={11} style={{ verticalAlign: -1, opacity: actionsSortKey === "rendement_dividende" ? 1 : 0.35 }} />
                        </td>
                      </tr>
                      {actionsData.companies
                        .filter((c) => {
                          const q = actionsSearch.trim().toLowerCase();
                          if (q && !(c.nom.toLowerCase().includes(q) || (c.ticker || "").toLowerCase().includes(q))) return false;
                          if (showFavorisOnly && !favoris.includes(c.ticker)) return false;
                          return true;
                        })
                        .sort((a, b) => {
                          if (!actionsSortKey) return 0;
                          const av = a[actionsSortKey];
                          const bv = b[actionsSortKey];
                          if (av == null) return 1;
                          if (bv == null) return -1;
                          return actionsSortDir === "asc" ? av - bv : bv - av;
                        })
                        .map((c) => (
                          <tr
                            key={c.ticker}
                            className="opcvm-row-clickable"
                          >
                            <td onClick={(e) => { e.stopPropagation(); toggleFavori(c.ticker); }} style={{ cursor: "pointer", width: 34 }}>
                              <Star
                                size={16}
                                color={favoris.includes(c.ticker) ? "var(--gold)" : "var(--hairline)"}
                                fill={favoris.includes(c.ticker) ? "var(--gold)" : "none"}
                              />
                            </td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }}>
                              <div className="fund-name">{c.nom}</div>
                              <div className="fund-gerant">{c.ticker}</div>
                            </td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }} style={{ color: "var(--ink-soft)", fontSize: 13 }}>{c.secteur || "—"}</td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }} className="mono" style={{ textAlign: "right", fontWeight: 600 }}>
                              {c.prix != null ? `${c.prix.toLocaleString("fr-FR")} MAD` : "—"}
                            </td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }} className="mono" style={{ textAlign: "right", color: "var(--ink-soft)" }}>
                              {c.capitalisation != null ? `${(c.capitalisation / 1e9).toLocaleString("fr-FR", { maximumFractionDigits: 2 })} Mrd` : "—"}
                            </td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }} className="mono" style={{ textAlign: "right", color: "var(--ink-soft)" }}>
                              {c.per ?? "—"}
                            </td>
                            <td onClick={() => { setSelectedAction(c); setPage("actions-detail"); }} className="mono" style={{ textAlign: "right", color: "var(--ink-soft)" }}>
                              {c.rendement_dividende != null ? `${c.rendement_dividende}%` : "—"}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {page === "opcvm-detail" && selectedOpcvm && (
        <section className="page-shell">
          <div className="container">
            <a
              href="#"
              className="opcvm-back-link"
              onClick={(e) => { e.preventDefault(); setPage("opcvm"); }}
            >
              ← Retour à la liste des OPCVM
            </a>

            <div className="page-header" style={{ marginTop: 18 }}>
              <div className="eyebrow-mono">{selectedOpcvm.classification}</div>
              <h1 className="page-title serif">{selectedOpcvm.nom}</h1>
              <div className="opcvm-detail-price">
                <span className="mono">{selectedOpcvm.valeur} MAD</span>
                <Variation value={selectedOpcvm.jour} size="lg" />
                <span className="section-note">variation du jour</span>
              </div>
            </div>

            <div className="kpi-row" style={{ marginBottom: 32 }}>
              <div className="kpi-cell">
                <div className="kpi-value" style={{ color: (selectedOpcvm.ytd ?? 0) >= 0 ? "var(--green)" : "var(--red)" }}>
                  {(selectedOpcvm.ytd ?? 0) >= 0 ? "+" : ""}{(selectedOpcvm.ytd ?? 0).toFixed(2)}%
                </div>
                <div className="kpi-label">Depuis le 1er janvier (YTD)</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value" style={{ color: (selectedOpcvm.a1 ?? 0) >= 0 ? "var(--green)" : "var(--red)" }}>
                  {(selectedOpcvm.a1 ?? 0) >= 0 ? "+" : ""}{(selectedOpcvm.a1 ?? 0).toFixed(2)}%
                </div>
                <div className="kpi-label">Performance sur 1 an</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value">
                  {selectedOpcvm.encours != null ? selectedOpcvm.encours.toLocaleString("fr-FR", { maximumFractionDigits: 0 }) : "—"}
                </div>
                <div className="kpi-label">Encours géré (MAD)</div>
              </div>
              <div className="kpi-cell">
                <div className="kpi-value">{(selectedOpcvm.fraisGestion ?? 0).toFixed(2)}%</div>
                <div className="kpi-label">Frais de gestion</div>
              </div>
            </div>

            <div className="section-head">
              <div className="section-title" style={{ fontSize: 22 }}>Performance par horizon</div>
            </div>
            <div className="opcvm-card" style={{ marginBottom: 32 }}>
              <div className="opcvm-scroll">
                <table>
                  <tbody>
                    <tr className="opcvm-row-head">
                      <td>Depuis janv.</td>
                      <td>1 jour</td>
                      <td>1 semaine</td>
                      <td>1 mois</td>
                      <td>3 mois</td>
                      <td>6 mois</td>
                      <td>1 an</td>
                      <td>2 ans</td>
                      <td>3 ans</td>
                      <td>5 ans</td>
                      <td>Depuis création</td>
                    </tr>
                    <tr>
                      <PercentCell value={selectedOpcvm.ytd} />
                      <PercentCell value={selectedOpcvm.jour} />
                      <PercentCell value={selectedOpcvm.semaine} />
                      <PercentCell value={selectedOpcvm.m1} />
                      <PercentCell value={selectedOpcvm.m3} />
                      <PercentCell value={selectedOpcvm.m6} />
                      <PercentCell value={selectedOpcvm.a1} />
                      <PercentCell value={selectedOpcvm.a2} />
                      <PercentCell value={selectedOpcvm.a3} />
                      <PercentCell value={selectedOpcvm.a5} />
                      <PercentCell value={selectedOpcvm.sinceCreated} />
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="two-col" style={{ marginBottom: 32 }}>
              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 22 }}>Caractéristiques</div>
                </div>
                <div className="opcvm-detail-facts">
                  <div><span>Code ISIN</span><span>{selectedOpcvm.code || "—"}</span></div>
                  <div><span>Code Maroclear</span><span>{selectedOpcvm.codeMaroclear || "—"}</span></div>
                  <div><span>Nature juridique</span><span>{selectedOpcvm.natureJuridique || "—"}</span></div>
                  <div><span>Classification</span><span>{selectedOpcvm.classification || "—"}</span></div>
                  <div><span>Périodicité de VL</span><span>{selectedOpcvm.periodicite || "—"}</span></div>
                  <div><span>Affectation du résultat</span><span>{selectedOpcvm.affectationResultat || "—"}</span></div>
                  <div><span>Souscripteurs</span><span>{selectedOpcvm.souscripteur || "—"}</span></div>
                  <div><span>Profil investisseur</span><span>{selectedOpcvm.promoteur || "—"}</span></div>
                  <div><span>Indice de référence</span><span>{selectedOpcvm.benchmark || "—"}</span></div>
                  <div><span>Sensibilité (risque)</span><span>{selectedOpcvm.sensibilite || "—"}</span></div>
                  <div><span>Dépositaire</span><span>{selectedOpcvm.depositaire || "—"}</span></div>
                </div>
              </div>
              <div>
                <div className="section-head">
                  <div className="section-title" style={{ fontSize: 22 }}>Frais &amp; société de gestion</div>
                </div>
                <div className="opcvm-detail-facts">
                  <div><span>Droits d'entrée</span><span>{(selectedOpcvm.droitsEntree ?? 0).toFixed(2)}%</span></div>
                  <div><span>Droits de sortie</span><span>{(selectedOpcvm.droitsSortie ?? 0).toFixed(2)}%</span></div>
                  <div><span>Frais de gestion</span><span>{(selectedOpcvm.fraisGestion ?? 0).toFixed(2)}%</span></div>
                  <div><span>Société de gestion</span><span>{selectedOpcvm.societeGestion?.nom || "—"}</span></div>
                  <div><span>Directeur général</span><span>{selectedOpcvm.societeGestion?.directeur || "—"}</span></div>
                  <div><span>Téléphone</span><span>{selectedOpcvm.societeGestion?.telephone || "—"}</span></div>
                  <div><span>Adresse</span><span>{selectedOpcvm.societeGestion?.adresse || "—"}</span></div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {page === "opcvm" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header">
              <div className="eyebrow-mono">Fonds d'investissement</div>
              <h1 className="page-title serif">Performance de tous les OPCVM</h1>
              <p className="page-subtitle">
                L'ensemble des fonds marocains, par catégorie, avec leur performance sur plusieurs
                horizons — données réelles de l'ASFIM, actualisées automatiquement.
              </p>
            </div>

            <div className="section-head">
              <div className="section-note">
                {opcvmData?.source_date_label
                  ? `Situation au ${opcvmData.source_date_label}`
                  : "Chargement des données en direct…"}
              </div>
            </div>

            <div className="tabs" style={{ marginBottom: 16 }}>
              {opcvmCategoryList.map((c) => (
                <button
                  key={c}
                  className={`tab-btn ${opcvmPageTab === c ? "active" : ""}`}
                  onClick={() => setOpcvmPageTab(c)}
                >
                  {c}
                  {opcvmData?.categories?.[c] ? ` (${opcvmData.categories[c].length})` : ""}
                </button>
              ))}
            </div>

            <input
              type="text"
              className="opcvm-search"
              placeholder="Rechercher un fonds par nom ou code ISIN..."
              value={opcvmSearch}
              onChange={(e) => setOpcvmSearch(e.target.value)}
            />

            {!opcvmData ? (
              <p className="page-subtitle">Chargement des données en direct…</p>
            ) : (
              <div className="opcvm-card" style={{ marginTop: 16 }}>
                <div className="opcvm-scroll">
                  <table>
                    <tbody>
                      <tr className="opcvm-row-head">
                        <td>Nom de l'OPCVM</td>
                        <td style={{ textAlign: "right" }}>Encours (MAD)</td>
                        <td style={{ textAlign: "right" }}>Valeur</td>
                        <td style={{ textAlign: "right" }}>Depuis janv.</td>
                        <td style={{ textAlign: "right" }}>1 jour</td>
                        <td style={{ textAlign: "right" }}>1 semaine</td>
                        <td style={{ textAlign: "right" }}>1 mois</td>
                        <td style={{ textAlign: "right" }}>3 mois</td>
                        <td style={{ textAlign: "right" }}>6 mois</td>
                        <td style={{ textAlign: "right" }}>1 an</td>
                        <td style={{ textAlign: "right" }}>2 ans</td>
                        <td style={{ textAlign: "right" }}>3 ans</td>
                        <td style={{ textAlign: "right" }}>5 ans</td>
                      </tr>
                      {(opcvmData.categories?.[opcvmPageTab] || [])
                        .filter((f) => {
                          const q = opcvmSearch.trim().toLowerCase();
                          if (!q) return true;
                          return (
                            f.nom.toLowerCase().includes(q) ||
                            (f.code || "").toLowerCase().includes(q)
                          );
                        })
                        .map((f) => (
                          <tr
                            key={f.code || f.nom}
                            className="opcvm-row-clickable"
                            onClick={() => { setSelectedOpcvm(f); setPage("opcvm-detail"); }}
                          >
                            <td>
                              <div className="fund-name">{f.nom}</div>
                              <div className="fund-gerant">{f.code}</div>
                            </td>
                            <td className="mono" style={{ textAlign: "right", color: "var(--ink-soft)" }}>
                              {f.encours != null ? f.encours.toLocaleString("fr-FR", { maximumFractionDigits: 0 }) : "—"}
                            </td>
                            <td className="mono" style={{ textAlign: "right", fontWeight: 600 }}>
                              {f.valeur} MAD
                            </td>
                            <PercentCell value={f.ytd} />
                            <PercentCell value={f.jour} />
                            <PercentCell value={f.semaine} />
                            <PercentCell value={f.m1} />
                            <PercentCell value={f.m3} />
                            <PercentCell value={f.m6} />
                            <PercentCell value={f.a1} />
                            <PercentCell value={f.a2} />
                            <PercentCell value={f.a3} />
                            <PercentCell value={f.a5} />
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {page === "data" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
              <div>
                <div className="eyebrow-mono">Données de marché</div>
                <h1 className="page-title serif">Calendrier Dividende</h1>
                <p className="page-subtitle">Calendrier des dividendes et capitalisation des sociétés cotées.</p>
              </div>
              <button className="tab-btn no-print" onClick={() => window.print()} style={{ display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
                <Download size={14} /> Exporter en PDF
              </button>
            </div>

            <div className="tabs" style={{ marginBottom: 28 }}>
              <button
                className={`tab-btn ${dataTab === "dividendes" ? "active" : ""}`}
                onClick={() => setDataTab("dividendes")}
              >
                Calendrier de dividende
              </button>
            </div>

            {dataTab === "dividendes" && (
              <div>
                <div className="kpi-row">
                  <div className="kpi-cell">
                    <div className="kpi-value">{dividendStats.distributrices}</div>
                    <div className="kpi-label">Sociétés distributrices</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value">{dividendStats.sansDividende}</div>
                    <div className="kpi-label">Sans dividende</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value">{dividendStats.rendementMoyen}%</div>
                    <div className="kpi-label">Rendement moyen</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value">{dividendStats.cumul} DH</div>
                    <div className="kpi-label">Cumul DPA (82 sociétés)</div>
                  </div>
                </div>

                <div className="tabs" style={{ marginTop: 36, marginBottom: 0 }}>
                  {["2026", "2025", "2024"].map((y) => (
                    <button
                      key={y}
                      className={`tab-btn ${dividendYear === y ? "active" : ""}`}
                      onClick={() => setDividendYear(y)}
                    >
                      {y}
                    </button>
                  ))}
                </div>

                <div className="section-head" style={{ marginTop: 20 }}>
                  <div className="section-title" style={{ fontSize: 22 }}>{dividendByYear[dividendYear].label}</div>
                  <div className="section-note">{dividendByYear[dividendYear].note} · {dividendByYear[dividendYear].data.length} lignes</div>
                </div>
                <div className="official-table-card">
                  <div className="opcvm-scroll">
                    <table className="official-table">
                      <thead>
                        <tr>
                          <th>Émetteur</th>
                          <th style={{ textAlign: "right" }}>Montant</th>
                          <th>Date de détachement</th>
                          <th>Date de paiement</th>
                          <th>Type Dividende</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dividendByYear[dividendYear].data.map((d, i) => (
                          <tr key={d.emetteur + i}>
                            <td className="official-emetteur">{d.emetteur}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{d.montant.toFixed(2)}</td>
                            <td className={d.detachement === "À confirmer" ? "muted" : ""}>{d.detachement}</td>
                            <td className={d.paiement === "À confirmer" ? "muted" : ""}>{d.paiement}</td>
                            <td>
                              <span className={`type-badge ${d.type === "Exceptionnel" ? "exceptionnel" : ""}`}>{d.type}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <p className="page-footnote">
                  Calendrier 2025/2026. Les dates non confirmées le seront au fil des Assemblées
                  Générales. Montants en dirhams (DH) par action ; performances passées, ne
                  préjugent pas des performances futures.
                </p>
              </div>
            )}
          </div>
        </section>
      )}

      {page === "portefeuille" && (
        <section className="page-shell">
          <div className="container">
            <div className="page-header" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
              <div>
                <div className="eyebrow-mono">Simulateur</div>
                <h1 className="page-title serif">Gérer votre portefeuille en temps réel</h1>
                <p className="page-subtitle">
                  Créez un compte gratuit pour construire un ou plusieurs portefeuilles virtuels et
                  suivre leur performance. Le calcul utilise le <strong>dernier cours de la séance
                  boursière</strong>, actualisé manuellement chaque jour ; vos données sont liées à
                  votre compte et vous les retrouvez sur n'importe quel appareil.
                </p>
              </div>
              {user && (
                <button className="tab-btn no-print" onClick={() => window.print()} style={{ display: "flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>
                  <Download size={14} /> Exporter en PDF
                </button>
              )}
            </div>

            {authLoading ? (
              <p className="page-subtitle">Chargement…</p>
            ) : !user ? (
              <div className="opcvm-card" style={{ maxWidth: 420, padding: 28, margin: "24px 0" }}>
                <div className="tabs" style={{ marginBottom: 20 }}>
                  <button
                    className={`tab-btn ${authMode === "signin" ? "active" : ""}`}
                    onClick={() => { setAuthMode("signin"); setAuthError(null); setAuthMessage(null); }}
                  >
                    Se connecter
                  </button>
                  <button
                    className={`tab-btn ${authMode === "signup" ? "active" : ""}`}
                    onClick={() => { setAuthMode("signup"); setAuthError(null); setAuthMessage(null); }}
                  >
                    Créer un compte
                  </button>
                </div>
                <form onSubmit={handleAuthSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div className="ptf-field">
                    <label>Adresse e-mail</label>
                    <input
                      type="email" required placeholder="vous@exemple.com"
                      value={authEmail} onChange={(e) => setAuthEmail(e.target.value)}
                    />
                  </div>
                  <div className="ptf-field">
                    <label>Mot de passe</label>
                    <div style={{ position: "relative" }}>
                      <input
                        type={showAuthPassword ? "text" : "password"} required minLength={6} placeholder="6 caractères minimum"
                        value={authPassword} onChange={(e) => setAuthPassword(e.target.value)}
                        style={{ paddingRight: 40, width: "100%" }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowAuthPassword((v) => !v)}
                        aria-label={showAuthPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                        style={{
                          position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                          background: "none", border: "none", cursor: "pointer", color: "var(--ink-soft)",
                          display: "flex", alignItems: "center", padding: 4,
                        }}
                      >
                        {showAuthPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                  {authError && <p className="ptf-error">{authError}</p>}
                  {authMessage && <p className="page-subtitle" style={{ color: "var(--green)" }}>{authMessage}</p>}
                  <button type="submit" className="ptf-add-btn" disabled={authBusy}>
                    {authBusy ? "Un instant…" : authMode === "signup" ? "Créer mon compte" : "Se connecter"}
                  </button>
                </form>
              </div>
            ) : (
              <>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap", margin: "8px 0 20px" }}>
                  <div className="section-note">Connecté(e) en tant que <strong style={{ color: "var(--ink)" }}>{user.email}</strong></div>
                  <button
                    onClick={handleSignOut}
                    style={{ fontSize: 13, background: "none", border: "1px solid var(--hairline)", borderRadius: 20, padding: "6px 14px", cursor: "pointer", color: "var(--ink-soft)", fontFamily: "inherit" }}
                  >
                    Se déconnecter
                  </button>
                </div>

            <div className="ptf-form">
              <div className="ptf-field">
                <label>Valeur</label>
                <select value={formCode} onChange={(e) => setFormCode(e.target.value)}>
                  {stockUniverse.map((s) => (
                    <option key={s.code} value={s.code}>{s.nom} ({s.code})</option>
                  ))}
                </select>
              </div>
              <div className="ptf-field">
                <label>Quantité</label>
                <input
                  type="text" inputMode="numeric" placeholder="ex. 10"
                  value={formQte} onChange={(e) => setFormQte(e.target.value)}
                />
              </div>
              <div className="ptf-field">
                <label>Prix d'achat unitaire (MAD)</label>
                <input
                  type="text" inputMode="decimal" placeholder="ex. 105,00"
                  value={formPrix} onChange={(e) => setFormPrix(e.target.value)}
                />
              </div>
              <button type="button" className="ptf-add-btn" onClick={addHolding}>Ajouter à mon portefeuille</button>
            </div>
            {formError && <p className="ptf-error">{formError}</p>}
            {ptfError && <p className="ptf-error">{ptfError}</p>}

            {ptfLoading ? (
              <p className="page-subtitle">Chargement de votre portefeuille…</p>
            ) : ptfRows.length === 0 ? (
              <div className="ptf-empty">
                Votre portefeuille est vide pour le moment. Ajoutez une première valeur ci-dessus
                pour commencer à suivre sa performance.
              </div>
            ) : (
              <>
                <div className="kpi-row" style={{ margin: "32px 0 28px" }}>
                  <div className="kpi-cell">
                    <div className="kpi-value">{ptfTotalValeur.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} DH</div>
                    <div className="kpi-label">Valeur du portefeuille</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value">{ptfTotalCout.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} DH</div>
                    <div className="kpi-label">Coût total investi</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value" style={{ color: ptfTotalPV >= 0 ? "var(--green)" : "var(--red)" }}>
                      {ptfTotalPV >= 0 ? "+" : ""}{ptfTotalPV.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} DH
                    </div>
                    <div className="kpi-label">Plus/moins-value</div>
                  </div>
                  <div className="kpi-cell">
                    <div className="kpi-value" style={{ color: ptfTotalPVPct >= 0 ? "var(--green)" : "var(--red)" }}>
                      {ptfTotalPVPct >= 0 ? "+" : ""}{ptfTotalPVPct.toFixed(2)}%
                    </div>
                    <div className="kpi-label">Performance globale</div>
                  </div>
                </div>

                <div className="opcvm-card">
                  <div className="opcvm-scroll">
                    <table>
                      <tbody>
                        <tr className="opcvm-row-head">
                          <td>Valeur</td>
                          <td style={{ textAlign: "right" }}>Quantité</td>
                          <td style={{ textAlign: "right" }}>Prix d'achat</td>
                          <td style={{ textAlign: "right" }}>Dernier cours (séance)</td>
                          <td style={{ textAlign: "right" }}>Valeur actuelle</td>
                          <td style={{ textAlign: "right" }}>Plus/moins-value</td>
                          <td></td>
                        </tr>
                        {ptfRows.map((r) => (
                          <tr key={r.id}>
                            <td>
                              <div className="fund-name">{r.nom}</div>
                              <div className="fund-gerant">{r.code}</div>
                            </td>
                            <td className="mono" style={{ textAlign: "right" }}>{r.quantite}</td>
                            <td className="mono" style={{ textAlign: "right" }}>{r.prixAchat.toFixed(2)} DH</td>
                            <td className="mono" style={{ textAlign: "right" }}>
                              {r.cours.toFixed(2)} DH
                              {r.coursSource === "reference" && (
                                <div style={{ fontSize: 10.5, color: "var(--ink-soft)", fontWeight: 400 }}>cours de référence</div>
                              )}
                            </td>
                            <td className="mono" style={{ textAlign: "right", fontWeight: 600 }}>
                              {r.valeur.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} DH
                            </td>
                            <td className={`ytd-value ${r.pv >= 0 ? "up" : "down"}`} style={{ textAlign: "right" }}>
                              {r.pv >= 0 ? "+" : ""}{r.pv.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} DH
                              <div style={{ fontSize: 11.5, fontWeight: 400 }}>
                                {r.pvPct >= 0 ? "+" : ""}{r.pvPct.toFixed(2)}%
                              </div>
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <button className="ptf-remove-btn" onClick={() => removeHolding(r.id)}>Retirer</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
              </>
            )}

            <p className="page-footnote">
              Simulateur à but pédagogique — le calcul de plus/moins-value se base sur le dernier
              cours de la séance boursière (actualisé manuellement chaque jour, pas un flux en
              continu). Vos données sont liées à votre compte et ne sont partagées avec personne
              d'autre.
            </p>
          </div>
        </section>
      )}

      <footer className="footer">
        BourseInfo.ma — statut du marché calculé à partir des horaires réels de cotation (hors jours fériés marocains) &middot; non affilié à la Bourse de Casablanca
      </footer>
    </div>
  );
}
