"""Valorisation en série de la base de titres sur une courbe BAM.

Exemples :
  python valoriser_base.py --date 2026-09-24 --courbe bam          (courbe téléchargée sur bkam.ma)
  python valoriser_base.py --date 2026-09-24 --courbe data/courbe_exemple.csv
  python valoriser_base.py --date 2026-09-24 --courbe export_bkam.csv --primes data/primes_exemple.csv --isin MA0000021537 MA0002019380

Entrées :
  --courbe  export CSV de bkam.ma (Date d'échéance ; Taux moyen pondéré ; Date de la valeur)
            ou fichier simple « maturite;taux » (13s;2,20 / 2a;2,45 …)
  --primes  (optionnel) CSV « emetteur;prime_pb » — BKAM (Trésor) = 0 pb par défaut
Sortie : fichier CSV (séparateur « ; », décimales à virgule) lisible directement dans Excel.
Hypothèse : titres à taux fixe, coupon annuel, remboursement in fine (la base ne précise pas le type).
"""
from __future__ import annotations

import argparse
import csv
from datetime import date
from pathlib import Path

from pricer_obligataire import CourbeTaux, ObligationTauxFixe, valoriser
from pricer_obligataire.bam import courbe_bam
from pricer_obligataire.base_titres import charger_base

ICI = Path(__file__).resolve().parent


def lire_courbe(chemin: Path, date_courbe: str | None) -> CourbeTaux:
    texte = chemin.read_text(encoding="utf-8-sig", errors="replace")
    minus = texte.lower()
    if ("échéance" in minus or "echeance" in minus) and "taux" in minus:  # export bkam.ma
        return CourbeTaux.depuis_csv_bam(texte, date_courbe=date_courbe)
    pts = {}
    for ligne in texte.splitlines():
        parts = [p.strip() for p in ligne.replace(",", ".").split(";") if p.strip()] if ";" in ligne else ligne.split()
        if len(parts) >= 2 and parts[0][0].isdigit():
            pts[parts[0]] = parts[1]
    if not date_courbe:
        raise SystemExit("Précise --date-courbe pour un fichier « maturite;taux ».")
    return CourbeTaux.depuis_maturites(date_courbe, pts)


def lire_primes(chemin: Path | None) -> dict[str, float]:
    if not chemin:
        return {}
    primes = {}
    with open(chemin, encoding="utf-8-sig") as f:
        for r in csv.reader(f, delimiter=";"):
            if len(r) < 2:
                continue
            try:
                primes[r[0].strip().upper()] = float(r[1].strip().replace(",", ".")) / 1e4
            except ValueError:
                pass  # ligne d'en-tête
    return primes


def fr(x, d=4):
    return "" if x is None else f"{x:.{d}f}".replace(".", ",")


def main():
    p = argparse.ArgumentParser(description="Valorisation en série de la base de titres")
    p.add_argument("--date", default=date.today().isoformat(), help="date de valorisation AAAA-MM-JJ")
    p.add_argument("--courbe", required=True, help="CSV de la courbe BAM, ou « bam » pour la télécharger sur bkam.ma")
    p.add_argument("--date-courbe", help="date de la courbe si absente du fichier (AAAA-MM-JJ)")
    p.add_argument("--primes", help="CSV emetteur;prime_pb")
    p.add_argument("--base", default=str(ICI / "data" / "Base Titres.xlsx"))
    p.add_argument("--isin", nargs="*", help="limiter à ces ISIN")
    p.add_argument("--sortie", help="fichier CSV de sortie")
    a = p.parse_args()

    if a.courbe.lower() == "bam":  # téléchargement direct sur bkam.ma
        courbe = courbe_bam(a.date)
        print(f"Courbe BAM du {courbe.date_courbe:%d/%m/%Y} téléchargée ({len(courbe.points)} points)")
    else:
        courbe = lire_courbe(Path(a.courbe), a.date_courbe)
    primes = lire_primes(Path(a.primes) if a.primes else None)
    base = charger_base(Path(a.base))
    if a.isin:
        voulus = {i.upper() for i in a.isin}
        base = [t for t in base if t["isin"] in voulus or t["code"] in voulus]
    sortie = Path(a.sortie or f"valorisation_{a.date}.csv")

    cols = ["ISIN", "Code", "Emetteur", "Emission", "Echeance", "Taux facial %", "VN", "Mr (j)", "Base",
            "Taux BAM %", "Prime pb", "Taux actualisation %", "Prix pied %", "Prix plein %", "Coupon couru DH",
            "Prix pied DH", "Prix plein DH", "Sensibilite", "Duration", "Statut"]
    ok = ko = 0
    with open(sortie, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(cols)
        for t in base:
            etat = t["emetteur"].upper() == "BKAM"
            prime = 0.0 if etat else primes.get(t["emetteur"].upper(), 0.0)
            statut = []
            if not etat and t["emetteur"].upper() not in primes:
                statut.append("prime non renseignée (0 pb)")
            if t["taux_facial"] == 0:
                statut.append("taux facial nul : vérifier le type")
            ligne = [t["isin"], t["code"], t["emetteur"], t["emission"], t["echeance"], fr(t["taux_facial"]), fr(t["vn"], 2)]
            try:
                ob = ObligationTauxFixe(t["isin"], t["vn"], t["emission"], t["echeance"], t["taux_facial"] / 100, prime=prime)
                r = valoriser(ob, a.date, courbe)
                ligne += [r.maturite_residuelle, r.base, fr(r.taux_reference * 100), fr(prime * 1e4, 1), fr(r.taux * 100),
                          fr(r.prix_pied_pct), fr(r.prix_plein_pct), fr(r.coupon_couru, 2), fr(r.prix_pied, 2),
                          fr(r.prix_plein, 2), fr(r.sensibilite), fr(r.duration), " ; ".join(statut) or "OK"]
                ok += 1
            except ValueError as e:
                ligne += [""] * 12 + [str(e)]
                ko += 1
            w.writerow(ligne)
    print(f"{ok} titres valorisés, {ko} non valorisables (échus…) -> {sortie.resolve()}")


if __name__ == "__main__":
    main()
