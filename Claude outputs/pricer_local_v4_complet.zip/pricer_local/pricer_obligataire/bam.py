"""Téléchargement de la courbe des taux de référence des BDT sur bkam.ma.

Utilise le lien « Téléchargement CSV » de la page Bank Al-Maghrib
(Marchés > Marché obligataire > Marché secondaire > Taux de référence des bons du Trésor).
BAM publie la courbe vers 15h00 ; les week-ends, jours fériés, ou avant publication, le fichier
est vide : on remonte alors jour par jour jusqu'à la dernière courbe disponible.
"""
from __future__ import annotations

import urllib.request
from datetime import date, timedelta

from .courbe import CourbeTaux, _parse_date

URL_CSV = (
    "https://www.bkam.ma/export/blockcsv/2340/c3367fcefc5f524397748201aee5dab8/"
    "e1d6b9bbf87f86f8ba53e8518e882982?block=e1d6b9bbf87f86f8ba53e8518e882982&date={jj}%2F{mm}%2F{aaaa}"
)
ENTETES = {"User-Agent": "Mozilla/5.0 (pricer obligataire)", "Accept": "text/csv,*/*"}


def _telecharger(d: date, timeout: float = 15) -> str:
    url = URL_CSV.format(jj=f"{d.day:02d}", mm=f"{d.month:02d}", aaaa=d.year)
    with urllib.request.urlopen(urllib.request.Request(url, headers=ENTETES), timeout=timeout) as r:
        brut = r.read()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return brut.decode(enc)
        except UnicodeDecodeError:
            pass
    return brut.decode("latin-1")


def _a_des_taux(texte: str) -> bool:
    return sum(1 for l in texte.splitlines() if "%" in l and l[:2].isdigit()) >= 2


def telecharger_courbe_bam(date_voulue, max_recul: int = 10) -> tuple[str, date]:
    """Renvoie (texte CSV, date de la courbe) pour la dernière courbe publiée à `date_voulue` ou avant.

    Lève RuntimeError si aucune courbe n'est trouvée sur `max_recul` jours, et laisse passer les
    erreurs réseau (urllib.error.URLError) pour que l'appelant puisse les afficher.
    """
    d = _parse_date(date_voulue)
    for k in range(max_recul + 1):
        jour = d - timedelta(days=k)
        if jour.weekday() >= 5:  # samedi, dimanche : pas de courbe
            continue
        texte = _telecharger(jour)
        if _a_des_taux(texte):
            return texte, jour
    raise RuntimeError(f"Aucune courbe BAM publiée entre le {d - timedelta(days=max_recul):%d/%m/%Y} et le {d:%d/%m/%Y}.")


def courbe_bam(date_voulue, **kw) -> CourbeTaux:
    """Télécharge et construit la courbe BAM (dernière publiée à `date_voulue` ou avant)."""
    texte, jour = telecharger_courbe_bam(date_voulue)
    return CourbeTaux.depuis_csv_bam(texte, date_courbe=jour, **kw)


if __name__ == "__main__":  # python -m pricer_obligataire.bam 2026-09-25
    import sys

    c = courbe_bam(sys.argv[1] if len(sys.argv) > 1 else date.today())
    print(f"Courbe BAM du {c.date_courbe:%d/%m/%Y} : {len(c.points)} points")
    for j, t in c.points:
        print(f"  {j:>6} j   {t * 100:.3f} %")
