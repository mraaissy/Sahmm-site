"""Pricer obligataire — serveur local.

Lance l'interface web du pricer sur http://localhost:8765 et l'ouvre dans le navigateur.
La base de titres est relue depuis data/Base Titres.xlsx à chaque chargement de la page :
il suffit de remplacer ce fichier puis d'actualiser la page (F5).

Usage :  python app.py                     (port 8765, ouvre le navigateur)
         python app.py --port 9000 --base "D:\\Titres\\base.xlsx" --sans-navigateur
Aucune dépendance externe : Python 3.10+ suffit.
"""
from __future__ import annotations

import argparse
import json
import threading
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from pricer_obligataire.bam import telecharger_courbe_bam
from pricer_obligataire.base_titres import base_pour_page, charger_base

ICI = Path(__file__).resolve().parent
PAGE = ICI / "web" / "index.html"
_cache: dict = {"mtime": None, "chemin": None, "base": [], "erreur": ""}


def lire_base(chemin: Path):
    """Charge la base (avec cache tant que le fichier n'a pas changé)."""
    try:
        mtime = chemin.stat().st_mtime
    except FileNotFoundError:
        return [], f"fichier introuvable ({chemin})", ""
    if _cache["mtime"] != mtime or _cache["chemin"] != chemin:
        try:
            _cache.update(base=charger_base(chemin), erreur="")
        except Exception as e:  # fichier ouvert dans Excel, colonnes manquantes…
            _cache.update(base=[], erreur=str(e))
        _cache.update(mtime=mtime, chemin=chemin)
    maj = datetime.fromtimestamp(mtime).strftime("%d/%m/%Y %H:%M")
    return _cache["base"], _cache["erreur"], maj


def fabriquer_handler(chemin_base: Path):
    class Handler(BaseHTTPRequestHandler):
        def _envoyer(self, code: int, corps: bytes, type_: str):
            self.send_response(code)
            self.send_header("Content-Type", type_)
            self.send_header("Content-Length", str(len(corps)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(corps)

        def do_GET(self):
            chemin = self.path.split("?")[0]
            if chemin in ("/", "/index.html"):
                base, erreur, maj = lire_base(chemin_base)
                info = {"fichier": chemin_base.name, "maj": maj, "erreur": erreur}
                html = PAGE.read_text(encoding="utf-8")
                html = html.replace("/*__BASE_TITRES__*/[]", json.dumps(base_pour_page(base), ensure_ascii=False))
                html = html.replace('/*__BASE_INFO__*/{"fichier":"","maj":"","erreur":""}', json.dumps(info, ensure_ascii=False))
                self._envoyer(200, html.encode("utf-8"), "text/html; charset=utf-8")
            elif chemin == "/api/titres":
                base, erreur, maj = lire_base(chemin_base)
                corps = json.dumps({"titres": base, "erreur": erreur, "maj": maj}, ensure_ascii=False).encode("utf-8")
                self._envoyer(200, corps, "application/json; charset=utf-8")
            elif chemin == "/api/courbe_bam":
                from urllib.parse import parse_qs, urlparse

                q = parse_qs(urlparse(self.path).query)
                voulu = (q.get("date") or [datetime.now().strftime("%Y-%m-%d")])[0]
                try:
                    texte, jour = telecharger_courbe_bam(voulu)
                    rep = {"ok": True, "date": jour.isoformat(), "texte": texte}
                except Exception as e:  # pas d'Internet, proxy, site indisponible…
                    rep = {"ok": False, "erreur": str(e) or e.__class__.__name__}
                self._envoyer(200, json.dumps(rep, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            else:
                self._envoyer(404, "Page introuvable".encode("utf-8"), "text/plain; charset=utf-8")

        def log_message(self, fmt, *args):  # console silencieuse
            pass

    return Handler


def main():
    p = argparse.ArgumentParser(description="Pricer obligataire — serveur local")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--base", default=str(ICI / "data" / "Base Titres.xlsx"), help="chemin du fichier Excel des titres")
    p.add_argument("--sans-navigateur", action="store_true", help="ne pas ouvrir le navigateur")
    a = p.parse_args()

    chemin_base = Path(a.base).expanduser().resolve()
    base, erreur, _ = lire_base(chemin_base)
    print(f"Base de titres : {len(base)} titres ({chemin_base})" if not erreur else f"Attention : {erreur}")

    serveur = ThreadingHTTPServer(("127.0.0.1", a.port), fabriquer_handler(chemin_base))
    url = f"http://localhost:{a.port}"
    print(f"Pricer disponible sur {url}  —  Ctrl+C pour arrêter")
    if not a.sans_navigateur:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du pricer.")
        serveur.server_close()


if __name__ == "__main__":
    main()
