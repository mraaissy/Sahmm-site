"""Courbe des taux de référence BAM et courbe des primes de risque (circulaire 02/04, art. 6 et 7)."""
from __future__ import annotations

import csv
import io
import re
from bisect import bisect_left
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Iterable, Sequence

from .conventions import (
    SEUIL_MONETAIRE,
    jours_un_an,
    actuariel_vers_monetaire,
    base_du_taux,
    monetaire_vers_actuariel,
)


def _parse_date(x) -> date:
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    s = str(x).strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"Date non reconnue : {x!r}")


def _parse_taux(x) -> float:
    """'2,345 %' -> 0.02345 ; 2.345 -> 0.02345 ; 0.02345 -> 0.02345."""
    if isinstance(x, (int, float)):
        v = float(x)
    else:
        s = str(x).replace("%", "").replace("\xa0", "").replace(" ", "").replace(",", ".")
        v = float(s)
    return v / 100.0 if abs(v) > 0.5 else v


@dataclass
class CourbeTaux:
    """Courbe des taux de référence des BDT publiée par Bank Al-Maghrib.

    Les points sont exprimés en maturité résiduelle (jours) et en taux décimal, dans la base native
    publiée par BAM : monétaire (Exact/360) pour <= 365 jours, actuarielle au-delà.

    Interpolation (art. 6.2) : linéaire entre les deux points encadrants.
      - deux points <= 365 j : interpolation sur les taux monétaires ;
      - deux points  > 365 j : interpolation sur les taux actuariels ;
      - de part et d'autre de 365 j : le point court est converti en actuariel, on interpole en
        actuariel puis on reconvertit dans la base de la maturité cible (pratique de place).
    Extrapolation plate avant le premier point (art. 6.3) et après le dernier.
    `jours_min` (ex. 56 = 8 semaines, note de l'annexe) fige le taux pour les maturités plus courtes.
    """

    date_courbe: date
    points: list[tuple[int, float]]  # (jours, taux natif)
    jours_min: int | None = None
    nom: str = "Courbe BAM"
    bissextile: bool = True  # True : seuil et conversions sur 366 j si l'année qui suit la date de courbe contient un 29/02

    def __post_init__(self):
        pts = sorted((int(j), float(t)) for j, t in self.points if int(j) > 0)
        # doublons de maturité : on garde le dernier fourni
        dedup: dict[int, float] = {}
        for j, t in pts:
            dedup[j] = t
        self.points = sorted(dedup.items())
        if not self.points:
            raise ValueError("La courbe doit contenir au moins un point.")
        self._jours = [j for j, _ in self.points]
        self._an = jours_un_an(self.date_courbe) if self.bissextile else 365

    def _base(self, j: int) -> str:
        return base_du_taux(j, self._an)

    # ------------------------------------------------------------------ constructeurs
    @classmethod
    def depuis_maturites(cls, date_courbe, points: dict | Iterable, **kw) -> "CourbeTaux":
        """points : {jours ou date_echeance: taux} ; taux en % (2.5) ou décimal (0.025)."""
        d0 = _parse_date(date_courbe)
        items = points.items() if isinstance(points, dict) else points
        pts = []
        for m, t in items:
            if isinstance(m, (int, float)) and not isinstance(m, bool):
                j = int(m)
            elif isinstance(m, str) and re.fullmatch(r"\s*\d+\s*[jJsSmMaA]\s*", m):
                j = _maturite_texte(m)
            else:
                j = (_parse_date(m) - d0).days
            pts.append((j, _parse_taux(t)))
        return cls(d0, pts, **kw)

    @classmethod
    def depuis_csv_bam(cls, source, date_courbe=None, **kw) -> "CourbeTaux":
        """Lit l'export CSV/Excel de la page « Taux de référence des bons du Trésor » de bkam.ma.

        Colonnes attendues (tolérant) : « Date d'échéance », « Taux moyen pondéré »,
        et éventuellement « Date de la valeur ». `source` : chemin, texte CSV ou DataFrame.
        """
        rows = _lire_table(source)
        cols = list(rows[0].keys())
        c_ech = _trouver_col(cols, ["echeance", "échéance"])
        c_taux = _trouver_col(cols, ["taux"])
        c_val = _trouver_col(cols, ["valeur"], obligatoire=False)
        pts, dates_valeur = [], []
        for r in rows:
            try:
                ech = _parse_date(r[c_ech])
                t = _parse_taux(r[c_taux])
            except (ValueError, TypeError):
                continue  # lignes de total / vides
            pts.append((ech, t))
            if c_val and r.get(c_val):
                try:
                    dates_valeur.append(_parse_date(r[c_val]))
                except ValueError:
                    pass
        if date_courbe is None:
            if not dates_valeur:
                raise ValueError("Préciser date_courbe (aucune colonne « Date de la valeur »).")
            date_courbe = max(set(dates_valeur), key=dates_valeur.count)
        d0 = _parse_date(date_courbe)
        return cls(d0, [((e - d0).days, t) for e, t in pts], **kw)

    @classmethod
    def telecharger_bam(cls, date_courbe, **kw) -> "CourbeTaux":  # pragma: no cover - réseau
        """Récupère la courbe sur bkam.ma (nécessite pandas + lxml et un accès au site).

        Expérimental : dépend de la structure de la page BAM. En cas d'échec, exporter le CSV
        depuis le site puis utiliser `depuis_csv_bam`.
        """
        import pandas as pd

        d = _parse_date(date_courbe)
        url = (
            "https://www.bkam.ma/Marches/Principaux-indicateurs/Marche-obligataire/"
            "Marche-des-bons-de-tresor/Marche-secondaire/Taux-de-reference-des-bons-du-tresor"
            f"?date={d:%d/%m/%Y}"
        )
        tables = pd.read_html(url, decimal=",", thousands=" ")
        for t in tables:
            if any("ch" in str(c).lower() for c in t.columns) and any("taux" in str(c).lower() for c in t.columns):
                return cls.depuis_csv_bam(t, **kw)
        raise RuntimeError("Tableau de la courbe introuvable sur la page BAM.")

    # ------------------------------------------------------------------ interpolation
    def taux(self, jours: int, base: str | None = None) -> float:
        """Taux de référence pour une maturité résiduelle en jours.

        base : 'monetaire', 'actuariel' ou None (= base naturelle de la maturité).
        """
        jours = max(int(jours), 1)
        if self.jours_min and jours < self.jours_min:
            jours_lookup = self.jours_min
        else:
            jours_lookup = jours
        cible = base or self._base(jours)
        t, base_t, j_ref = self._interpoler(jours_lookup)
        # t est exprimé dans la base `base_t` pour la maturité `j_ref`.
        # Même base -> taux repris tel quel (zones plates comprises) ; sinon conversion via l'actuariel.
        if base_t == cible:
            return t
        ta = t if base_t == "actuariel" else monetaire_vers_actuariel(t, j_ref, self._an)
        return ta if cible == "actuariel" else actuariel_vers_monetaire(ta, jours, self._an)

    def _interpoler(self, j: int) -> tuple[float, str, int]:
        js, pts = self._jours, self.points
        if j <= js[0]:  # extrapolation plate (art. 6.3) : taux du 1er point, dans sa base
            j0, t0 = pts[0]
            return t0, self._base(j0), j0
        if j >= js[-1]:
            jn, tn = pts[-1]
            return tn, self._base(jn), jn
        k = bisect_left(js, j)
        if js[k] == j:
            return pts[k][1], self._base(j), j
        (j1, t1), (j2, t2) = pts[k - 1], pts[k]
        b1, b2 = self._base(j1), self._base(j2)
        if b1 != b2:  # chevauchement du seuil de 365 j
            t1 = monetaire_vers_actuariel(t1, j1, self._an)
            base = "actuariel"
        else:
            base = b1
        t = t1 + (t2 - t1) * (j - j1) / (j2 - j1)
        return t, base, j

    def decaler(self, bp: float) -> "CourbeTaux":
        """Translation parallèle de la courbe de `bp` points de base (stress test)."""
        return CourbeTaux(self.date_courbe, [(j, t + bp / 1e4) for j, t in self.points], self.jours_min, self.nom, self.bissextile)

    def tableau(self, maturites_jours: Sequence[int] = (91, 182, 364, 730, 1825, 3650, 5475, 7300, 10950)):
        return [
            {"jours": j, "base": self._base(j), "taux": self.taux(j)} for j in maturites_jours
        ]

    def __repr__(self):
        return f"CourbeTaux({self.date_courbe}, {len(self.points)} points)"


@dataclass
class CourbePrimes:
    """Courbe des primes de risque d'un émetteur (art. 7.1).

    Points = (maturité résiduelle en jours, prime décimale) observés à l'émission des obligations de
    l'émetteur. Interpolation linéaire ; prime plate entre 0 et le premier point, et après le dernier.
    """

    points: list[tuple[int, float]] = field(default_factory=list)
    emetteur: str = ""

    def __post_init__(self):
        self.points = sorted((int(j), _parse_taux_prime(p)) for j, p in self.points)

    def prime(self, jours: int) -> float:
        if not self.points:
            return 0.0
        js = [j for j, _ in self.points]
        if jours <= js[0]:
            return self.points[0][1]
        if jours >= js[-1]:
            return self.points[-1][1]
        k = bisect_left(js, jours)
        (j1, p1), (j2, p2) = self.points[k - 1], self.points[k]
        return p1 + (p2 - p1) * (jours - j1) / (j2 - j1)


def _parse_taux_prime(p) -> float:
    """Primes : accepte décimal (0.0085), % (0.85) ou points de base via chaîne '85bp'."""
    if isinstance(p, str) and p.lower().strip().endswith(("bp", "pb")):
        return float(p.lower().strip()[:-2].replace(",", ".")) / 1e4
    v = float(str(p).replace(",", ".").replace("%", ""))
    return v / 100.0 if abs(v) >= 0.05 else v


def _maturite_texte(m: str) -> int:
    n, u = int(m.strip()[:-1]), m.strip()[-1].lower()
    return {"j": n, "s": 7 * n, "m": round(n * 365 / 12), "a": 365 * n}[u]


def _lire_table(source) -> list[dict]:
    try:
        import pandas as pd  # noqa

        if isinstance(source, pd.DataFrame):
            return source.astype(str).to_dict("records")
    except ImportError:
        pass
    if isinstance(source, (str, Path)) and Path(str(source)).exists():
        p = Path(source)
        if p.suffix.lower() in (".xls", ".xlsx"):
            import pandas as pd

            return pd.read_excel(p).astype(str).to_dict("records")
        raw = p.read_bytes()
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                texte = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
    else:
        texte = str(source)
    lignes = [l for l in texte.splitlines() if l.strip()]
    # saute d'éventuelles lignes de titre avant l'en-tête
    debut = next((i for i, l in enumerate(lignes) if "taux" in l.lower() and "ch" in l.lower()), 0)
    texte = "\n".join(lignes[debut:])
    dialect = csv.Sniffer().sniff(lignes[debut], delimiters=";,\t")
    return list(csv.DictReader(io.StringIO(texte), dialect=dialect))


def _norm(s: str) -> str:
    return (
        str(s).lower().replace("é", "e").replace("è", "e").replace("ê", "e").replace("’", "'").strip()
    )


def _trouver_col(cols, motifs, obligatoire=True):
    for c in cols:
        if any(_norm(m) in _norm(c) for m in motifs):
            return c
    if obligatoire:
        raise ValueError(f"Colonne introuvable ({motifs}) parmi {cols}")
    return None
