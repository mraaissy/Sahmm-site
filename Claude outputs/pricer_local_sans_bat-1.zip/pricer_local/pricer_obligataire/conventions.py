"""Conventions de calcul du marché obligataire marocain (circulaire CDVM/AMMC n° 02/04).

- Maturité résiduelle <= 365 jours : taux monétaire (intérêts simples, base Exact/360).
- Maturité résiduelle  > 365 jours : taux actuariel (intérêts composés, base Exact/365 ou 366).
"""
from __future__ import annotations

import calendar
from datetime import date, timedelta

SEUIL_MONETAIRE = 365  # jours : au-delà, on bascule en actuariel
BASE_MONETAIRE = 360


def est_bissextile(annee: int) -> bool:
    return calendar.isleap(annee)


def ajouter_mois(d: date, mois: int) -> date:
    """Ajoute (ou retire) un nombre de mois ; le 29/02 devient 28/02 si besoin."""
    m = d.month - 1 + mois
    annee = d.year + m // 12
    m = m % 12 + 1
    jour = min(d.day, calendar.monthrange(annee, m)[1])
    return date(annee, m, jour)


def ajouter_annees(d: date, n: int) -> date:
    return ajouter_mois(d, 12 * n)


def base_annuelle(date_fin: date) -> int:
    """Nombre de jours de l'année qui se termine à `date_fin` (365, ou 366 si elle contient un 29/02).

    C'est la lecture « période de coupon » du paramètre A de l'annexe : A = 366 si la période
    annuelle de coupon en cours contient un 29 février, 365 sinon.
    """
    return (date_fin - ajouter_annees(date_fin, -1)).days


def base_annee_calendaire(d: date) -> int:
    """Lecture littérale de l'annexe : A = 366 si l'année en cours est bissextile, 365 sinon."""
    return 366 if est_bissextile(d.year) else 365


def monetaire_vers_actuariel(tm: float, jours: int, annee: int = 365) -> float:
    """Taux monétaire (Exact/360, simple) -> taux actuariel équivalent (base `annee` : 365 ou 366)."""
    if jours <= 0:
        return tm
    return (1.0 + tm * jours / BASE_MONETAIRE) ** (annee / jours) - 1.0


def actuariel_vers_monetaire(ta: float, jours: int, annee: int = 365) -> float:
    """Taux actuariel (base `annee`) -> taux monétaire équivalent (Exact/360, simple)."""
    if jours <= 0:
        return ta
    return ((1.0 + ta) ** (jours / annee) - 1.0) * BASE_MONETAIRE / jours


def base_du_taux(jours: int, seuil: int = SEUIL_MONETAIRE) -> str:
    return "monetaire" if jours <= seuil else "actuariel"


def jours_un_an(d: date) -> int:
    """Nombre de jours entre d et d + 1 an (366 si la période contient un 29 février)."""
    return (ajouter_annees(d, 1) - d).days


def jours_entre(d1: date, d2: date) -> int:
    return (d2 - d1).days


__all__ = [
    "SEUIL_MONETAIRE", "BASE_MONETAIRE", "est_bissextile", "ajouter_mois", "ajouter_annees",
    "base_annuelle", "base_annee_calendaire", "monetaire_vers_actuariel",
    "actuariel_vers_monetaire", "base_du_taux", "jours_entre", "timedelta",
]
