# Pricer obligataire — version locale

Pricer de titres de créance marocains (circulaire CDVM/AMMC n° 02/04), à installer sur un poste de travail.
Il ne dépend que de **Python 3.10 ou plus**, sans aucune bibliothèque à installer : pas besoin de `pip`
ni d'accès Internet (utile derrière un proxy d'entreprise).

## Contenu

| Élément | Rôle |
|---|---|
| `lancer_pricer.bat` | Double-clic : lance le pricer dans le navigateur (Windows) |
| `app.py` | Serveur local de l'interface web (http://localhost:8765) |
| `web/index.html` | Interface : recherche ISIN, saisie manuelle, courbe BAM, flux, stress test |
| `valoriser_base.py` | Valorisation en série de toute la base → fichier CSV pour Excel |
| `data/Base Titres.xlsx` | Base des titres (ISIN, dates, taux facial, émetteur, VN) |
| `data/courbe_exemple.csv` | Courbe BAM d'exemple, au format de l'export bkam.ma |
| `data/primes_exemple.csv` | Primes de risque par émetteur (en pb), à adapter |
| `pricer_obligataire/` | Module de calcul Python |
| `tests/` | Tests des formules de la circulaire |

## Installation

1. Vérifier Python : ouvrir une invite de commandes et taper `python --version`.
   S'il n'est pas installé : python.org → Downloads → Windows, et cocher **« Add python.exe to PATH »**.
   Sans droits administrateur, l'installateur propose une installation « pour moi seulement ».
2. Dézipper `pricer_local.zip`, par exemple dans `C:\Users\<toi>\Documents\pricer_local`.

C'est tout.

## Utiliser l'interface

Double-cliquer sur **`lancer_pricer.bat`**. Le navigateur s'ouvre sur http://localhost:8765.
Laisser la fenêtre noire ouverte pendant l'utilisation ; la fermer arrête le pricer.

Équivalent en ligne de commande :

```
cd C:\Users\<toi>\Documents\pricer_local
python app.py
```

Options : `--port 9000`, `--base "D:\autre\base.xlsx"`, `--sans-navigateur`.

**Mettre à jour la base de titres** : remplacer `data\Base Titres.xlsx` par le nouveau fichier (même nom,
mêmes colonnes), puis actualiser la page (F5). La colonne des ISIN est reconnue d'après son contenu,
les autres par leur titre : Date d'émission, Date de maturité, Taux facial, Emetteur, VN.

## Valoriser toute la base

```
python valoriser_base.py --date 2026-09-24 --courbe data\courbe_exemple.csv --primes data\primes_exemple.csv
```

- `--courbe` : l'export CSV téléchargé sur bkam.ma (ou un fichier simple `maturite;taux`, ex. `13s;2,20`,
  avec `--date-courbe`).
- `--primes` : primes de risque par émetteur en pb. Les titres BKAM (Trésor) sont à 0 pb ; un émetteur
  absent du fichier est valorisé à 0 pb et signalé dans la colonne « Statut ».
- `--isin MA0000021537 MA0002019380` : limiter à quelques titres.
- `--sortie mon_fichier.csv` : nom du fichier produit (par défaut `valorisation_<date>.csv`).

Le CSV (séparateur `;`, décimales à virgule) s'ouvre directement dans Excel.
La base ne précisant pas le type de titre, le calcul en série suppose un **taux fixe, coupon annuel,
in fine**. Pour un révisable ou un amortissable, utiliser l'interface.

## Utiliser le module dans un script

```python
from pricer_obligataire import CourbeTaux, ObligationTauxFixe, valoriser

courbe = CourbeTaux.depuis_csv_bam("data/courbe_exemple.csv")
bdt = ObligationTauxFixe("BDT", 100_000, "2020-06-15", "2030-06-15", 3.50)
print(valoriser(bdt, "2026-09-24", courbe))
```

## Vérifier l'installation (optionnel)

```
pip install pytest
python -m pytest -q tests
```

## Conventions

Formules (1), (2), (4.1), (4.2), (4.3) de l'annexe de la circulaire 02/04 ; courbe BAM interpolée
linéairement (conversion monétaire → actuariel de part et d'autre d'un an) ; A = 365/366 selon la
période de coupon (option « calendaire » disponible).

Années bissextiles (par défaut) : le seuil monétaire/actuariel est « 1 an calendaire » (366 jours quand
l'année qui suit contient un 29 février) et la conversion des taux de la courbe se fait sur la même base.
Pour revenir à 365 jours fixes : menu « Seuil monétaire / actuariel » dans l'interface, ou
`valoriser(..., bissextile=False)` dans un script. Détails dans `pricer_obligataire/pricer.py`.
