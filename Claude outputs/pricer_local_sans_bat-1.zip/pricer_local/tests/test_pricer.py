"""Tests : conformité aux formules de l'annexe de la circulaire 02/04 et cohérence interne."""
from datetime import date

import pytest

from pricer_obligataire import (
    CourbePrimes, CourbeTaux, ObligationAmortissable, ObligationRevisable, ObligationTauxFixe,
    ZeroCoupon, actuariel_vers_monetaire, monetaire_vers_actuariel, stress, taux_depuis_prix,
    valoriser,
)

N = 100_000
D = date(2026, 9, 24)


def courbe_test():
    return CourbeTaux.depuis_maturites(D, {
        "13s": 2.20, "26s": 2.25, "52s": 2.35, "2a": 2.45, "5a": 2.70, "10a": 3.10,
        "15a": 3.40, "20a": 3.65, "30a": 3.95,
    })


# ------------------------------------------------------------------ formule (1)
def test_formule_1_bt_court_terme():
    bt = ObligationTauxFixe("BT52", N, date(2026, 1, 15), date(2027, 1, 14), 2.5)
    tr = 0.023
    res = valoriser(bt, D, taux=tr)
    Mi, Mr = 364, (date(2027, 1, 14) - D).days
    attendu = N * (1 + 0.025 * Mi / 360) / (1 + tr * Mr / 360)
    assert res.base == "monetaire"
    assert res.prix_plein == pytest.approx(attendu, rel=1e-12)
    assert res.coupon_couru == pytest.approx(N * 0.025 * (D - date(2026, 1, 15)).days / 360)


# ------------------------------------------------------------------ formule (2)
def test_formule_2_residuel_court():
    ob = ObligationTauxFixe("BDT", N, date(2022, 3, 10), date(2027, 3, 10), 3.0)
    tr = 0.024
    res = valoriser(ob, D, taux=tr)
    Mr = (date(2027, 3, 10) - D).days
    assert res.base == "monetaire"
    assert res.prix_plein == pytest.approx(N * 1.03 / (1 + tr * Mr / 360), rel=1e-12)


# ------------------------------------------------------------------ formule (4.1)
def test_formule_41_ligne_normale():
    ob = ObligationTauxFixe("BDT10", N, date(2020, 6, 15), date(2030, 6, 15), 3.5)
    tr = 0.028
    res = valoriser(ob, D, taux=tr)
    nj = (date(2027, 6, 15) - D).days
    A = 365  # 15/06/2026 -> 15/06/2027 : pas de 29/02
    n = 4
    s = sum(0.035 / (1 + tr) ** (i - 1) for i in range(1, n + 1)) + 1 / (1 + tr) ** (n - 1)
    attendu = N / (1 + tr) ** (nj / A) * s
    assert res.base == "actuariel"
    assert res.prix_plein == pytest.approx(attendu, rel=1e-12)
    cc = N * 0.035 * (D - date(2026, 6, 15)).days / 365
    assert res.coupon_couru == pytest.approx(cc)


def test_A_bissextile():
    # période de coupon 01/03/2027 -> 01/03/2028 contient le 29/02/2028 : A = 366
    ob = ObligationTauxFixe("BDT", N, date(2024, 3, 1), date(2031, 3, 1), 3.0)
    res = valoriser(ob, date(2027, 9, 1), taux=0.03)
    nj = (date(2028, 3, 1) - date(2027, 9, 1)).days
    assert res.echeancier[0]["temps"] == pytest.approx(nj / 366)
    res_cal = valoriser(ob, date(2027, 9, 1), taux=0.03, convention_A="calendaire")
    assert res_cal.echeancier[0]["temps"] == pytest.approx(nj / 365)


# ------------------------------------------------------------------ formule (4.2)
def test_formule_42_posterieure_un_flux():
    em, ech = date(2025, 5, 20), date(2028, 5, 20)  # un seul flux (coupon long cumulé)
    ob = ObligationTauxFixe("POST1", N, em, ech, 3.0, date_premier_coupon=ech)
    tr = 0.027
    res = valoriser(ob, D, taux=tr)
    Mi, nj = (ech - em).days, (ech - D).days
    A = 366  # 20/05/2027 -> 20/05/2028 contient le 29/02/2028
    attendu = N * (1 + 0.03 * Mi / A) / (1 + tr) ** (nj / A)
    assert res.prix_plein == pytest.approx(attendu, rel=1e-12)


# ------------------------------------------------------------------ formule (4.3)
def test_formule_43_posterieure_plusieurs_flux():
    em, d1c, ech = date(2026, 2, 1), date(2027, 11, 1), date(2031, 11, 1)
    ob = ObligationTauxFixe("POSTN", N, em, ech, 3.2, date_premier_coupon=d1c)
    tr = 0.029
    res = valoriser(ob, D, taux=tr)
    nj, A, n = (d1c - D).days, 365, 5
    s = 0.032 * (d1c - em).days / A
    s += sum(0.032 / (1 + tr) ** (i - 1) for i in range(2, n + 1)) + 1 / (1 + tr) ** (n - 1)
    assert res.prix_plein == pytest.approx(N / (1 + tr) ** (nj / A) * s, rel=1e-12)


# ------------------------------------------------------------------ cohérence
def test_pair_au_detachement():
    ob = ObligationTauxFixe("PAR", N, date(2021, 9, 24), date(2031, 9, 24), 3.0)
    res = valoriser(ob, D, taux=0.03)
    assert res.prix_pied_pct == pytest.approx(100.0, abs=1e-9)


def test_aller_retour_prix_taux():
    ob = ObligationTauxFixe("RT", N, date(2020, 6, 15), date(2035, 6, 15), 3.8)
    res = valoriser(ob, D, courbe=courbe_test())
    inv = taux_depuis_prix(ob, D, res.prix_pied_pct, courbe=courbe_test())
    assert inv["taux"] == pytest.approx(res.taux, abs=1e-10)
    assert inv["spread_implicite"] == pytest.approx(0.0, abs=1e-10)


@pytest.mark.parametrize("ech", [date(2027, 3, 10), date(2034, 3, 10)])
def test_sensibilite_numerique(ech):
    ob = ObligationTauxFixe("S", N, date(2022, 3, 10), ech, 3.0)
    r, h = 0.03, 1e-6
    p0 = valoriser(ob, D, taux=r)
    pu, pd = valoriser(ob, D, taux=r + h).prix_plein, valoriser(ob, D, taux=r - h).prix_plein
    assert p0.sensibilite == pytest.approx(-(pu - pd) / (2 * h) / p0.prix_plein, rel=1e-5)
    assert p0.convexite == pytest.approx((pu + pd - 2 * p0.prix_plein) / h**2 / p0.prix_plein, rel=1e-3)


def test_zero_coupon():
    zc = ZeroCoupon("ZC", N, date(2024, 1, 1), date(2029, 1, 1))
    res = valoriser(zc, D, taux=0.03)
    nj = (date(2029, 1, 1) - D).days
    A = 366  # formule 4.2 : A de la période annuelle précédant l'échéance (contient le 29/02/2028)
    assert res.prix_plein == pytest.approx(N / 1.03 ** (nj / A))
    assert res.coupon_couru == 0
    assert res.duration == pytest.approx(nj / A)


# ------------------------------------------------------------------ courbe
def test_courbe_interpolation():
    c = courbe_test()
    assert c.taux(91) == pytest.approx(0.022)
    assert c.taux(30) == pytest.approx(0.022)  # plat avant le 1er point (art. 6.3)
    # entre 13s et 26s : linéaire monétaire
    assert c.taux(136) == pytest.approx(0.022 + 0.0005 * (136 - 91) / (182 - 91))
    # entre 52s (364 j, monétaire) et 2a (730 j, actuariel) : interpolation en actuariel
    a364 = monetaire_vers_actuariel(0.0235, 364)
    attendu = a364 + (0.0245 - a364) * (500 - 364) / (730 - 364)
    assert c.taux(500) == pytest.approx(attendu)
    assert c.taux(10950 + 500) == pytest.approx(0.0395)
    # conversions réciproques
    assert actuariel_vers_monetaire(monetaire_vers_actuariel(0.025, 200), 200) == pytest.approx(0.025)


def test_courbe_jours_min():
    c = CourbeTaux.depuis_maturites(D, {10: 2.0, 91: 2.2}, jours_min=56)
    assert c.taux(20) == pytest.approx(c.taux(56))


def test_csv_bam(tmp_path):
    txt = (
        "Date d'échéance;Transaction;Taux moyen pondéré;Date de la valeur\n"
        "24/12/2026;100 000 000,00;2,200 %;24/09/2026\n"
        "23/09/2027;;2,350 %;24/09/2026\n"
        "24/09/2031;;2,700 %;24/09/2026\n"
    )
    p = tmp_path / "bam.csv"
    p.write_text(txt, encoding="utf-8")
    c = CourbeTaux.depuis_csv_bam(p)
    assert c.date_courbe == D
    assert c.points[0] == (91, pytest.approx(0.022))
    assert len(c.points) == 3


# ------------------------------------------------------------------ primes
def test_prime_emetteur():
    primes = CourbePrimes([(1825, "60bp"), (3650, "90bp")], "Emetteur X")
    assert primes.prime(1000) == pytest.approx(0.006)
    assert primes.prime(2737) == pytest.approx(0.0075, abs=1e-6)
    ob = ObligationTauxFixe("CORP", N, date(2024, 6, 1), date(2031, 6, 1), 4.0, prime=primes)
    c = courbe_test()
    res = valoriser(ob, D, courbe=c)
    j = (date(2031, 6, 1) - D).days
    assert res.taux == pytest.approx(c.taux(j) + primes.prime(j))


# ------------------------------------------------------------------ amortissable
def test_amortissable_constant():
    ob = ObligationAmortissable("AMO", N, date(2023, 9, 24), date(2030, 9, 24), 4.0, differe=2)
    fl = ob.flux()
    assert len(fl) == 7
    assert sum(f.amortissement for f in fl) == pytest.approx(N)
    assert fl[2].amortissement == pytest.approx(N / 5)
    assert fl[3].coupon == pytest.approx(0.04 * N * 4 / 5)
    res = valoriser(ob, D, taux=0.04)
    assert res.prix_pied_pct == pytest.approx(100.0, abs=1e-9)
    assert res.capital_restant == pytest.approx(N * 4 / 5)
    # maturité de lecture = vie moyenne
    assert ob.jours_taux_reference(D) < (ob.date_echeance - D).days


# ------------------------------------------------------------------ révisable
def test_revisable_au_pair():
    ob = ObligationRevisable("REV", N, date(2024, 3, 15), date(2034, 3, 15),
                             taux_courant=2.95, spread_emission="60bp")
    res = valoriser(ob, D, courbe=courbe_test())
    nj = (date(2027, 3, 15) - D).days
    C = N * 0.0295 * 365 / 360
    r = courbe_test().taux(nj, "monetaire") + 0.006
    assert res.prix_plein == pytest.approx((N + C) / (1 + r * nj / 360))
    assert res.ajustement_spread == 0


def test_revisable_ajustement_spread():
    ob = ObligationRevisable("REV", N, date(2024, 3, 15), date(2034, 3, 15),
                             taux_courant=2.95, spread_emission="60bp", prime="90bp")
    res = valoriser(ob, D, courbe=courbe_test())
    assert res.ajustement_spread < 0  # prime de marché > spread facial -> décote


def test_stress():
    ob = ObligationTauxFixe("BDT10", N, date(2020, 6, 15), date(2030, 6, 15), 3.5)
    s = stress(ob, D, courbe_test(), (-50, 50))
    assert s[0]["variation"] > 0 > s[1]["variation"]


# ------------------------------------------------------------------ années bissextiles
def test_bissextile_conversion_et_seuil():
    d = date(2027, 6, 15)  # l'année suivante contient le 29/02/2028 : 1 an = 366 j
    c = CourbeTaux(d, [(328, 0.0232), (510, 0.0242)])
    a366 = (1 + 0.0232 * 328 / 360) ** (366 / 328) - 1
    assert c.taux(400) == pytest.approx(a366 + (0.0242 - a366) * (400 - 328) / (510 - 328))
    c365 = CourbeTaux(d, [(328, 0.0232), (510, 0.0242)], bissextile=False)
    assert c365.taux(400) < c.taux(400)
    # titre à 366 j de l'échéance : monétaire (1 an calendaire), actuariel en convention 365 j
    ob = ObligationTauxFixe("B", N, date(2020, 6, 16), date(2028, 6, 15), 3.0)
    assert valoriser(ob, d, taux=0.03).base == "monetaire"
    assert valoriser(ob, d, taux=0.03, bissextile=False).base == "actuariel"


def test_bissextile_sans_effet_hors_29_fevrier():
    ob = ObligationTauxFixe("BDT10", N, date(2020, 6, 15), date(2030, 6, 15), 3.5)
    a = valoriser(ob, D, courbe_test())
    b = valoriser(ob, D, courbe_test(), bissextile=False)
    assert a.prix_plein == pytest.approx(b.prix_plein, rel=1e-14)
