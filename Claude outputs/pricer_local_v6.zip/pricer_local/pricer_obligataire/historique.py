"""Historique de la courbe des taux de référence BAM et variations (jour, mois, début d'année).

Chaque courbe téléchargée sur bkam.ma est conservée telle quelle (CSV d'origine) dans
data/historique_courbes/AAAA-MM-JJ.csv. Les jours sans publication (fériés…) sont notés dans
_jours_sans_courbe.txt pour ne pas être redemandés.

Variations : la courbe du jour D est comparée à
  - J-1      : la dernière courbe publiée avant D ;
  - mois     : la dernière courbe du mois précédent (MTD) ;
  - YTD      : la dernière courbe de l'année précédente.
Les taux sont lus aux maturités standard BAM (13 s … 30 ans) par interpolation, dans leur base
de publication (monétaire jusqu'à 1 an, actuariel au-delà). Variations en points de base.
"""
from __future__ import annotations

import threading
from datetime import date, datetime, timedelta
from pathlib import Path

from .bam import _a_des_taux, _telecharger
from .courbe import CourbeTaux, _parse_date

DOSSIER_DEFAUT = Path(__file__).resolve().parent.parent / "data" / "historique_courbes"
MATURITES = [  # libellé, jours
    ("13 sem.", 91), ("26 sem.", 182), ("52 sem.", 364), ("2 ans", 730), ("5 ans", 1825),
    ("10 ans", 3650), ("15 ans", 5475), ("20 ans", 7300), ("30 ans", 10950),
]
_verrou = threading.Lock()


class Historique:
    def __init__(self, dossier: Path | str = DOSSIER_DEFAUT, telecharger=_telecharger):
        self.dossier = Path(dossier)
        self.dossier.mkdir(parents=True, exist_ok=True)
        self._telecharger = telecharger
        self._cache: dict[date, CourbeTaux] = {}

    # ------------------------------------------------------------------ stockage
    def _fichier(self, jour: date) -> Path:
        return self.dossier / f"{jour.isoformat()}.csv"

    @property
    def _fichier_absents(self) -> Path:
        return self.dossier / "_jours_sans_courbe.txt"

    def _absents(self) -> set[date]:
        try:
            return {date.fromisoformat(l.strip()) for l in self._fichier_absents.read_text().splitlines() if l.strip()}
        except FileNotFoundError:
            return set()

    def _noter_absent(self, jour: date) -> None:
        with _verrou, open(self._fichier_absents, "a", encoding="utf-8") as f:
            f.write(jour.isoformat() + "\n")

    def enregistrer(self, texte: str, jour: date) -> None:
        self._fichier(jour).write_text(texte, encoding="utf-8")
        self._cache.pop(jour, None)

    def dates(self) -> list[date]:
        out = []
        for p in self.dossier.glob("????-??-??.csv"):
            try:
                out.append(date.fromisoformat(p.stem))
            except ValueError:
                pass
        return sorted(out)

    def texte(self, jour: date) -> str | None:
        p = self._fichier(jour)
        return p.read_text(encoding="utf-8") if p.exists() else None

    def courbe(self, jour: date) -> CourbeTaux | None:
        if jour not in self._cache:
            t = self.texte(jour)
            if t is None:
                return None
            self._cache[jour] = CourbeTaux.depuis_csv_bam(t, date_courbe=jour)
        return self._cache[jour]

    # ------------------------------------------------------------------ récupération
    def courbe_au_plus_tard(self, jour_voulu, max_recul: int = 10, telecharger: bool = True) -> tuple[CourbeTaux, date]:
        """Dernière courbe publiée à `jour_voulu` ou avant (historique d'abord, sinon bkam.ma)."""
        d = _parse_date(jour_voulu)
        absents, aujourd_hui = self._absents(), date.today()
        for k in range(max_recul + 1):
            j = d - timedelta(days=k)
            if j.weekday() >= 5 or j in absents or j > aujourd_hui:
                continue
            c = self.courbe(j)
            if c is not None:
                return c, j
            if not telecharger:
                continue
            texte = self._telecharger(j)
            if _a_des_taux(texte):
                self.enregistrer(texte, j)
                return self.courbe(j), j
            if j < aujourd_hui:  # aujourd'hui : la courbe peut encore être publiée (15h)
                self._noter_absent(j)
        raise RuntimeError(f"Aucune courbe BAM entre le {d - timedelta(days=max_recul):%d/%m/%Y} et le {d:%d/%m/%Y}.")

    def completer(self, depuis, jusqu=None, progression=None) -> dict:
        """Télécharge toutes les courbes manquantes entre deux dates (jours ouvrés)."""
        d0, d1 = _parse_date(depuis), _parse_date(jusqu or date.today())
        presents, absents = set(self.dates()), self._absents()
        jours = [d0 + timedelta(days=i) for i in range((d1 - d0).days + 1)]
        a_faire = [j for j in jours if j.weekday() < 5 and j not in presents and j not in absents]
        ajoutes = erreurs = 0
        for i, j in enumerate(a_faire, 1):
            try:
                texte = self._telecharger(j)
                if _a_des_taux(texte):
                    self.enregistrer(texte, j)
                    ajoutes += 1
                elif j < date.today():
                    self._noter_absent(j)
            except Exception:
                erreurs += 1
            if progression:
                progression(i, len(a_faire), j)
        return {"a_faire": len(a_faire), "ajoutes": ajoutes, "erreurs": erreurs, "total": len(self.dates())}

    # ------------------------------------------------------------------ analyses
    @staticmethod
    def points_standard(c: CourbeTaux) -> list[float]:
        return [c.taux(j) for _, j in MATURITES]

    def variations(self, jour, telecharger: bool = True) -> dict:
        """Taux aux maturités standard et variations jour / mois / YTD (en points de base)."""
        c0, d0 = self.courbe_au_plus_tard(jour, telecharger=telecharger)
        fin_mois_prec = d0.replace(day=1) - timedelta(days=1)
        fin_annee_prec = date(d0.year - 1, 12, 31)
        refs = {}
        for cle, voulu in (("jour", d0 - timedelta(days=1)), ("mois", fin_mois_prec), ("ytd", fin_annee_prec)):
            try:
                c, d = self.courbe_au_plus_tard(voulu, telecharger=telecharger)
                refs[cle] = (c, d)
            except Exception as e:
                refs[cle] = (None, None, str(e))
        t0 = self.points_standard(c0)
        lignes = []
        for i, (lib, j) in enumerate(MATURITES):
            ligne = {"maturite": lib, "jours": j, "base": "monetaire" if j <= 365 else "actuariel", "taux": t0[i]}
            for cle, ref in refs.items():
                ligne[cle] = None if ref[0] is None else (t0[i] - self.points_standard(ref[0])[i]) * 1e4
            lignes.append(ligne)
        return {
            "date": d0.isoformat(),
            "references": {k: (v[1].isoformat() if v[1] else None) for k, v in refs.items()},
            "erreurs": {k: v[2] for k, v in refs.items() if len(v) > 2},
            "courbes": {
                "date": t0,
                **{k: (self.points_standard(v[0]) if v[0] is not None else None) for k, v in refs.items()},
            },
            "lignes": lignes,
        }

    def serie(self, jours_maturite: int, depuis=None, jusqu=None) -> list[tuple[str, float]]:
        """Évolution du taux à une maturité donnée sur l'historique stocké."""
        d0 = _parse_date(depuis) if depuis else date.min
        d1 = _parse_date(jusqu) if jusqu else date.max
        out = []
        for d in self.dates():
            if d0 <= d <= d1:
                try:
                    out.append((d.isoformat(), self.courbe(d).taux(jours_maturite)))
                except Exception:
                    pass
        return out

    def export_csv(self) -> str:
        """Tableau date x maturités standard (taux en %), séparateur ; et virgule décimale."""
        lignes = ["Date;" + ";".join(lib for lib, _ in MATURITES)]
        for d in self.dates():
            try:
                pts = self.points_standard(self.courbe(d))
            except Exception:
                continue
            lignes.append(f"{d:%d/%m/%Y};" + ";".join(f"{t * 100:.3f}".replace(".", ",") for t in pts))
        return "\n".join(lignes) + "\n"


if __name__ == "__main__":  # python -m pricer_obligataire.historique 2026-10-05
    import sys

    h = Historique()
    v = h.variations(sys.argv[1] if len(sys.argv) > 1 else date.today())
    print(f"Courbe du {v['date']}  |  réf. J-1 {v['references']['jour']}  mois {v['references']['mois']}  YTD {v['references']['ytd']}")
    for l in v["lignes"]:
        f = lambda x: "   n.d." if x is None else f"{x:+7.1f}"
        print(f"{l['maturite']:>8}  {l['taux'] * 100:6.3f} %   jour {f(l['jour'])}  mois {f(l['mois'])}  YTD {f(l['ytd'])} pb")
