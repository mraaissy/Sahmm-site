"""Pricer obligataire — marché marocain (circulaire CDVM/AMMC n° 02/04)."""
from .conventions import actuariel_vers_monetaire, monetaire_vers_actuariel
from .courbe import CourbePrimes, CourbeTaux
from .instruments import (
    Flux,
    Obligation,
    ObligationAmortissable,
    ObligationRevisable,
    ObligationTauxFixe,
    ZeroCoupon,
)
from .pricer import Resultat, prix_depuis_taux, stress, taux_depuis_prix, valoriser

__version__ = "1.0.0"
__all__ = [
    "CourbeTaux", "CourbePrimes", "Flux", "Obligation", "ObligationTauxFixe", "ZeroCoupon",
    "ObligationAmortissable", "ObligationRevisable", "Resultat", "valoriser", "prix_depuis_taux",
    "taux_depuis_prix", "stress", "monetaire_vers_actuariel", "actuariel_vers_monetaire",
]
