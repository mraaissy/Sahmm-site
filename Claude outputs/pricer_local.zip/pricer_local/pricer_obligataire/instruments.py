"""Définition des titres de créance : taux fixe in fine, zéro-coupon / BT, amortissables, révisables."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Sequence

from .conventions import BASE_MONETAIRE, SEUIL_MONETAIRE, ajouter_mois, base_annuelle
from .courbe import CourbePrimes, _parse_date, _parse_taux, _parse_taux_prime


@dataclass
class Flux:
    date: date
    coupon: float
    amortissement: float
    capital_debut: float

    @property
    def total(self) -> float:
        return self.coupon + self.amortissement


@dataclass
class Obligation:
    """Titre de créance à taux fixe remboursable in fine (cas de base de la circulaire 02/04).

    taux_facial : décimal (0.035) ou % (3.5).
    frequence   : nombre de coupons par an (1 = annuel, standard au Maroc).
    prime       : prime de risque/liquidité (art. 6.4, 6.5, 7) : décimal, %, '85bp' ou CourbePrimes.
    date_premier_coupon : à renseigner pour une ligne « postérieure » (1er coupon long) ou à
                          1er coupon court ; sinon l'échéancier est construit à rebours depuis
                          l'échéance.
    """

    code: str
    nominal: float
    date_emission: date
    date_echeance: date
    taux_facial: float = 0.0
    frequence: int = 1
    prime: float | str | CourbePrimes | None = 0.0
    date_premier_coupon: date | None = None
    emetteur: str = "Trésor"

    def __post_init__(self):
        self.date_emission = _parse_date(self.date_emission)
        self.date_echeance = _parse_date(self.date_echeance)
        if self.date_premier_coupon is not None:
            self.date_premier_coupon = _parse_date(self.date_premier_coupon)
        self.taux_facial = _parse_taux(self.taux_facial) if self.taux_facial else 0.0
        if self.prime is not None and not isinstance(self.prime, CourbePrimes):
            self.prime = _parse_taux_prime(self.prime) if self.prime else 0.0
        if self.date_echeance <= self.date_emission:
            raise ValueError("La date d'échéance doit être postérieure à la date d'émission.")
        if 12 % self.frequence:
            raise ValueError("frequence doit diviser 12 (1, 2, 4 ou 12).")

    # ------------------------------------------------------------------ caractéristiques
    @property
    def maturite_initiale(self) -> int:
        return (self.date_echeance - self.date_emission).days

    @property
    def court_terme(self) -> bool:
        """Maturité initiale <= 365 jours : flux unique, formule (1) de l'annexe."""
        return self.maturite_initiale <= SEUIL_MONETAIRE

    @property
    def mois_periode(self) -> int:
        return 12 // self.frequence

    def dates_coupon(self) -> list[date]:
        if self.court_terme:
            return [self.date_echeance]
        p = self.mois_periode
        if self.date_premier_coupon:
            dates, d = [], self.date_premier_coupon
            k = 0
            while d < self.date_echeance:
                dates.append(d)
                k += 1
                d = ajouter_mois(self.date_premier_coupon, p * k)
            dates.append(self.date_echeance)
            return dates
        dates, k = [], 0
        while True:
            d = ajouter_mois(self.date_echeance, -p * k)
            if d <= self.date_emission:
                break
            dates.append(d)
            k += 1
        return sorted(dates)

    def _coupon_periode(self, capital: float, debut: date, fin: date, taux: float) -> float:
        if self.court_terme:  # formule (1) : intérêts simples Exact/360
            return capital * taux * (fin - debut).days / BASE_MONETAIRE
        reguliere = ajouter_mois(debut, self.mois_periode) == fin
        if reguliere:
            return capital * taux / self.frequence
        # période irrégulière (ligne postérieure / 1er coupon court) : prorata Exact/A (formule 4.3)
        return capital * taux * (fin - debut).days / base_annuelle(fin)

    def _amortissements(self, dates: Sequence[date]) -> list[float]:
        return [0.0] * (len(dates) - 1) + [self.nominal]

    def flux(self) -> list[Flux]:
        dates = self.dates_coupon()
        amort = self._amortissements(dates)
        capital, debut, out = self.nominal, self.date_emission, []
        for d, a in zip(dates, amort):
            c = self._coupon_periode(capital, debut, d, self.taux_facial)
            out.append(Flux(d, c, a, capital))
            capital -= a
            debut = d
        return out

    def flux_restants(self, d: date) -> list[Flux]:
        return [f for f in self.flux() if f.date > d]

    def date_coupon_precedent(self, d: date) -> date:
        passees = [f.date for f in self.flux() if f.date <= d]
        return passees[-1] if passees else self.date_emission

    def capital_restant(self, d: date) -> float:
        return self.nominal - sum(f.amortissement for f in self.flux() if f.date <= d)

    def coupon_couru(self, d: date) -> float:
        restants = self.flux_restants(d)
        if not restants:
            return 0.0
        prochain = restants[0]
        debut = self.date_coupon_precedent(d)
        duree = (prochain.date - debut).days
        return prochain.coupon * (d - debut).days / duree if duree else 0.0

    def jours_taux_reference(self, d: date) -> int:
        """Maturité (jours) utilisée pour lire la courbe BAM : échéance résiduelle."""
        return (self.date_echeance - d).days

    def prime_a(self, jours: int) -> float:
        if isinstance(self.prime, CourbePrimes):
            return self.prime.prime(jours)
        return float(self.prime or 0.0)


@dataclass
class ObligationTauxFixe(Obligation):
    """Obligation / BDT à taux fixe remboursable in fine."""


@dataclass
class ZeroCoupon(Obligation):
    """Titre zéro-coupon : un seul flux (le nominal) à l'échéance.

    Pour un BT court terme à intérêts post-comptés, utiliser ObligationTauxFixe avec
    maturité <= 365 j : flux = N x (1 + tf x Mi/360), formule (1).
    """

    def dates_coupon(self) -> list[date]:
        return [self.date_echeance]

    def _coupon_periode(self, capital, debut, fin, taux) -> float:
        return 0.0


@dataclass
class ObligationAmortissable(Obligation):
    """Obligation à amortissement du nominal.

    amortissement : 'constant' (tranches égales après le différé) ou liste de montants (un par
                    date de coupon, somme = nominal) ou dict {date: montant}.
    differe       : nombre de périodes sans amortissement (mode 'constant').
    maturite_taux : 'vie_moyenne' (défaut, pratique de place pour les amortissables) ou 'echeance'.
    """

    amortissement: str | Sequence[float] | dict = "constant"
    differe: int = 0
    maturite_taux: str = "vie_moyenne"

    def _amortissements(self, dates):
        n = len(dates)
        if isinstance(self.amortissement, str):
            if self.amortissement != "constant":
                raise ValueError("amortissement : 'constant', liste ou dict.")
            k = n - self.differe
            if k <= 0:
                raise ValueError("Différé trop long pour le nombre de périodes.")
            tranche = self.nominal / k
            return [0.0] * self.differe + [tranche] * k
        if isinstance(self.amortissement, dict):
            m = {_parse_date(k): float(v) for k, v in self.amortissement.items()}
            am = [m.get(d, 0.0) for d in dates]
        else:
            am = [float(x) for x in self.amortissement]
            if len(am) != n:
                raise ValueError(f"{n} montants d'amortissement attendus, {len(am)} fournis.")
        if abs(sum(am) - self.nominal) > 1e-6 * self.nominal:
            raise ValueError("La somme des amortissements doit égaler le nominal.")
        return am

    def jours_taux_reference(self, d: date) -> int:
        if self.maturite_taux == "echeance":
            return super().jours_taux_reference(d)
        restants = self.flux_restants(d)
        total = sum(f.amortissement for f in restants)
        return round(sum(f.amortissement * (f.date - d).days for f in restants) / total)

    def vie_moyenne(self, d: date) -> float:
        """Durée de vie moyenne résiduelle en années."""
        restants = self.flux_restants(d)
        total = sum(f.amortissement for f in restants)
        return sum(f.amortissement * (f.date - d).days for f in restants) / total / 365.0


@dataclass
class ObligationRevisable(Obligation):
    """Obligation à taux révisable (révision à chaque date de coupon).

    taux_courant    : taux du coupon en cours (déjà fixé) = taux de référence + spread.
    spread_emission : marge faciale ajoutée au taux de référence.
    base_coupon     : 'Exact/360' (coupon = N x t x jours/360, usage monétaire) ou 'annuel'.

    Valorisation : le titre est actualisé jusqu'à la prochaine date de révision, où il est
    remboursé fictivement au pair avec le coupon connu. Si la prime de marché diffère du spread
    facial, l'écart (spread - prime) est actualisé sur les coupons suivants (ajustement_spread).
    Par défaut la prime de marché = spread d'émission (titre au pair à la révision).
    """

    prime: float | str | CourbePrimes | None = None  # None -> prime = spread d'émission
    taux_courant: float = 0.0
    spread_emission: float | str = 0.0
    base_coupon: str = "Exact/360"
    ajustement_spread: bool = True

    def __post_init__(self):
        prime_non_fournie = self.prime is None
        super().__post_init__()
        self.taux_courant = _parse_taux(self.taux_courant) if self.taux_courant else 0.0
        self.spread_emission = _parse_taux_prime(self.spread_emission) if self.spread_emission else 0.0
        if prime_non_fournie:
            self.prime = self.spread_emission
        if not self.taux_facial:
            self.taux_facial = self.taux_courant

    def _coupon_periode(self, capital, debut, fin, taux):
        if self.base_coupon.lower().startswith("exact"):
            return capital * taux * (fin - debut).days / BASE_MONETAIRE
        return super()._coupon_periode(capital, debut, fin, taux)

    def flux(self) -> list[Flux]:
        """Échéancier projeté au taux courant (les coupons futurs ne sont pas connus)."""
        dates = self.dates_coupon()
        out, debut = [], self.date_emission
        for i, d in enumerate(dates):
            a = self.nominal if i == len(dates) - 1 else 0.0
            out.append(Flux(d, self._coupon_periode(self.nominal, debut, d, self.taux_courant), a, self.nominal))
            debut = d
        return out

    def flux_valorisation(self, d: date) -> list[Flux]:
        """Flux fictifs : coupon connu + nominal à la prochaine révision."""
        prochain = self.flux_restants(d)[0]
        return [Flux(prochain.date, prochain.coupon, self.nominal, self.nominal)]

    def dates_apres_revision(self, d: date) -> list[date]:
        return [f.date for f in self.flux_restants(d)[1:]]

    def jours_taux_reference(self, d: date) -> int:
        return (self.flux_restants(d)[0].date - d).days


__all__ = [
    "Flux", "Obligation", "ObligationTauxFixe", "ZeroCoupon", "ObligationAmortissable",
    "ObligationRevisable",
]
