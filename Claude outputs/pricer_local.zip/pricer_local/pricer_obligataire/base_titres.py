"""Lecture de la base de titres (fichier Excel .xlsx) sans dépendance externe.

Colonnes reconnues (ordre libre, casse et accents ignorés) :
  ISIN / INSTRID, Date d'émission, Date de maturité (ou d'échéance), Taux facial, Emetteur, VN.
La colonne contenant les codes ISIN (MA0000021230…) est détectée d'après son contenu :
dans le fichier d'origine, « INSTRID » contient l'ISIN et « ISIN » le code Maroclear.
"""
from __future__ import annotations

import re
import unicodedata
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RELS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
ISIN_RE = re.compile(r"^[A-Z]{2}[A-Z0-9]{9}\d$")


def _norm(s) -> str:
    s = unicodedata.normalize("NFD", str(s or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _col_index(ref: str) -> int:
    n = 0
    for ch in re.match(r"[A-Z]+", ref).group(0):
        n = n * 26 + ord(ch) - 64
    return n - 1


def lire_xlsx(chemin) -> list[list]:
    """Renvoie les lignes de la première feuille (valeurs brutes : str ou float)."""
    with zipfile.ZipFile(chemin) as z:
        partages = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
                partages.append("".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rid = wb.find("m:sheets/m:sheet", NS).get(RELS)
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        cible = next(r.get("Target") for r in rels if r.get("Id") == rid)
        cible = cible.lstrip("/")
        feuille = cible if cible.startswith("xl/") else "xl/" + cible
        lignes = []
        for row in ET.fromstring(z.read(feuille)).iter(f"{{{NS['m']}}}row"):
            vals = {}
            for c in row.findall("m:c", NS):
                t, v = c.get("t"), c.find("m:v", NS)
                if t == "s" and v is not None:
                    val = partages[int(v.text)]
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(f"{{{NS['m']}}}t"))
                elif v is not None:
                    try:
                        val = float(v.text)
                    except ValueError:
                        val = v.text
                else:
                    val = None
                vals[_col_index(c.get("r"))] = val
            if vals:
                lignes.append([vals.get(i) for i in range(max(vals) + 1)])
        return lignes


def _date(v) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, float):
        return date(1899, 12, 30) + timedelta(days=int(v))
    s = str(v).strip()
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def _num(v) -> float | None:
    if v is None or v == "":
        return None
    if isinstance(v, float):
        return v
    try:
        return float(str(v).replace("%", "").replace("\xa0", "").replace(" ", "").replace(",", "."))
    except ValueError:
        return None


def charger_base(chemin) -> list[dict]:
    """Charge la base de titres et renvoie une liste de dicts normalisés.

    taux_facial est en % (5.3 = 5,30 %) ; les taux saisis en décimal (0.053) ou en %
    (5.3) sont acceptés.
    """
    lignes = lire_xlsx(chemin)
    if not lignes:
        return []
    entete = [_norm(h) for h in lignes[0]]
    donnees = lignes[1:]

    def col(*motifs):
        for i, h in enumerate(entete):
            if any(m in h for m in motifs):
                return i
        return None

    # colonne ISIN détectée par le contenu
    c_isin = None
    for i in range(len(entete)):
        vals = [str(r[i]).strip().upper() for r in donnees[:50] if i < len(r) and r[i] is not None]
        if vals and sum(bool(ISIN_RE.match(v)) for v in vals) >= 0.8 * len(vals):
            c_isin = i
            break
    if c_isin is None:
        raise ValueError("Aucune colonne ne contient de codes ISIN (ex. MA0000021230).")
    c_code = next((i for i in (col("instrid"), col("isin"), col("code")) if i is not None and i != c_isin), None)
    c_em, c_ech = col("emission"), col("maturite", "echeance")
    c_tf, c_emet, c_vn = col("tauxfacial", "taux"), col("emetteur"), col("vn", "nominal")
    for nom, c in (("Date d'émission", c_em), ("Date de maturité", c_ech), ("Taux facial", c_tf)):
        if c is None:
            raise ValueError(f"Colonne « {nom} » introuvable dans la base.")

    base = []
    for r in donnees:
        g = lambda i: r[i] if i is not None and i < len(r) else None
        isin = str(g(c_isin) or "").strip().upper()
        em, ech, tf = _date(g(c_em)), _date(g(c_ech)), _num(g(c_tf))
        if not ISIN_RE.match(isin) or not em or not ech or tf is None:
            continue
        tf = tf * 100 if tf <= 0.5 else tf  # décimal -> %
        code = g(c_code)
        if isinstance(code, float) and code.is_integer():
            code = int(code)
        base.append({
            "isin": isin, "code": str(code) if code is not None else "", "emission": em.isoformat(),
            "echeance": ech.isoformat(), "taux_facial": round(tf, 6),
            "emetteur": str(g(c_emet) or "").strip(), "vn": _num(g(c_vn)) or 100000.0,
        })
    return base


def base_pour_page(base: list[dict]) -> list[list]:
    """Format compact attendu par la page web : [ISIN, code, émission, échéance, taux %, émetteur, VN]."""
    return [[t["isin"], t["code"], t["emission"], t["echeance"], t["taux_facial"], t["emetteur"], t["vn"]] for t in base]


if __name__ == "__main__":  # python -m pricer_obligataire.base_titres "data/Base Titres.xlsx"
    import sys

    b = charger_base(Path(sys.argv[1]))
    print(f"{len(b)} titres lus")
    for t in b[:5]:
        print(t)
