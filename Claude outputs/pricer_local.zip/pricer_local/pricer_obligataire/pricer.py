"""Moteur de valorisation (annexe de la circulaire CDVM/AMMC n° 02/04).

Formules :
  (1)   Mi <= 365 j            P = N (1 + tf Mi/360) / (1 + tr Mr/360)
  (2,3) Mi > 365, Mr <= 365 j   P = Σ F_i / (1 + tr d_i/360)
  (4)   Mr > 365 j              P = Σ F_i / (1 + tr)^(nj/A + i - 1)
avec tr = tA (courbe BAM interpolée) + p (prime de risque / liquidité).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from .conventions import BASE_MONETAIRE, SEUIL_MONETAIRE, base_annee_calendaire, base_annuelle
from .courbe import CourbeTaux, _parse_date, _parse_taux
from .instruments import Flux, Obligation, ObligationRevisable


@dataclass
class Resultat:
    code: str
    date_valorisation: date
    base: str                      # 'monetaire' ou 'actuariel'
    taux: float                    # taux d'actualisation retenu tr = tA + p
    taux_reference: float | None   # tA lu sur la courbe
    prime: float | None
    jours_courbe: int | None       # maturité utilisée pour lire la courbe
    maturite_residuelle: int       # jours jusqu'au dernier flux
    capital_restant: float
    prix_plein: float
    coupon_couru: float
    prix_pied: float
    duration: float                # Macaulay, années
    sensibilite: float             # duration modifiée
    convexite: float
    dv01: float                    # DH par titre pour -1 pb
    ajustement_spread: float = 0.0
    echeancier: list[dict] = field(default_factory=list)

    @property
    def prix_plein_pct(self) -> float:
        return 100 * self.prix_plein / self.capital_restant

    @property
    def prix_pied_pct(self) -> float:
        return 100 * self.prix_pied / self.capital_restant

    @property
    def coupon_couru_pct(self) -> float:
        return 100 * self.coupon_couru / self.capital_restant

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "echeancier"}
        d.update(prix_plein_pct=self.prix_plein_pct, prix_pied_pct=self.prix_pied_pct,
                 coupon_couru_pct=self.coupon_couru_pct)
        return d

    def echeancier_df(self):
        import pandas as pd

        return pd.DataFrame(self.echeancier)

    def __str__(self) -> str:
        l = [
            f"{self.code} — valorisation au {self.date_valorisation:%d/%m/%Y}",
            f"  Maturité résiduelle : {self.maturite_residuelle} j  |  base {self.base}",
        ]
        if self.taux_reference is not None:
            l.append(
                f"  Taux BAM ({self.jours_courbe} j) : {self.taux_reference:.4%}  + prime {self.prime * 1e4:.1f} pb"
            )
        l += [
            f"  Taux d'actualisation : {self.taux:.4%}",
            f"  Prix plein coupon    : {_dh(self.prix_plein)} DH  ({self.prix_plein_pct:.4f} %)",
            f"  Coupon couru         : {_dh(self.coupon_couru)} DH  ({self.coupon_couru_pct:.4f} %)",
            f"  Prix pied de coupon  : {_dh(self.prix_pied)} DH  ({self.prix_pied_pct:.4f} %)",
            f"  Duration             : {self.duration:.4f} ans",
            f"  Sensibilité          : {self.sensibilite:.4f}",
            f"  Convexité            : {self.convexite:.4f}",
            f"  DV01                 : {self.dv01:.4f} DH / titre",
        ]
        if self.ajustement_spread:
            l.append(f"  dont ajust. spread   : {_dh(self.ajustement_spread)} DH")
        return "\n".join(l)


def _dh(x: float) -> str:
    """Montant au format marocain : 104 136,57."""
    return f"{x:,.2f}".replace(",", "\u202f").replace(".", ",")


# ---------------------------------------------------------------------- noyau de calcul
def _exposants(flux: list[Flux], d: date, base: str, frequence: int, convention_A: str):
    """Renvoie, pour chaque flux, le « temps » utilisé dans la formule d'actualisation.

    monétaire : d_i / 360 (intérêts simples) ; actuariel : nj/A + (i-1)/f (formule 4).
    """
    if base == "monetaire":
        return [(f.date - d).days / BASE_MONETAIRE for f in flux]
    nj = (flux[0].date - d).days
    A = base_annuelle(flux[0].date) if convention_A == "periode" else base_annee_calendaire(d)
    return [nj / A + i / frequence for i in range(len(flux))]


def _facteur(r: float, t: float, base: str) -> float:
    return 1.0 / (1.0 + r * t) if base == "monetaire" else (1.0 + r) ** (-t)


def _pv_et_risques(flux, temps, r, base):
    P = mac = sens = conv = 0.0
    for f, t in zip(flux, temps):
        df = _facteur(r, t, base)
        pv = f.total * df
        P += pv
        if base == "monetaire":
            ty = t * BASE_MONETAIRE / 365.0
            mac += pv * ty
            sens += pv * t / (1 + r * t)
            conv += pv * 2 * t * t / (1 + r * t) ** 2
        else:
            mac += pv * t
            sens += pv * t / (1 + r)
            conv += pv * t * (t + 1) / (1 + r) ** 2
    return P, mac, sens, conv


def _base_valorisation(ob: Obligation, flux: list[Flux], d: date) -> str:
    if ob.court_terme:
        return "monetaire"
    return "monetaire" if (flux[-1].date - d).days <= SEUIL_MONETAIRE else "actuariel"


# ---------------------------------------------------------------------- API publique
def valoriser(
    obligation: Obligation,
    date_valorisation,
    courbe: CourbeTaux | None = None,
    taux: float | None = None,
    prime: float | None = None,
    convention_A: str = "periode",
) -> Resultat:
    """Valorise un titre.

    - `courbe` : taux lu sur la courbe BAM à la maturité de référence, + prime de l'obligation
      (ou `prime` passé en argument pour la forcer).
    - `taux`   : force directement le taux d'actualisation (monétaire si Mr <= 365 j, sinon
      actuariel). Prioritaire sur la courbe.
    - convention_A : 'periode' (A = 365/366 selon la période annuelle de coupon en cours) ou
      'calendaire' (A = 366 si l'année de valorisation est bissextile).
    """
    d = _parse_date(date_valorisation)
    if d < obligation.date_emission:
        raise ValueError("Date de valorisation antérieure à l'émission.")
    revisable = isinstance(obligation, ObligationRevisable)
    flux = obligation.flux_valorisation(d) if revisable else obligation.flux_restants(d)
    if not flux:
        raise ValueError("Titre échu à la date de valorisation.")

    base = _base_valorisation(obligation, flux, d)
    jours_ref = obligation.jours_taux_reference(d)
    tA = p = None
    if taux is not None:
        r = _parse_taux(taux)
    elif courbe is not None:
        tA = courbe.taux(jours_ref, base)
        p = obligation.prime_a(jours_ref) if prime is None else _parse_taux(prime)
        r = tA + p
    else:
        raise ValueError("Fournir une courbe BAM ou un taux.")

    temps = _exposants(flux, d, base, obligation.frequence, convention_A)
    P, mac, sens, conv = _pv_et_risques(flux, temps, r, base)

    ajust = 0.0
    if revisable and obligation.ajustement_spread:
        ajust = _ajustement_spread(obligation, d, courbe, r if (taux is not None or courbe is None) else None,
                                   p if p is not None else obligation.prime_a(jours_ref))
        P += ajust

    cc = obligation.coupon_couru(d)
    ech = []
    for f, t in zip(flux, temps):
        df = _facteur(r, t, base)
        ech.append({
            "date": f.date, "jours": (f.date - d).days, "capital_debut": f.capital_debut,
            "coupon": f.coupon, "amortissement": f.amortissement, "flux": f.total,
            "temps": t, "facteur_actualisation": df, "valeur_actuelle": f.total * df,
        })

    return Resultat(
        code=obligation.code, date_valorisation=d, base=base, taux=r, taux_reference=tA, prime=p,
        jours_courbe=jours_ref if tA is not None else None,
        maturite_residuelle=(flux[-1].date - d).days if not revisable else (obligation.date_echeance - d).days,
        capital_restant=obligation.capital_restant(d),
        prix_plein=P, coupon_couru=cc, prix_pied=P - cc,
        duration=mac / (P - ajust), sensibilite=sens / (P - ajust), convexite=conv / (P - ajust),
        dv01=sens * 1e-4, ajustement_spread=ajust, echeancier=ech,
    )


def _ajustement_spread(ob: ObligationRevisable, d: date, courbe, taux_force, prime_marche) -> float:
    """VA de l'écart (spread facial - prime de marché) sur les coupons postérieurs à la révision."""
    ecart = ob.spread_emission - prime_marche
    if abs(ecart) < 1e-12:
        return 0.0
    total, precedente = 0.0, ob.flux_restants(d)[0].date
    for dt in ob.dates_apres_revision(d):
        j = (dt - d).days
        montant = ob._coupon_periode(ob.nominal, precedente, dt, ecart)
        b = "monetaire" if j <= SEUIL_MONETAIRE else "actuariel"
        r = taux_force if taux_force is not None else courbe.taux(j, b) + prime_marche
        total += montant * _facteur(r, j / (BASE_MONETAIRE if b == "monetaire" else 365.0), b)
        precedente = dt
    return total


def prix_depuis_taux(obligation: Obligation, date_valorisation, taux: float, **kw) -> Resultat:
    """Alias explicite : valorisation à un taux saisi manuellement."""
    return valoriser(obligation, date_valorisation, taux=taux, **kw)


def taux_depuis_prix(
    obligation: Obligation,
    date_valorisation,
    prix: float,
    type_prix: str = "pied",
    en_pourcentage: bool = True,
    courbe: CourbeTaux | None = None,
    **kw,
) -> dict:
    """Calcul inverse : taux de rendement (dans la base de valorisation) correspondant à un prix.

    prix : en % du capital restant dû (défaut) ou en DH ; type_prix : 'pied' ou 'plein'.
    Si une courbe est fournie, renvoie aussi le spread implicite vs le taux BAM.
    """
    d = _parse_date(date_valorisation)

    def prix_modele(r):
        res = valoriser(obligation, d, taux=r, **kw)
        v = res.prix_pied if type_prix == "pied" else res.prix_plein
        return 100 * v / res.capital_restant if en_pourcentage else v

    lo, hi = -0.05, 0.45  # taux décimaux (> 0.5 serait lu comme un %)
    f_lo, f_hi = prix_modele(lo) - prix, prix_modele(hi) - prix
    if f_lo * f_hi > 0:
        raise ValueError("Prix hors de la plage atteignable (taux entre -5 % et 45 %).")
    for _ in range(200):
        mid = (lo + hi) / 2
        f_mid = prix_modele(mid) - prix
        if abs(f_mid) < 1e-12 or hi - lo < 1e-14:
            break
        if f_lo * f_mid <= 0:
            hi = mid
        else:
            lo, f_lo = mid, f_mid
    r = (lo + hi) / 2
    res = valoriser(obligation, d, taux=r, **kw)
    out = {"taux": r, "base": res.base, "resultat": res}
    if courbe is not None:
        j = obligation.jours_taux_reference(d)
        tA = courbe.taux(j, res.base)
        out.update(taux_reference=tA, spread_implicite=r - tA, jours_courbe=j)
    return out


def stress(obligation: Obligation, date_valorisation, courbe: CourbeTaux, chocs_bp=(-100, -50, -25, 25, 50, 100)):
    """Variation du prix plein pour des translations parallèles de la courbe."""
    base = valoriser(obligation, date_valorisation, courbe)
    lignes = []
    for bp in chocs_bp:
        r = valoriser(obligation, date_valorisation, courbe.decaler(bp))
        lignes.append({"choc_pb": bp, "prix_plein": r.prix_plein,
                       "variation": r.prix_plein - base.prix_plein,
                       "variation_pct": (r.prix_plein / base.prix_plein - 1) * 100})
    return lignes
