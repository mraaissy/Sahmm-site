@echo off
REM Pricer obligataire : double-cliquer pour lancer l'interface dans le navigateur.
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python est introuvable. Installe Python 3.10+ depuis python.org en cochant "Add python.exe to PATH".
  pause
  exit /b 1
)
python app.py
pause
